module.exports = function(Model) {; 
 
 
    let validator = require('../../src/fieldValidations.js');
    let _ = require('lodash');
    let logger = require('../../../utility/logger.js');
    let g = require('strong-globalize')()

    let isNotNullUndefinedAndEmptyString = function (val) {
        return !(_.isNil(val) || val === "")
    }

    function validationResponseHandler(responseObject, err, done) {
        // logger.error(responseObject);
        (!responseObject.skipped && !responseObject.isValid) ? err() : true;
        return done();
    }

    (function overrideSetter() {
        let setterHandler = function (fieldName) {
            return function opaqueSetter(value) {
                this.__data[fieldName] = value;
            }
        }

        let dateType = function (fieldName) {
            return function dateSetter(arg) {
                if(arg === null){
                    this.__data[fieldName] = null;
                }
                else if(isNotNullUndefinedAndEmptyString(arg)){
                    let d = new Date(arg);
                    if (isNaN(d.getTime())) {
                        throw new Error(g.f('Invalid date: %s: %s', fieldName, arg));
                    }
                    this.__data[fieldName] = d;
                }
            }


          }
        _.map(Model.definition.properties, (property, key) => {
            if(!_.includes(['id'], key)){
                if(Model.definition.properties[key].type.name === 'Date'){
                    Model.setter[key] = dateType(key)
                    logger.debug("Model."+ key +" setter overrided");
                }
                else{
                    Model.setter[key] = setterHandler(key)
                    logger.debug("Model."+ key +" setter overrided");
                }
            }
            else
                logger.debug("Model."+ key +" setter override skipped");
        })
    })()

    
    Model.validateAsync('orgId', orgIdDatatypeValidation, {message: "TYPE: datatype mismatch"});

    function orgIdDatatypeValidation(err, done) {
        return validator.validateDatatype('number', this.orgId)
        .then((resp) => {
            //('number' === 'date') ? ((!resp.skipped && !resp.isValid) ? true : this.setAttribute('orgId', new Date(this.orgId)) ): true;
            validationResponseHandler(resp, err, done)
        })
        .catch((err) => {
            logger.error("orgIdDatatypeValidation: Error : ", err)
            done();
        })
    }

    
    Model.validateAsync('orgId', orgIdRequiredValidation, {message: "REQUIRED: field missing"});

    function orgIdRequiredValidation(err, done) {
        return validator.validateRequired(this.orgId)
        .then((resp) => validationResponseHandler(resp, err, done))
        .catch((err) => {
            logger.error("orgIdRequiredValidation: Error : ", err)
            done();
        })
    }

    
    Model.validateAsync('id', idDatatypeValidation, {message: "TYPE: datatype mismatch"});

    function idDatatypeValidation(err, done) {
        return validator.validateDatatype('string', this.id)
        .then((resp) => {
            //('string' === 'date') ? ((!resp.skipped && !resp.isValid) ? true : this.setAttribute('id', new Date(this.id)) ): true;
            validationResponseHandler(resp, err, done)
        })
        .catch((err) => {
            logger.error("idDatatypeValidation: Error : ", err)
            done();
        })
    }

     
 
 return Model}
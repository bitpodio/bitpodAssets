﻿var RequiredQuickFormElements = ["sqlSeq", "displaySeq", "name", "type", "cssClass", "value", "rowNum"];
var FullLayoutElements = ["Grid", "Separator"];
//var sourceURL = 'http://ayushqh7a2.dev.p10.io/svc/explorer/swagger.json';
var sourceURL = `${window.parent.hostURL}/svc/explorer/swagger.json`;
var ajaxContentName = null;
var contentName = "";
var userNameValid = true;
var DropItems = 0;
var TabCount = 0;
var Tabs = [];
var TabProperties = ["label", "transaction", "populateStageTransaction", "updateStageTransaction"];
var FormDetailsRequired = ["title", "isdialog", "type", "successMessage"];
var TabConfigSeq = 10000;
var BusinessProcessFlow = false;
var tour;
var TransactionProperties = ["summarysql", "dbtype", "dbconnection"]; //Used For Providing Property to Transaction If not present.
var TransactionHidden = ["status", "type"];
var TransactionDbType = ["mssql", "oracle", "mysql"];
var defaultDbType = "mssql";
var isEditForm = false;
var lookupurlid = "";
var lookupcontentid = "";
var max_cols = 1;
var formcontentid = "";
var MaxLayoutCount = 0;
var TransactionFilterType = ["string", "number"];
var TabEnabled = true;
var gridster;
var xWidth = 20;
var yWidth = 10;
//var TextBoxes = ["name", "sqlSeq", "jsonUrl", "label", "defaultValue", "fileFor", "allowedExtensions", "sizeLimit", "min", "max", "minLength", "maxLength"];//Element Setting
//var Select = ["required", "readonly", "populateEvent", "showIn", "multiple"];//Element Setting Dropdowns
//var TextBoxes = ["class", "field", "type", "data-ModelApis", "data-attchmentAPI", "data-allowMulti", "label"];
let TextBoxes = [
    "class",
    "orignal-type",
    "field",
    "map-filter",
    "map-field",
    "type",
    "data-ModelApis",
    "data-attchmentAPI",
    "data-allowMulti",
    "step",
    "label",
];
let Select = [
    "map-list",
    "display-field",
    "required"
];
let Internals = [
    "ElementId",
    "type",
    "col-span",
    "displaySeq",
    "rowNum"
]
var showTour = false;
let script = "";
let css = "";
let finalScript = "";
let finalCSS = "";
var FormElementState = [];
var loading = null; //Edit Form Loader.
var HiddenTransMapping = {
    status: "active",
    type: "chart"
};
let swaggerJSON = {

};

let FormConstants = ["FormType", "title", "list-name", "validate", "managePermission", "column-name", "data-showFormActions"];
var Form = {
    FormType: "", //CRM,SalesForce,SQL
    // id: "",
    // isdialog: "false",
    // jsfunction: "Hybrid(this)",
    // title: "sample form 1",
    // type: "Hybrid",
    // successMessage: "Operation Completed Successfully",
    // transactionId: "",
    // insertTransaction: "",
    // businessprocessflow: "false",
    // showButtonControls: "true",
    // getactivestage: "",
    // setactivestage: "",
    // updateTransaction: "",
    // cssPath: "",
    // height: "",
    // width: "",
    // cssClass: "",
    // viewOnly: "false",
    // dbValidator: "",
    // populateEntityId: "",
    // notificationTransaction: "",
    // notificationParamsTransaction: "",
    // postExecutionHandler: "",
    // customValidator: "",
    // Attributes: {
    //     populateDropDown: "none",
    // },
    // customProperties: {

    // },
    // Grids: [],
    class: 'form-body',
    title: "sample form 1",
    'list-name': '',
    validate: true,
    managePermission: true,
    'column-name': '',
    'data-showFormActions': true


};
var MSCRM = {
    EntityName: "",
    DisplayName: "",
    Attributes: [],
};
var SQL = {
    TableName: "",
    Fields: []
};
var ErrorMessages = {
    PropertiesSave: "Saved",
    FilterSeqBlank: "Filter Sequence Cannot Be Blank",

};
var SALESFORCE = {
    EntityName: "",
    DisplayName: "",
    Attributes: [],
    FieldTypeEnum: {
        string: 0,
        picklist: 1,
        multipicklist: 2,
        combobox: 3,
        reference: 4,
        base64: 5,
        boolean: 6,
        currency: 7,
        textarea: 8,
        int: 9,
        double: 10,
        percent: 11,
        phone: 12,
        id: 13,
        date: 14,
        datetime: 15,
        time: 16,
        url: 17,
        email: 18,
        encryptedstring: 19,
        datacategorygroupreference: 20,
        location: 21,
        address: 22,
        anyType: 23,
        complexvalue: 24
    }
};
//Backward Compatability For OBX and Sql Forms
var oldFormDesigner = {
    Transactions: [],
    Hierarchies: [],
};
Object.defineProperty(Array.prototype, "clean", {
    enumerable: false,
    value: function (deleteValue) {
        for (var i = 0; i < this.length; i++) {
            if (this[i] == deleteValue) {
                this.splice(i, 1);
                i--;
            }
        }
        return this;
    }
});



$(document).ready(function () {
    loading = $.loading({
        imgPath: '/form-designer/files/ajax-loading.gif',
        tip: 'Loading',
        zIndex: '10000',
        ajax: false,

    });
    $(".designer-form-name").text(sessionStorage.FormName || "New Form");
    //Tab hover trash icon
    $(document).on('mouseover mouseout', '#pageTab li', function () {
        $(this).find('.editMenu').toggle();
        if ($(this).find('.close').css('visibility') == 'hidden') {
            $(this).find('.close').css('visibility', 'visible');
        } else {
            $(this).find('.close').css('visibility', 'hidden');
        }

    });
    $(document).on('click', '#cssLink', function () {
        $("#myCSS").modal("show");
        $('#cssContainer')
    });
    $(`#dataSourceLi`).click(() => {
        $(`#executionOrder`).css("cssText", 'display: none !important');
        $(`#dataSource`).css("cssText", 'margin-top:5px;height:360px!important;width:886px;display:block');
    });
    $(`#executionOrderLi`).click(() => {
        $(`#dataSource`).css("cssText", 'display: none !important');
        $(`#executionOrder`).css("cssText", 'margin-top:5px;height:360px!important;width:886px;display: block');
    });

    //BusinessProcessFlow = true;
    $.notifyDefaults({
        placement: {
            from: "top",
            align: "center"
        },
        newest_on_top: true,
        z_index: 99999,
        delay: 2000,
    });
    $("#formTitle").text(Form.title);
    $("#transactionTabs").tab();
    $("#transactionTabs").on("click", "a", function (e) {
        e.preventDefault();
        $(this).tab('show');
    });
    $('#formTitle').focusout(function () {
        if ($(this).text() == "") {
            $(this).text("");
        }
        Form.title = $(this).text();
    }).keypress(function (e) {
        if (e.which == 13) {
            e.preventDefault();
            if ($(this).text() == "") {
                $(this).text("");
            }
        }
        Form.title = $(this).text();
    });

    $(".designer-heading-title").click(() => {
        window.parent.closedDesigner();
    })
    $("#submitForm").click(submitForm);
    $('#appElements').draggable({
        containment: "window",
    });
    $("#crmElements").draggable({
        containment: "window",
    });
    $("#salesforceElements").draggable({
        containment: "window",
    });
    $("#sqlElements").draggable({
        containment: "window",
    });
    $("#formInfoLink").click(function () {
        $("#myForm").modal("show");
    });
    $('body').tooltip({
        selector: '[data-toogle=tooltip]'
    });
    $('body').on('click', function (e) {
        $('[data-toggle="popover"]').each(function () {
            //the 'is' for buttons that trigger popups
            //the 'has' for icons within a button that triggers a popup
            if ($(e.target).closest("li").hasClass("ui-menu-item")) {
                return;
            }
            //e.stopPropagation();
            if (!$(this).is(e.target) && $(this).has(e.target).length === 0 && $('.popover').has(e.target).length === 0) {
                $(this).popover('hide');
                $(".MoreElements").hide();
                $(".Basic").show();
            }
        });
    });
    $('[data-toggle="popover"]').popover();
    if (!(sessionStorage.IsBpf === undefined)) {
        BusinessProcessFlow = true;
        if (sessionStorage.EditFormXML == undefined) {
            //Form.customProperties = {
            //    businessprocessflow: true,
            //    showButtonControls: false,
            //};
            Form.businessprocessflow = "true";
            Form.showButtonControls = "false";
        }
    }

    if (!(sessionStorage.EditFormXML === undefined)) {
        //EditForm
        window.EditFormXML = sessionStorage.EditFormXML;
        if (window.opener != null) {
            window.opener.sessionStorage.clear();
        }
        loadFormFromXML();
        //$("#pageTab").children().removeClass("active").first().addClass("active")
    } else {
       // $('#mySelectForm').modal('show');
        getFormType("sql");
         SetAsset();
        setRequiredProperties('hybrid');
    }
    if (window.opener != null) {
        window.opener.sessionStorage.clear();
    }
    $("#updateFormInfo").click(updateFormInfo);
    $('#myForm').on('shown.bs.modal', formDetailsLoad);
    $("#addTransButton").click(function () {
        $(".transSwitch").each(function () {
            if ($(this).hasClass("active")) {
                if ($(this).attr("id") == "dataSourceLi") {
                    addSqlTransaction();
                } else {
                    addSqlHierarchy();
                }
            }
        });
    });
    $("#myTransactions").on('hidden.bs.modal', function (e) {
        // $("#dataSource").empty();
        // $("#executionOrder").empty();
        $('#scriptContainer').empty();
    });
    $("#myCSS").on('hidden.bs.modal', function (e) {
        $("#cssContainer").empty();
    });
    $(`#myCSS`).on(`shown.bs.modal`, function (e) {
        require(["vs/editor/editor.main"], function () {
            editor2 = monaco.editor.create(document.getElementById('cssContainer'), {
                value: css || [
                    '.form {',
                    `background:#fff`,
                    '}'
                ].join('\n'),
                language: 'css',
                automaticLayout: true,
                theme: 'vs-dark'
            });

            editor2.addListener('didType', () => {
                //console.log(editor2.getValue());
                css = editor2.getValue();
            });
        });
    });

    $(`#myTransactions`).on('shown.bs.modal', function (e) {
        require(["vs/editor/editor.main"], function () {
            editor = monaco.editor.create(document.getElementById('scriptContainer'), {
                value: script || [
                    'function someFunction() {',
                    '\tconsole.log("Hello world!");',
                    '}'
                ].join('\n'),
                language: 'javascript',
                automaticLayout: true,
                theme: 'vs-dark'
            });

            editor.focus();

            editor.addListener('didType', () => {
                //console.log(editor.getValue());
                script = editor.getValue();
            });
        });
    });
    // $("#myTransactions").on('shown.bs.modal', function (e) {
    //     //Transaction
    //     var html = "<div class=\"tabbable tabs-left\"><ul class=\"nav nav-tabs\" id=\"transaction-menulist\"></ul><div class=\"tab-content\" id=\"transaction-contentlist\"></div></div>";
    //     $("#dataSource").html(html);
    //     for (var index = 0; index < oldFormDesigner.Transactions.length; index++) {
    //         var data = oldFormDesigner.Transactions[index];
    //         var guidIndex = guid();
    //         $("#transaction-menulist").append("<li><a href=\"#transaction-" + guidIndex + "\" data-toggle=\"tab\" title=\"" + data.Attributes.id + "\" data-toggle=\"tooltip\">" + data.Attributes.id + "</a></li>");
    //         $("#transaction-contentlist").append("<div class=\"tab-pane\" id=\"transaction-" + guidIndex + "\"><span class=\"glyphicon glyphicon-trash pull-right\" onclick=\"removeSqlTransaction('#transaction-" + guidIndex + "')\" ></span></div>");
    //         loadTransactionInDiv(index.toString(), guidIndex);
    //     }
    //     $("#transaction-menulist").on("click", "a", function (e) {
    //         e.preventDefault();
    //         $(this).tab('show');
    //     });
    //     if (oldFormDesigner.Transactions.length > 0) {
    //         $('#transaction-menulist a:first').tab('show');
    //     }
    //     //Hierarchy
    //     html = "<div class=\"tabbable tabs-left\"><ul class=\"nav nav-tabs\" id=\"hierarchy-menulist\"></ul><div class=\"tab-content\" id=\"hierarchy-contentlist\"></div></div>";
    //     $("#executionOrder").html(html);
    //     for (var index = 0; index < oldFormDesigner.Hierarchies.length; index++) {
    //         var data = oldFormDesigner.Hierarchies[index];
    //         var guidIndex = guid();
    //         $("#hierarchy-menulist").append("<li><a href=\"#hierarchy-" + guidIndex + "\" data-toggle=\"tab\" title=\"" + data.Attributes.id + "\" data-toggle=\"tooltip\">" + data.Attributes.id + "</a></li>");
    //         $("#hierarchy-contentlist").append("<div class=\"tab-pane\" id=\"hierarchy-" + guidIndex + "\"></div>");
    //         loadHierarchyInDiv(index.toString(), guidIndex);
    //     }
    //     $("#hierarchy-menulist").on("click", "a", function (e) {
    //         e.preventDefault();
    //         $(this).tab('show');
    //     });
    //     if (oldFormDesigner.Hierarchies.length > 0) {
    //         $('#hierarchy-menulist a:first').tab('show');
    //     }
    // });
    $('#cssSave').click(function () {
        finalCSS = css;
        $("#myCSS").modal('hide');
    })
    $("#transactionSave").click(function () {
        finalScript = script;
        $("#myTransactions").modal('hide');
        //finalCSS = css;
        //For Each Transaction.
        // try {
        //     verifyTransaction();
        //     oldFormDesigner.Transactions = [];
        //     $("#transaction-menulist").children().each(function () {
        //         var divId = $(this).children().first().attr("href");
        //         var attributes = ["id", "status", "type"];
        //         var newObject = {
        //             Attributes: {
        //             },
        //             Filters: []
        //         };
        //         $(divId).find("#transactionData").find("input,textarea,select").each(function () {
        //             var property = $(this).attr("name");
        //             var value = $(this).val();
        //             if ($.inArray(property, attributes) != -1) {
        //                 newObject.Attributes[property] = value;
        //             }
        //             else {
        //                 newObject[property] = value;
        //             }
        //         });
        //         $(divId).find("#filtersDiv ul").children().each(function () {
        //             var filter = {};
        //             $(this).find("input,textarea").each(function () {
        //                 var property = $(this).attr("name");
        //                 var value = $(this).val();
        //                 filter[property] = value;
        //             });
        //             newObject.Filters.push(filter);
        //         });
        //         oldFormDesigner.Transactions.push(newObject);
        //     });
        //     oldFormDesigner.Hierarchies = [];
        //     $("#hierarchy-menulist").children().each(function () {
        //         var divId = $(this).children().first().attr("href");
        //         var newObject = {
        //             Attributes: {
        //             },
        //             TransactionInfo: []
        //         };
        //         newObject.Attributes["id"] = $(divId).find("#hierarchyData").find("input:first").val();
        //         $(divId).find("#transinfoDiv ul").children().each(function () {
        //             var transactionInfo = {};
        //             $(this).find("input").each(function () {
        //                 var property = $(this).attr("name");
        //                 var value = $(this).val();
        //                 transactionInfo[property] = value;
        //             });
        //             newObject.TransactionInfo.push(transactionInfo);
        //         });
        //         oldFormDesigner.Hierarchies.push(newObject);
        //     });

        //     //alert("saved");
        //     $.notify({ icon: 'glyphicon glyphicon-floppy-saved', title: '<strong>Saved</strong>', message: 'Data Source Information Updated' }, { type: 'success' });
        //     $("#myTransactions").modal('hide');
        // }
        // catch (e) {
        //     //alert(e);
        //     $.notify({ icon: 'glyphicon glyphicon-exclamation-sign', title: '<strong>Error</strong>', message: e }, { type: 'danger', z_index: 99999 });
        // }
    });
    $(document).on('click', function (event) {
        $('.layout-column-menu-icon').removeClass('open');
    })


});

function checkContentName(value) {
    if ($("#formContentname").closest(".form-group").hasClass("has-error")) {
        $("#formContentname").closest(".form-group").removeClass("has-error has-feedback");
        $("#formContentname").next().remove();
    }
    userNameValid = true;
    // if (value != null && value.hasOwnProperty("length") && value.length > 4) {
    //     if (ajaxContentName) {
    //         ajaxContentName.abort();
    //     }
    //     ajaxContentName = $.ajax({
    //         url: "/FormDesignerUpgraded/CheckContentName",
    //         type: "GET",
    //         data: {
    //             contentName: value,
    //         },
    //         contentName: value,
    //         beforeSend: function () {
    //             $('#contentNameMessage').css("text-align", "center");
    //             $('#contentNameMessage').html("<img src=\"files/ajaxloader.gif\" />");
    //         },
    //         success: function (data) {
    //             var message = data.Key;
    //             var Suggestions = $.parseJSON(data.Value);
    //             if (message.toLowerCase() == "available") {
    //                 $("#contentNameMessage").html("<span style='color:green'>" + this.contentName + " is " + message + "</span>");
    //                 userNameValid = true;
    //             }
    //             else {
    //                 $("#contentNameMessage").html("<span style='color:red'>" + this.contentName + " is " + message + "</span><div id=\"suggestionsList\" style=\"text-align:center;\"></div>");
    //                 if (message.toLowerCase() == "not available") {
    //                     var suggestionString = "<ul>";
    //                     for (var index in Suggestions) {
    //                         suggestionString += "<li style=\"padding:4px;\">" + Suggestions[index] + " <input type='radio' onclick=\"setFormName(this.value)\" name='suggestions' value='" + Suggestions[index] + "' /></li>";
    //                     }
    //                     suggestionString += "</ul>";
    //                     $("#suggestionsList").html(suggestionString);

    //                 }
    //             }
    //         },
    //         always: function () {
    //         }
    //     });
    // }
    // else {
    //     $('#contentNameMessage').css("text-align", "center");
    //     $("#contentNameMessage").html("<span style='color:red'>content name cannot be less than 5 characters</span>");
    // }
}

function setRequiredProperties(formType) {
    var requiredHTML = "<font color='red'>*</font>";
    switch (formType.toLowerCase()) {
        case 'hybrid':
            if (BusinessProcessFlow) {
                $("form[name=FormDetails] [name=getactivestage]").before(requiredHTML);
                $("form[name=FormDetails] [name=setactivestage]").before(requiredHTML);
                $("form[name=FormDetails] [name=populateEntityId]").before(requiredHTML);
            } else {
                $("form[name=FormDetails] [name=insertTransaction]").before(requiredHTML);
                $("form[name=FormDetails] [name=updateTransaction]").before(requiredHTML);
                $("form[name=FormDetails] [name=populateEntityId]").before(requiredHTML);
            }
            break;
        case 'new':
            $("form[name=FormDetails] [name=transactionId]").before(requiredHTML);
            break;
        case 'edit':
            $("form[name=FormDetails] [name=transactionId]").before(requiredHTML);
            $("form[name=FormDetails] [name=populateEntityId]").before(requiredHTML);
            break;
    }
}

function setFormName(value) {
    userNameValid = true;
    if ($("#formContentname").closest(".form-group").hasClass("has-error")) {
        $("#formContentname").closest(".form-group").removeClass("has-error has-feedback");
        $("#formContentname").next().remove();
    }
    $("#formContentname").val(value);
    $("#contentNameMessage").empty();
}

function verifyTransaction() {
    verifyTransactionFilter();
    verifyHierarchyTransInformation();
}

function verifyTransactionFilter() {
    $(".my-filter").find("[name=seq]").each(function () {
        if ($(this).val() == "") {
            throw "Filter Sequence Number Cannot Be Blank";
        }
        if (isNaN($(this).val())) {
            throw "Invalid Filter Sequence Number";
        } else if ($(this).val() < 100) {
            throw "Filter Sequence Must Be Greater than or Equal to 100";
        }
    });
}

function verifyHierarchyTransInformation() {
    $(".my-hierarchy").find("[name=id]").each(function () {
        if ($(this).val() == "") {
            throw "Transaction Information Value Cannot Be Blank";
        }
    });
    $(".my-hierarchy").find("[name=seq]").each(function () {
        if ($(this).val() == "") {
            throw "Transaction Information Sequence Cannot Be Blank";
        }
    });
}

function addSqlTransaction() {
    var guidIndex = guid();
    var transactionLabel = "Query";
    $("#transaction-menulist").append("<li><a href=\"#transaction-" + guidIndex + "\" data-toggle=\"tab\" title=\"" + transactionLabel + "\" data-toggle=\"tooltip\">" + transactionLabel + "</a></li>");
    $("#transaction-contentlist").append("<div class=\"tab-pane\" id=\"transaction-" + guidIndex + "\" ></div>");
    var optHTML = "";
    for (var item in TransactionDbType) {
        if (defaultDbType == TransactionDbType[item]) {
            optHTML += "<option value=\"" + TransactionDbType[item] + "\" selected>" + TransactionDbType[item] + "</option>";
        } else {
            optHTML += "<option value=\"" + TransactionDbType[item] + "\">" + TransactionDbType[item] + "</option>";
        }
    }
    $("#transaction-" + guidIndex).append("<div class=\"panel panel-default\"><div class=\"panel-heading\">Query<span class=\"glyphicon glyphicon-trash pull-right\" onclick=\"removeSqlTransaction('#transaction-" + guidIndex + "')\"></span></div><div class=\"panel-body\"><div id=\"transactionData\"><label>id</label><input type=\"text\" name=\"id\" id=\"Transaction_id\" oninput=\"$('a[href=#' + $(this).closest('.tab-pane').attr('id') + ']').text(this.value).attr('title', this.value)\" class=\"form-control\" value=\"" + transactionLabel + "\"><label class=\"hide\">status</label><input type=\"text\" name=\"status\" class=\"form-control hide\" value=\"" + HiddenTransMapping["status"] + "\" /><label class=\"hide\">type</label><input type=\"text\" name=\"type\" class=\"form-control hide\" value=\"" + HiddenTransMapping["type"] + "\" /><label>summarysql</label><textarea class=\"form-control\" name=\"summarysql\" id=\"Transaction_summarysql\" style=\"resize:vertical;\" rows=\"5\"></textarea><label>dbtype</label><select name=\"dbtype\" id=\"Transaction_dbtype\" class=\"form-control\">" + optHTML + "</select><label>dbconnection</label><input type=\"text\" name=\"dbconnection\" id=\"Transaction_dbconnection\" class=\"form-control\" value=\"\"></div><br><div class=\"panel panel-default\"><div class=\"panel-heading\">Filters<span style=\"float:right;\"><span class=\"glyphicon glyphicon-plus\" onclick=\"addFilter(this)\" title=\"Add Filter\" ></span></span></div><div class=\"panel-body\" id=\"filtersDiv\"><ul class=\"my-filter\"></ul></div></div></div></div>");
    $('#transaction-menulist a:last').tab('show');
}

function removeSqlTransaction(TransactionId) {
    if (confirm("Do you want to Remove this Transaction")) {
        //var TransactionId = $(obj).parent().children().first().attr("href");
        $(TransactionId).remove();
        $("[href=" + TransactionId + "]").parent().remove();
        //$(obj).parent().remove();
        $('#transaction-menulist a:first').tab('show');
    }
}

function setLayoutWidth() {
    if (max_cols < 2) {
        return "38%";
    } else if (max_cols < 3) {
        return "60%";
    } else if (max_cols < 4) {
        return "80%";
    }
    return "100%";
}

function removeSqlHierarchy(TransactionId) {
    if (confirm("Do you want to Remove this Hierarchy")) {
        //var TransactionId = $(obj).parent().children().first().attr("href");
        $(TransactionId).remove();
        $("[href=" + TransactionId + "]").parent().remove();
        $('#hierarchy-menulist a:first').tab('show');
    }
}

function addSqlHierarchy() {
    var guidIndex = guid();
    var hierarchyLabel = "Batch";
    $("#hierarchy-menulist").append("<li><a href=\"#hierarchy-" + guidIndex + "\" data-toggle=\"tab\" title=\"" + hierarchyLabel + "\" data-toggle=\"tooltip\">" + hierarchyLabel + "</a></li>");
    $("#hierarchy-contentlist").append("<div class=\"tab-pane\" id=\"hierarchy-" + guidIndex + "\" ></div>");
    $("#hierarchy-" + guidIndex).append("<div class=\"panel panel-default\"><div class=\"panel-heading\">Batch<span class=\"glyphicon glyphicon-trash\" onclick=\"removeSqlHierarchy('#hierarchy-" + guidIndex + "')\"></span></div><div class=\"panel-body\"><div id=\"hierarchyData\"><label>id</label><input type=\"text\" name=\"id\" oninput=\"$('a[href=#' + $(this).closest('.tab-pane').attr('id') + ']').text(this.value).attr('title', this.value)\" class=\"form-control\" value=\"" + hierarchyLabel + "\"></div><br><div class=\"panel panel-default\"><div class=\"panel panel-heading\">Batch Sequence<span style=\"float:right;\"><span class=\"glyphicon glyphicon-plus\" onclick=\"addTransactionInfo(this)\" ></span></span></div><div class=\"panel-body\" id=\"transinfoDiv\"><ul class=\"my-hierarchy\"></ul></div></div></div></div>");
    $('#hierarchy-menulist a:last').tab('show');
}

function formDetailsLoad(e) {
    var form = document.forms.FormDetails;
    // if (BusinessProcessFlow) {
    //     $(".bpf-hide").addClass("hide");
    //     $(".bpf-show").removeClass("hide");
    // }
    // //var setHybrid = false;
    customPropIndex = 0;
    for (var index = 0; index < form.length; index++) {
        // if (form[index].name == "customProperties") {
        //     $.each(Form.customProperties, function (key, value) {
        //         customProp += key + "=" + value + ";";
        //     });
        //     form[index].value = customProp;
        // }
        // else {
        //if (form[index].name.toLowerCase() == "jsfunction" && form[index].value.trim().toLowerCase() == "hybrid(this)") {
        //    setHybrid = true;
        //} else {
        if (_.includes(FormConstants, form[index].name)) {
            form[index].value = Form[form[index].name];
        } else if (form[index].name == "customProperties") {
            customPropIndex = index;
        }
        // else{
        //     customProp += `${form[index].name}=${Form[form[index].name]};`; 
        // }
        //}
        //}
    }
    form[customPropIndex].value = _.map(_.omitBy(Form, (data, key) => _.includes(FormConstants.map(item => item.toLowerCase()), key.toLowerCase())), (v, k) => `${k}=${v};`).join('');


}

function removeHierarchy(id) {
    $("#hierarchyContent").html("");
    oldFormDesigner.Hierarchies[id] = null;
    oldFormDesigner.Hierarchies.clean(null);
    refreshHierarchySelect();
}

function loadHierarchyInDiv(arrayId, guidIndex) {

    var Hierarchy = oldFormDesigner.Hierarchies[arrayId];
    var html = "<div class=\"panel panel-default\"><div class=\"panel-heading\">Batch<span class=\"pull-right\" onclick=\"removeSqlHierarchy('#hierarchy-" + guidIndex + "')\"><i class=\"glyphicon glyphicon-trash\"></i></span></div><div class=\"panel-body\"><div id=\"hierarchyData\">";
    //html += "<input type=\"hidden\" name=\"hierarchyid\" value=\"" + arrayId + "\" />";
    $.each(Hierarchy.Attributes, function (i, attr) {
        html += "<label>";
        html += i;
        html += "</label>";
        if (i.toLowerCase() == "id") {
            html += "<input type=\"text\" name=\"" + i + "\" oninput=\"$('a[href=#' + $(this).closest('.tab-pane').attr('id') + ']').text(this.value).attr('title', this.value)\" class=\"form-control\" value=\"" + attr + "\" />";
        } else {
            html += "<input type=\"text\" name=\"" + i + "\" class=\"form-control\" value=\"" + attr + "\" />";
        }
    });
    html += "</div><br><div class=\"panel panel-default\" ><div class=\"panel-heading\">Batch Sequence<span style=\"float:right;\"><span class=\"glyphicon glyphicon-plus\" onclick=\"addTransactionInfo(this)\"></span></span></div><div class=\"panel-body\" id=\"transinfoDiv\"><ul class=\"my-hierarchy\">";
    for (var i = 0; i < Hierarchy.TransactionInfo.length; i++) {
        html += "<li>";
        $.each(Hierarchy.TransactionInfo[i], function (key, value) {
            html += "<div class=\"col-xs-6\"><label style=\"text-transform:capitalize;\">" + key;
            html += "</label><input class=\"form-control\" type=\"text\" name=\"" + key + "\" value=\"" + value + "\"></div>";

        });
        html += "<span class=\"glyphicon glyphicon-trash\" onclick=\"$(this).closest(\'li\').remove();\"></span></li>";
    }
    html += "</ul></div></div></div></div>";
    $("#hierarchy-" + guidIndex).html(html);
}

function removeTransaction(id) {
    $("#transactionContent").html("");
    oldFormDesigner.Transactions[id] = null;
    oldFormDesigner.Transactions.clean(null);
    refreshTransactionSelect();
}

function loadTransactionInDiv(arrayId, guidIndex) {
    //cmt
    var Transaction = oldFormDesigner.Transactions[arrayId];
    var html = "<div class=\"panel panel-default\"><div class=\"panel-heading\">Query<span class=\"glyphicon glyphicon-trash pull-right\" onclick=\"removeSqlTransaction('#transaction-" + guidIndex + "')\"></span></div><div class=\"panel-body\"><div id=\"transactionData\">";
    //html += "<input type=\"hidden\" name=\"transid\" value=\"" + arrayId + "\" />";
    $.each(Transaction.Attributes, function (i, attr) {
        var className = "";
        if ($.inArray(i, TransactionHidden) >= 0) {
            className = "hide";
        }
        html += "<label class=\"" + className + "\">";
        html += i;
        html += "</label>";
        if (i.toLowerCase() == "id") {
            html += "<input type=\"text\" name=\"" + i + "\" id=\"Transaction_" + i + "\" oninput=\"$('a[href=#' + $(this).closest('.tab-pane').attr('id') + ']').text(this.value).attr('title', this.value)\" class=\"form-control\" value=\"" + attr + "\" />";
        } else {
            html += "<input type=\"text\" name=\"" + i + "\" class=\"form-control " + className + "\" value=\"" + attr + "\" />";
        }
    });
    $.each(Transaction, function (i, attr) {
        if (!(i.toLowerCase() == "attributes" || i.toLowerCase() == "filters")) {
            html += "<label>";
            html += i;
            html += "</label>";
            if (i.toLowerCase() == "summarysql") {
                html += "<textarea class=\"form-control\" name=\"" + i + "\"  id=\"Transaction_" + i + "\" style=\"resize:vertical;\" rows=\"5\">";
                html += attr;
                html += "</textarea>";
            } else if (i.toLowerCase() == "dbtype") {
                html += "<select name=\"" + i + "\" id=\"Transaction_" + i + "\" class=\"form-control\" >";
                for (var opt in TransactionDbType) {
                    if (attr.trim() == TransactionDbType[opt]) {
                        html += "<option value=\"" + TransactionDbType[opt] + "\" selected>" + TransactionDbType[opt] + "</option>";
                    } else {
                        html += "<option value=\"" + TransactionDbType[opt] + "\">" + TransactionDbType[opt] + "</option>";
                    }
                }
                html += "</select>";
            } else {
                html += "<input type=\"text\" name=\"" + i + "\" id=\"Transaction_" + i + "\" class=\"form-control\" value=\"" + attr + "\" />";
            }
        }
    });
    html += "</div><br><div class=\"panel panel-default\"><div class=\"panel-heading\">Filters<span style=\"float:right;\"><span class=\"glyphicon glyphicon-plus\" title=\"Add Filter\" onclick=\"addFilter(this)\"></span></span></div><div class=\"panel-body\" id=\"filtersDiv\"><ul class=\"my-filter\">";
    for (var index in Transaction.Filters) {
        var filter = Transaction.Filters[index];
        html += "<li>";
        $.each(filter, function (key, value) {
            html += "<div class=\"col-xs-2\"><label style=\"text-transform:capitalize;\">";
            html += key;
            html += "</label>";
            html += "<input class=\"form-control\" name=\"" + key + "\" type='text' value='" + value + "' /></div>";
        });
        html += "<span class=\"glyphicon glyphicon-trash\" onclick=\"$(this).closest('li').remove();\"></span></li>";
    }
    html += "</ul></div></div></div></div>";
    //$("#transactionContent").html(html);
    $("#transaction-" + guidIndex).html(html);
    //}
}

function saveTransaction() {
    var arrayId = $("#transactionData input[name=transid]").val();
    if ($("#transactionData [name=id]").val() == "") {
        alert("Transaction Id Cannot Be Blank.");
        return;
    }
    if (arrayId.toLowerCase() == "new") {
        var newObject = {
            Attributes: {},
            Filters: []
        };
        var attr = ["id", "status", "type"];
        var prop = ["summarysql", "dbconnection", "dbtype"];
        var attributes = {};
        for (var index in attr) {
            if ($.inArray(attr[index], TransactionHidden)) {
                attributes[attr[index]] = HiddenTransMapping[attr[index]];
            } else {
                attributes[attr[index]] = $("#transactionData input[name=" + attr[index] + "]").val();
            }
        }
        newObject.Attributes = attributes;
        for (var index in prop) {
            if (prop[index].toLowerCase() == "summarysql") {
                newObject[prop[index]] = $("#transactionData textarea[name=" + prop[index] + "]").val();
            } else {
                newObject[prop[index]] = $("#transactionData input[name=" + prop[index] + "]").val();
            }
        }
        var filters = [];
        $(".my-filter").children().each(function () {
            var obj = {
                defaultValue: "",
                fieldName: "",
                logicalOperator: "",
                operator: "",
                seq: "",
                type: "",
            };
            $(this).find("input").each(function () {
                obj[$(this).attr("name")] = $(this).val();
            });
            filters.push(obj);
        });
        newObject.Filters = filters;
        //console.dir(newObject);
        oldFormDesigner.Transactions.push(newObject);
    } else {
        var oldObject = oldFormDesigner.Transactions[arrayId];
        var newObject = {
            Attributes: {},
            Filters: []
        };
        var attributes = {};
        for (var index in oldObject.Attributes) {
            attributes[index] = $("#transactionData input[name=" + index + "]").val();
        }
        newObject.Attributes = attributes;
        for (var index in oldObject) {
            if (!(index.toLowerCase() == "attributes" || index.toLowerCase() == "filters")) {
                if (index.toLowerCase() == "summarysql") {
                    newObject[index] = $("#transactionData textarea[name=" + index + "]").val();
                } else {
                    newObject[index] = $("#transactionData input[name=" + index + "]").val();
                }
            }
        }
        var filters = [];
        $(".my-filter").children().each(function () {
            var obj = {
                defaultValue: "",
                fieldName: "",
                logicalOperator: "",
                operator: "",
                seq: "",
                type: "",
            };
            $(this).find("input").each(function () {
                obj[$(this).attr("name")] = $(this).val();
            });
            filters.push(obj);
        });
        newObject.Filters = filters;
        //console.dir(newObject);
        oldFormDesigner.Transactions[arrayId] = newObject;
    }
    refreshTransactionSelect();
    $("#transactionContent").html("");
    alert("saved");
}

function refreshTransactionSelect() {
    var html = "<option selected disabled>Select Transaction</option>";
    for (var index = 0; index < oldFormDesigner.Transactions.length; index++) {
        var data = oldFormDesigner.Transactions[index];
        html += "<option value=" + index + ">";
        html += data.Attributes.id;
        html += "</option>";
    }
    html += "<option value=\"New\">Add Transaction</option>";
    $("#transdivselect").html(html);
}

function refreshHierarchySelect() {
    var html = "<option selected disabled>Select Hierarchy</option>";
    for (var index = 0; index < oldFormDesigner.Hierarchies.length; index++) {
        var data = oldFormDesigner.Hierarchies[index];
        html += "<option value=" + index + ">";
        html += data.Attributes.id;
        html += "</option>";
    }
    html += "<option value=\"New\">Add Hierarchy</option>";
    $("#hierarchydivselect").html(html);
}

function saveHierarchy() {
    var arrayId = $("#hierarchyData input[name=hierarchyid]").val();
    if ($("#hierarchyData input[name=id]").val() == "") {
        alert("Hierarchy Id Cannot Be Blank.");
        return;
    }
    if (arrayId.toLowerCase() == "new") {
        var newObject = {
            Attributes: {},
            TransactionInfo: [],
        };
        var attributes = {};
        attributes["id"] = $("#hierarchyData input[name=id]").val();
        newObject.Attributes = attributes;
        var transinfo = [];
        $(".my-hierarchy").children().each(function () {
            var obj = {
                id: "",
                seq: "",
            };
            $(this).find("input").each(function () {
                obj[$(this).attr("name")] = $(this).val();
            });
            transinfo.push(obj);
        });
        newObject.TransactionInfo = transinfo;
        console.dir(newObject);
        oldFormDesigner.Hierarchies.push(newObject);
    } else {
        var oldObject = oldFormDesigner.Hierarchies[arrayId];
        var newObject = {
            Attributes: {},
            TransactionInfo: [],
        };
        var attributes = {};
        for (var index in oldObject.Attributes) {
            attributes[index] = $("#hierarchyData input[name=" + index + "]").val();
        }
        newObject.Attributes = attributes;
        var transinfo = [];
        $(".my-hierarchy").children().each(function () {
            var obj = {
                id: "",
                seq: "",
            };
            $(this).find("input").each(function () {
                obj[$(this).attr("name")] = $(this).val();
            });
            transinfo.push(obj);
        });
        newObject.TransactionInfo = transinfo;
        console.dir(newObject);
        oldFormDesigner.Hierarchies[arrayId] = newObject;
    }
    refreshHierarchySelect();
    $("#hierarchyContent").html("");
    alert("saved");
}

function addFilter(obj) {
    $(obj).closest(".panel-default").find(".my-filter").append('<li><div class="col-xs-2"><label style="text-transform:capitalize;">logicalOperator</label><input class="form-control" name="logicalOperator" type="text" value=""></div><div class="col-xs-2"><label style="text-transform:capitalize;">fieldName</label><input class="form-control" name="fieldName" type="text" value=""></div><div class="col-xs-2"><label style="text-transform:capitalize;">seq</label><input class="form-control" name="seq" type="text" value=""></div><div class="col-xs-2"><label style="text-transform:capitalize;">operator</label><input class="form-control" name="operator" type="text" value=""></div><div class="col-xs-2"><label style="text-transform:capitalize;">defaultValue</label><input class="form-control" name="defaultValue" type="text" value=""></div><div class="col-xs-2"><label style="text-transform:capitalize;">type</label><input class="form-control" name="type" type="text" value=""></div><span class="glyphicon glyphicon-trash" onclick="$(this).closest(\'li\').remove();"></span></li>');
}

function addTransactionInfo(obj) {
    $(obj).closest(".panel-default").find(".my-hierarchy").append('<li><div class="col-xs-6"><label style="text-transform:capitalize;">id</label><input class="form-control" type="text" name="id" value=""></div><div class="col-xs-6"><label style="text-transform:capitalize;">seq</label><input class="form-control" type="text" name="seq" value=""></div><span class="glyphicon glyphicon-trash" onclick="$(this).closest(\'li\').remove();"></span></li>');
}

function loadFormFromXML() {
    try {
        isEditForm = true;
        $("#mySelectForm").modal("hide");
        //var transactionId = "";
        // formcontentid = $(window.EditFormXML).find("id").text();
        // var EntityName = "";
        // contentName = $(window.EditFormXML).find("Name").text();
        // var contextXML = $.parseXML($(window.EditFormXML).find("ContentXml").text());
        // var transactionXML = $.parseXML($(window.EditFormXML).find("TransactionXml").text());
        // Form.jsfunction = $(window.EditFormXML).find("jsfunction").text().trim();
        // Form.isdialog = $(window.EditFormXML).find("isdialog").text();
        //Get Main Transaction->entity Name and  Form DB Type from main transaction.
        // $(contextXML).find("Property").each(function () {
        //     if ($(this).attr("name").toLowerCase() == "transactionid") {
        //         transactionId = $(this).attr("value");
        //         $(transactionXML).find("Transaction").each(function () {
        //             if ($(this).attr("id") == transactionId) {
        //                 $(this).find("Property").each(function () {
        //                     if ($(this).attr("name").toLowerCase() == "primaryentityname") {
        //                         EntityName = $(this).attr("value");
        //                     }
        //                     else if ($(this).attr("name").toLowerCase() == "summarysql" && EntityName == "") {
        //                         //earlier entityname was stored in summarysql so if primaryentityname does not provide entityname take entityname form summarysql
        //                         EntityName = $(this).attr("value");
        //                     }
        //                     else if ($(this).attr("name").toLowerCase() == "dbtype") {
        //                         switch ($(this).attr("value").toLowerCase()) {
        //                             case "mscrm":
        //                                 Form.FormType = "crm";
        //                                 break;
        //                             case "mssql":
        //                                 Form.FormType = "sql";
        //                                 break;
        //                             case "salesforce":
        //                                 Form.FormType = "salesforce";
        //                                 break;
        //                             default:
        //                                 Form.FormType = "sql";
        //                                 console.log("No Form Type Found");
        //                                 break;
        //                         }

        //                     }
        //                 });
        //             }
        //         });
        //     }
        //     else if ($(this).attr("name").toLowerCase() == "businessprocessflow") {
        //         if ($(this).attr("value").toLowerCase() == "true") {
        //             BusinessProcessFlow = true;
        //             //$(".bpf-hide").addClass("hide");
        //         }
        //     }
        // });
        if (Form.FormType == "") {
            Form.FormType = "sql";
        }
        //find lookup grid attached to form.
        // $(contextXML).find("QuickFormElement").each(function () {
        //     if ($(this).attr("dataType") != undefined && $(this).attr("dataType").toLowerCase() == "lookup") {
        //         lookupurlid = $(this).attr("onClick").split(',')[3].split('\'')[1];
        //     }
        // });
        //Get Entity Attributes to Populate Elements in Drag Section and global attribute object.
        switch (Form.FormType.toLowerCase()) {
            case "crm":
                $.ajax({
                    url: '/FormDesignerUpgraded/GetEntityAttributes',
                    data: {
                        Entity: EntityName,
                        Type: "CRM",
                        id: lookupurlid
                    },
                    beforeSend: function () {
                        $("#editLoaderHide").show();
                        loading.open();
                    },
                    success: function (data) {
                        if (data == "") {
                            alert("Error Opening Form Check Your CRM Connection.");
                            window.close();
                            return;
                        }
                        var jsonServerObject = JSON.parse(data);
                        MSCRM.EntityName = EntityName;
                        MSCRM.DisplayName = jsonServerObject[3].Value;;
                        MSCRM.Attributes = jsonServerObject[0].Value;
                        Form.Grids = jsonServerObject[1].Value;
                        if (jsonServerObject[4].Value != null) {
                            lookupcontentid = jsonServerObject[4].Value;
                        }
                        var tempHtml = $("#crmElements .panel-body").html();
                        $("#crmElements .panel-body").html("<div class=\"right-inner-addon \"><span class=\"glyphicon glyphicon-search\"></span><input type=\"search\" id=\"searchCrmElements\"  class=\"form-control\" placeholder=\"Search\" /></div>" + tempHtml);
                        for (var index in MSCRM.Attributes) {
                            // DisplayNameArray.push(MSCRM.Attributes[index].LogicalName + "-" + MSCRM.Attributes[index].DisplayName.LocalizedLabels[0].Label);
                            var description = MSCRM.Attributes[index].Description.LocalizedLabels.length != 0 ? MSCRM.Attributes[index].Description.LocalizedLabels[0].Label : "";
                            if (MSCRM.Attributes[index].RequiredLevel.Value == 2) {
                                $("#crmElementTable").append("<tr><td><button type=\"button\" class=\"btn btn-default btn-sm form-elements required-attr\" onclick=\"this.blur();\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"" + description + "\" id=\"" + MSCRM.Attributes[index].LogicalName + "\" data-arrayid=\"" + index + "\"><b>" + MSCRM.Attributes[index].DisplayName.LocalizedLabels[0].Label + "</b></button></td></tr>");
                            } else {
                                $("#crmElementTable").append("<tr><td><button type=\"button\" class=\"btn btn-default btn-sm form-elements\" onclick=\"this.blur();\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"" + description + "\" id=\"" + MSCRM.Attributes[index].LogicalName + "\" data-arrayid=\"" + index + "\"><b>" + MSCRM.Attributes[index].DisplayName.LocalizedLabels[0].Label + "</b></button></td></tr>");
                            }
                        }
                        $("#searchCrmElements").bind('keyup', function () {
                            var searchTerm = jQuery.trim($(this).val());
                            searchTable($(this).val(), '#crmElementTable');
                        });
                        //Show Drag Elements List
                        $("#crmElements").show();
                        $("#crmElements .panel-heading").html(MSCRM.DisplayName + "<span style=\"float:right;\"><span onclick=\"toggleCrmMenu()\" id=\"toggleCrmElements\" title=\"Toggle\" class=\"btn btn-default\"><span class=\"fa fa-bars\"></span></span><span id=\"btnAddPage\" title=\"Add Tab\" onclick=\"addTab()\" class=\"btn btn-default\"><span class=\"glyphicon glyphicon-plus-sign\"></span></span></span>");
                        $('.form-elements').draggable({
                            helper: 'clone',
                            start: function (event, ui) {
                                ui.helper.css('z-index', "1000");
                            },
                            cancel: false
                        });
                        //Add tooltip to Drag Element List
                        //$('[data-toggle="tooltip"]').tooltip();
                        //Start Loading Form From XML
                        callbackLoadForm(contextXML);
                        //Activate Submit Button.
                        loading.close();
                        $("#editLoaderHide").hide();
                    },
                    error: function (data) {
                        alert("Something Went Wrong while Fetching Meta Data");
                        console.log(data);
                    }
                });
                break;
            case "sql":
                $.ajax({
                    url: sourceURL,
                    beforeSend: function () {
                        $("#editLoaderHide").show();
                        loading.open();
                    },
                    success: function (data) {
                        //console.dir(data);
                        if (data == "") {
                            alert("Error Fetching Swagger JSON.");
                            window.close();
                            return;
                        }
                        swaggerJSON = data;
                        let modelList = Object.keys(data.definitions).map(def => `<option value="${def}">${def}</option>`).join("");
                        $(`#modelList`).append(modelList.concat('<option value="HTMLCONTROLS">HTML CONTROLS</option>'));
                        $('[name=list-name]').html(modelList);
                        $('[name=column-name]').html(modelList);
                        let newModelList = `<option selected="selected">None</option>${modelList}`;
                        $('[data-key=display-field]').html(newModelList);
                        $('[data-key=map-list]').html(newModelList);
                        $("#transactionInfoLink").click(function () {
                            $("#myTransactions").modal("show");
                        });
                        // Form.Grids = $.parseJSON(data);
                        // var mssqlTransaction = $.parseXML($(window.EditFormXML).find("TransactionXml").text());
                        callbackLoadForm();
                        $(".sql-show").removeClass("hide");
                        //loadTransaction(mssqlTransaction);
                        $("#appElements").show();
                        loading.close();
                        $("#editLoaderHide").hide();
                        $('.form-elements').draggable({
                            helper: 'clone',
                            start: function (event, ui) {
                                ui.helper.css('z-index', "1000");
                            },
                            cancel: false
                        });
                        $("#addTab").click(addTab);
                    },
                    error: function (data) {
                        alert("Something Went Wrong while Fetching Grids From Server");
                        console.log(data);
                    }
                });

                break;
            case "salesforce":
                $.ajax({
                    url: "/FormDesignerUpgraded/GetEntityAttributes",
                    data: {
                        Type: "salesforce",
                        Entity: EntityName,
                        id: lookupurlid
                    },
                    beforeSend: function () {
                        $("#editLoaderHide").show();
                        loading.open();
                    },
                    success: function (data) {
                        if (data == "") {
                            alert("Error Opening Form Check Your Salesforce Connection.");
                            window.close();
                            return;
                        }
                        var jsonServerObject = JSON.parse(data);
                        $('#mySelectFormLoader').html("");
                        SALESFORCE.EntityName = EntityName;
                        SALESFORCE.DisplayName = jsonServerObject[2].Value;
                        SALESFORCE.Attributes = jsonServerObject[0].Value;
                        Form.Grids = jsonServerObject[1].Value;
                        if (jsonServerObject[3].Value != null) {
                            lookupcontentid = jsonServerObject[3].Value;
                        }
                        var tempHtml = $("#salesforceElements .panel-body").html();
                        $("#salesforceElements .panel-body").html("<div class=\"right-inner-addon \"><span class=\"glyphicon glyphicon-search\"></span><input type=\"search\" id=\"searchSalesforceElements\"  class=\"form-control\" placeholder=\"Search\" /></div>" + tempHtml);
                        for (var index in SALESFORCE.Attributes) {
                            if (SALESFORCE.Attributes[index].nillable == false && SALESFORCE.Attributes[index].createable == true && SALESFORCE.Attributes[index].defaultedOnCreate != true) {
                                $("#salesforceElementTable").append("<tr><td><button type=\"button\" class=\"btn btn-default btn-sm form-elements required-attr\" onclick=\"this.blur();\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"" + SALESFORCE.Attributes[index].label + "\" id=\"" + SALESFORCE.Attributes[index].name + "\" data-arrayid=\"" + index + "\"><b>" + SALESFORCE.Attributes[index].label + "</b></button></td></tr>");
                            } else {
                                $("#salesforceElementTable").append("<tr><td><button type=\"button\" class=\"btn btn-default btn-sm form-elements\" onclick=\"this.blur();\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"" + SALESFORCE.Attributes[index].label + "\" id=\"" + SALESFORCE.Attributes[index].name + "\" data-arrayid=\"" + index + "\"><b>" + SALESFORCE.Attributes[index].label + "</b></button></td></tr>");
                            }
                        }
                        $("#searchSalesforceElements").bind('keyup', function () {
                            var searchTerm = jQuery.trim($(this).val());
                            searchTable($(this).val(), '#salesforceElementTable');

                        });
                        $("#salesforceElements").show();
                        $("#salesforceElements .panel-heading").html(SALESFORCE.DisplayName + "<span style=\"float:right;\"><span onclick=\"toggleSalesforceMenu()\" id=\"toggleSalesforceElements\" title=\"Toggle\" class=\"btn btn-default\"><span class=\"fa fa-bars\"></span></span><span id=\"btnAddPage\" title=\"Add Tab\" onclick=\"addTab()\" class=\"btn btn-default\"><span class=\"glyphicon glyphicon-plus-sign\"></span></span></span>");
                        $('.form-elements').draggable({
                            helper: 'clone',
                            start: function (event, ui) {
                                ui.helper.css('z-index', "1000");
                            },
                            cancel: false
                        });
                        //$('[data-toggle="tooltip"]').tooltip();
                        //$("#mySelectForm").modal("hide");
                        //enableGridster();
                        //$("#preview").click(showPreview);
                        //Start Loading Form From XML
                        callbackLoadForm(contextXML);
                        //Activate Submit Button.
                        loading.close();
                        $("#editLoaderHide").hide();
                    },
                    error: function (data) {
                        $('#mySelectFormLoader').html("<span style=\"color:red\">Something Went Wrong. Please Try Again.</span>");
                        console.dir(data);
                    }
                });
                break;
        }

    } catch (e) {
        console.dir(e.stack);
        alert("Something Went Wrong while Parsing XML");
        window.close();
    }
}

function loadTransaction(transactionXML) {
    $("#transactionInfoLink").click(function () {
        $("#myTransactions").modal("show");
    });
    //cmt
    $(transactionXML).find("Transaction").each(function () {
        var Transaction = {
            Filters: [],
            Attributes: {}
        };
        $.each(this.attributes, function (i, attr) {
            var name = attr.name;
            var value = attr.value;
            Transaction.Attributes[name] = value;
        });
        $(this).find("Property").each(function () {
            Transaction[$(this).attr("name")] = $(this).attr("value");
        });
        $(this).find("Filter").each(function () {
            var Filter = {};
            $.each(this.attributes, function (i, attr) {
                Filter[attr.name] = attr.value;
            });
            Transaction.Filters.push(Filter);
        });
        for (var index in TransactionProperties) {
            var property = TransactionProperties[index];
            if (!Transaction.hasOwnProperty(property)) {
                Transaction[property] = "";
            }
        }
        oldFormDesigner.Transactions.push(Transaction);
    });
    $(transactionXML).find("Hierarchy").each(function () {
        var Hierarchy = {
            Attributes: {},
            TransactionInfo: []
        };
        $.each(this.attributes, function (i, attr) {
            var name = attr.name;
            var value = attr.value;
            Hierarchy.Attributes[name] = value;
        });
        $(this).find("TransactionInfo").each(function () {
            Tinfo = {};
            $.each(this.attributes, function (i, attr) {
                Tinfo[attr.name] = attr.value;
            });
            Hierarchy.TransactionInfo.push(Tinfo);
        });
        oldFormDesigner.Hierarchies.push(Hierarchy);
    });
}

function callbackLoadForm() {
    populateFormProperties();
    formDetailsLoad(null);
    //setRequiredProperties(Form.type);
    //Enable Gridster will Create a Drop Area with Tabs.
    enableGridster();
    populateFormElement();
    //if (!BusinessProcessFlow) {
    $('#pageTab a:first').tab('show');
    //}
}

function getTabElement(id) {
    for (var index in Tabs) {
        if (Tabs[index]["tabId"] == id.toString()) {
            return Tabs[index];
        }
    }
    return null;
}

function populateFormProperties() {
    let domParser = new DOMParser();
    let dom = domParser.parseFromString(EditFormXML, "text/html");
    let jqeurySelector = $(dom);
    finalScript = jqeurySelector.find('script').map((x, y) => y.innerHTML).get().join('');
    finalCSS = jqeurySelector.find('style').map((x, y) => y.innerHTML).get().join('');
    script = finalScript;
    css = finalCSS;
    let title = _.head(jqeurySelector.find('.form-title').get())["innerText"];
    $('#formTitle').text(title);
    for (let element of _.head(jqeurySelector.find('div.form-body').first().get()).attributes) {
        let {
            name,
            value
        } = element;
        if (name == "validate") {
            Form[name] = "true";
        } else if (name.toLowerCase() == "managepermission") {
            Form["managePermission"] = value;
        } else if (name.toLowerCase() == "data-showformactions") {
            Form["data-showFormActions"] = value;
        } else {
            Form[name] = value;
        }
    }
    MaxLayoutCount = convertToNumber($(dom).find('div.form-body').first().attr("layout"));
    max_cols = MaxLayoutCount;
    // $(contextXML).find("Property").each(function () {
    //     if ($(this).attr("name").toLowerCase() == "layoutcolumnscount") {
    //         MaxLayoutCount = parseInt($(this).attr("value"));
    //         max_cols = MaxLayoutCount;
    //     }
    //     else {
    //         if ($(this).attr("value") != null || $(this).attr("value") != "") {
    //             if (Form[$(this).attr("name")] === undefined) {
    //                 Form.customProperties[$(this).attr("name")] = $(this).attr("value");
    //             }
    //             else {
    //                 Form[$(this).attr("name")] = $(this).attr("value");
    //             }
    //         }
    //     }

    // });
    //QuickForm Attributes
    // $(contextXML).find("QuickForm").each(function () {
    //     $.each(this.attributes, function (i, attrib) {
    //         Form[attrib.name] = attrib.value;
    //         if (attrib.name.toLowerCase() == "title") {
    //             $("#formTitle").text(attrib.value);
    //         }
    //     });
    // });
}

function populateFormElement() {
    //var row = -1;
    //var column = -1;
    //Check Total Tabs count.
    TabCount = 0;
    // $(contextXML).find("QuickFormElement").each(function () {
    //     if ($(this).attr("type").toLowerCase() == "tab") {
    //         //TabEnabled = true;
    //         TabCount++;
    //     }
    // });
    var TotalElementCount = -1;
    var rowCapacity = 0; //Total Element in current Row.
    var Row = 1;
    var prevRow = 1;
    var hasRowNum = true;
    var currentTab = -1; //To point Tab in Element
    let domParser = new DOMParser();
    let dom = domParser.parseFromString(EditFormXML, "text/html");
    let jqeurySelector = $(dom);
    // var QFE = $(contextXML).find("QuickFormElement").sort(function (a, b) {
    //     return (parseInt($(a).attr('displaySeq')) - parseInt($(b).attr('displaySeq')));
    // });
    // $(QFE).each(function (index) {
    //     if ($(this).attr("type").toLowerCase() != "tab" && $(this).attr("type").toLowerCase() != "endtab") {
    //         if (!$(this).attr("rowNum")) {
    //             hasRowNum = false;
    //             return false;
    //         }
    //     }
    // });
    hasRowNum = false;
    var QFE = jqeurySelector.find("div.form-field");
    //first Element in display sequence will be a tab
    //$(QFE).each(function (index) {
    QFE.each(function (index, element) {
        // if ($(this).attr("type").toLowerCase() == "tab") {
        //     //row++;
        //     //column=0;
        //     //First Tab will Be Present By Default
        //     if (currentTab != -1) {
        //         addTab();
        //     }
        //     Row = 1;
        //     ++currentTab;
        //     rowCapacity = 0;
        //     if (BusinessProcessFlow) {
        //         var newObject = {};
        //         var returnObject = getTabElement(currentTab.toString());
        //         newObject = returnObject == null ? { tabId: currentTab.toString() } : returnObject;
        //         for (var index in TabProperties) {
        //             newObject[TabProperties[index]] = $(this).attr(TabProperties[index]) == undefined ? "" : $(this).attr(TabProperties[index]);
        //         }
        //         if (!returnObject) {
        //             Tabs.push(newObject);
        //         }
        //     }
        //     $('#tabText_' + currentTab).text($(this).attr("label"));
        // }
        // else if ($(this).attr("type").toLowerCase() != "endtab") {
        //Without tabs, form wont have tabs so currentTab will remain -1 
        if (currentTab < 0) {
            currentTab = 0;
        }
        var jsonElement = {
            ElementId: ++TotalElementCount,
            class: "form-field",
            field: "",
            type: "",
            "orignal-type": "",
            "data-ModelApis": "",
            "data-attchmentAPI": "",
            "data-allowMulti": "",
            "orignal-type": "",
            "map-list": "",
            "map-field": "",
            "map-filter": "",
            "display-field": "",
            step: "",
            required: "false",
            label: ""
            // type: "",
            // name: "",
            // label: "",
            // sqlSeq: "",
            // cssClass: "",
            // dataType: "",
            // jsonUrl: "",
            // required: "",
            // viewOnly: "",
            // defaultValue: "",
            // onClick: "",
            // fileFor: "",
            // allowedExtensions: "",
            // sizeLimit: "",
            // multiple: "",
            // min: "",
            // showIn: "",
            // max: "",
            // options: "",
            // showSaveAndCloseButton: "",
            // value: "",
            // minLength: "",
            // maxLength: "",
            // populateElementId: "",
            // readonly: "",
            // editor: "",
            // isFrame: "",
            // onBlur: "",
            // tab: "",
            // errorInfo: "",
            // formatter: "",
            // inlineEditing: "",
            // reflectValue: "",
            // populateEvent: "",
            // target: "",
            // relationShip: ""
        };
        jsonElement.type = "Textbox";
        // $.each(this.attributes, function (i, attrib) {
        //     var name = attrib.name;
        //     var value = attrib.value;
        //     jsonElement[name] = value;
        // });
        for (let attribute of element.firstElementChild.attributes) {
            if (attribute.name == "type") {
                jsonElement['orignal-type'] = attribute.value;
            } else if (attribute.name == "required") {
                jsonElement['required'] = "true";
            } else {
                jsonElement[attribute.name] = attribute.value;
            }
        }
        //label
        jsonElement.label = (element.firstElementChild.firstChild && element.firstElementChild.firstChild.textContent && typeof element.firstElementChild.firstChild.textContent == "string" && element.firstElementChild.firstChild.textContent) || "label"
        jsonElement.label = jsonElement.label.trim();
        //var colspan = 1;
        var colspan = 1;
        if ($.inArray(jsonElement.type, FullLayoutElements) != -1) {
            if (rowCapacity != 0) {
                Row++;
                rowCapacity = 0;
            }
            if (hasRowNum) {
                Row = parseInt(jsonElement.rowNum) + 1;
            }
            colspan = max_cols;
            if (jsonElement.type.toLowerCase() == "grid") {
                addElementToGridster(gridster[currentTab], jsonElement, colspan, (rowCapacity + 1), Row, 3);
                Row = Row + 2;
            } else {
                addElementToGridster(gridster[currentTab], jsonElement, colspan, (rowCapacity + 1), Row, 1);
                Row++;
            }
            rowCapacity = 0;
            FormElementState.push(jsonElement);
            return true;
        }
        if (!(Form.FormType.toLowerCase() == "sql")) {
            $("#" + jsonElement.name.trim()).closest("tr").addClass("used");
        }
        //if (jsonElement.hasOwnProperty("colSpan")) {
        if (element.getAttribute('col-span')) {
            //parse to int;
            //colspan = parseInt(jsonElement.colSpan);
            colspan = parseInt(element.getAttribute('col-span'));
        }
        // switch (Form.FormType.toLowerCase()) {
        //     case "crm":
        //         for (var index in MSCRM.Attributes) {
        //             if (MSCRM.Attributes[index].LogicalName == jsonElement.name) {
        //                 var elementType = MSCRM.Attributes[index].AttributeTypeName.Value.toLowerCase();
        //                 if (elementType == "lookuptype" || elementType == "ownertype" || elementType == "customertype") {
        //                     if (jsonElement.target = MSCRM.Attributes[index].Targets != undefined)
        //                         jsonElement.target = MSCRM.Attributes[index].Targets[0];
        //                     else
        //                         jsonElement.target = elementType;
        //                 }
        //                 else {
        //                     jsonElement.target = elementType;
        //                 }
        //             }

        //         }
        //         break;
        //     case "salesforce":
        //         for (var index in SALESFORCE.Attributes) {
        //             if (SALESFORCE.Attributes[index].name == jsonElement.name) {
        //                 if (SALESFORCE.Attributes[index].type == SALESFORCE.FieldTypeEnum.reference) {
        //                     jsonElement.target = SALESFORCE.Attributes[index].referenceTo[0];
        //                     jsonElement.relationShip = SALESFORCE.Attributes[index].relationshipName;
        //                 }
        //             }
        //         }
        //         break;

        // }
        if (colspan > MaxLayoutCount) {
            colspan = MaxLayoutCount;
            jsonElement.colSpan = colspan;
        }
        FormElementState.push(jsonElement);
        if (hasRowNum) {
            var row = parseInt(jsonElement.rowNum) + 1;
            if (prevRow != row) {
                rowCapacity = 0;
                prevRow = row;
                addElementToGridster(gridster[currentTab], jsonElement, colspan, (rowCapacity + 1), row, 1);
                rowCapacity = rowCapacity + colspan;
            } else {
                addElementToGridster(gridster[currentTab], jsonElement, colspan, (rowCapacity + 1), row, 1);
                rowCapacity = rowCapacity + colspan;
                if (rowCapacity == MaxLayoutCount) {
                    rowCapacity = 0;
                }
            }
        } else {
            if ((rowCapacity + colspan) > MaxLayoutCount) {
                Row++;
                rowCapacity = 0;
                addElementToGridster(gridster[currentTab], jsonElement, colspan, (rowCapacity + 1), Row, 1);
                rowCapacity = rowCapacity + colspan;
            } else {
                addElementToGridster(gridster[currentTab], jsonElement, colspan, (rowCapacity + 1), Row, 1);
                rowCapacity = rowCapacity + colspan;
                if (rowCapacity == MaxLayoutCount) {
                    rowCapacity = 0;
                    Row++;
                }
            }
        }
        //}
    });
}

function addElementToGridster(gridsterObject, element, colspan, colcount, rowcount, colsize) {
    gridsterObject.options.shift_widgets_up = false;
    gridsterObject.avoid_overlapped_widgets = true;
    gridsterObject.add_widget("<li id=\"dropElement_" + DropItems + "\">" + getElementHtml(element, DropItems) + "</li>", colspan, colsize, colcount, rowcount);
    $('#dropElementSetting_' + DropItems).popover({
        container: 'body',
        trigger: "manual",
        placement: function (context, source) {
            var position = $(source).position();

            if (position.left > 515) {
                return "left";
            }

            if (position.left < 515) {
                return "right";
            }

            if (position.top < 110) {
                return "bottom";
            }

            return "top";
        },
        html: true,
        content: populateElement,
    }).click(function (e) {
        e.stopImmediatePropagation();
        $('[data-toggle="popover"]').not(this).popover('hide');
        //closePopover();
        $(this).popover('show');
        return false;
    });
    DropItems++;
    gridsterObject.options.shift_widgets_up = true;
}

function getElementHtml(element, count) {
    var htmlElement = "";
    element.label = element.label == "" ? element.field : element.label;
    switch (element.type.toLowerCase()) {
        case "separator":
            htmlElement = "<div class=\"drop-element-div separator-div\" id=\"dropElementDiv_" + count + "\"><div class=\"drop-element-div-header\"><span style=\"float: right;\" onclick=\"removeElement(this)\"><i class=\"fa fa-trash-o\"></i></span><span style=\"float: right;padding-right: 3px;\" title=\"Properties\" rel=\"popover\" data-toggle=\"popover\" tabindex=\"0\" id=\"dropElementSetting_" + count + "\"><i class=\"fa fa-pencil\"></i></span></div>";
            htmlElement += "<span style='height:100%;width:100%;text-align:center!important;'><label style=\"width:100%;\">" + escapeHtml(element.label) + "</label><div class=\"separator-div\"></div> </span>";
            break;
        case "grid":
            htmlElement = "<div class=\"drop-element-div grid-div\" id=\"dropElementDiv_" + count + "\" style=\"background: url('/Content/FormDesignerUpgraded/images/Grid-image.jpg');background-repeat: no-repeat!important;background-size: cover;\"><div class=\"drop-element-div-header\"><span style=\"float: right;\" onclick=\"removeElement(this)\"><i class=\"fa fa-trash-o\"></i></span><span style=\"float: right;padding-right: 3px;\" title=\"Properties\" rel=\"popover\" data-toggle=\"popover\" tabindex=\"0\" id=\"dropElementSetting_" + count + "\"><i class=\"fa fa-pencil\"></i></span></div>";
            break;
        case "textbox":
            htmlElement = "<div class=\"drop-element-div\" id=\"dropElementDiv_" + count + "\"><div class=\"drop-element-div-header\"><span style=\"float: right;\" onclick=\"removeElement(this)\"><i class=\"fa fa-trash-o\"></i></span><span style=\"float: right;padding-right: 3px;\" title=\"Properties\" rel=\"popover\" data-toggle=\"popover\" tabindex=\"0\" id=\"dropElementSetting_" + count + "\"><i class=\"fa fa-pencil\"></i></span></div>";
            htmlElement += "<label title=\"" + element.label + "\">" + escapeHtml(element.label);
            if (element.required.toLowerCase() == "true") {
                htmlElement += "<font color=\"red\">*</font>"
            }
            htmlElement += "</label>";
            // if (element.dataType.toLowerCase() == "lookup") {
            //     htmlElement += "<div class=\"lookup-div\"><input type=\"text\"><a class=\"lookupClick\"><img src=\"/Content/FormDesignerUpgraded/images/search_mag.png\" id=\"lkserarchbutton\"></a></div>";
            // }
            // else {
            htmlElement += "<input type='text' />";
            //}
            htmlElement += "</div>";
            break;
        case "dropdown":
            htmlElement = "<div class=\"drop-element-div\" id=\"dropElementDiv_" + count + "\"><div class=\"drop-element-div-header\"><span style=\"float: right;\" onclick=\"removeElement(this)\"><i class=\"fa fa-trash-o\"></i></span><span style=\"float: right;padding-right: 3px;margin-right:1px;\" title=\"Properties\" rel=\"popover\" data-toggle=\"popover\" tabindex=\"0\" id=\"dropElementSetting_" + count + "\"><i class=\"fa fa-pencil\"></i></span></div>";
            htmlElement += "<label title=\"" + element.label + "\">" + escapeHtml(element.label);
            if (element.required.toLowerCase() == "true") {
                htmlElement += "<font color=\"red\">*</font>"
            }
            htmlElement += "</label>";
            htmlElement += "<select></select>";
            htmlElement += "</div>";
            break;
        case "textarea":
            htmlElement = "<div class=\"drop-element-div\" id=\"dropElementDiv_" + count + "\"><div class=\"drop-element-div-header\"><span style=\"float: right;\" onclick=\"removeElement(this)\"><i class=\"fa fa-trash-o\"></i></span><span style=\"float: right;padding-right: 3px;margin-right:1px;\" title=\"Properties\" rel=\"popover\" data-toggle=\"popover\" tabindex=\"0\" id=\"dropElementSetting_" + count + "\"><i class=\"fa fa-pencil\"></i></span></div>";
            htmlElement += "<label title=\"" + element.label + "\">" + escapeHtml(element.label);
            if (element.required.toLowerCase() == "true") {
                htmlElement += "<font color=\"red\">*</font>"
            }
            htmlElement += "</label>";
            htmlElement += "<textarea></textarea>";
            htmlElement += "</div>";
            break;
        case "hidden":
            htmlElement = "<div class=\"drop-element-div\" id=\"dropElementDiv_" + count + "\"><div class=\"drop-element-div-header\"><span style=\"float: right;\" onclick=\"removeElement(this)\"><i class=\"fa fa-trash-o\"></i></span><span style=\"float: right;padding-right: 3px;margin-right:1px;\" title=\"Properties\" rel=\"popover\" data-toggle=\"popover\" tabindex=\"0\" id=\"dropElementSetting_" + count + "\"><i class=\"fa fa-pencil\"></i></span></div>";
            htmlElement += "<label title=\"" + element.label + "\">" + escapeHtml(element.label);
            if (element.required.toLowerCase() == "true") {
                htmlElement += "<font color=\"red\">*</font>"
            }
            htmlElement += "</label>";
            htmlElement += "<span><font color=\"red\">Hidden</font></span>";
            htmlElement += "</div>";
            break;
        case "button":
            htmlElement = "<div class=\"drop-element-div\" id=\"dropElementDiv_" + count + "\"><div class=\"drop-element-div-header\"><span style=\"float: right;\" onclick=\"removeElement(this)\"><i class=\"fa fa-trash-o\"></i></span><span style=\"float: right;padding-right: 3px;margin-right:1px;\" title=\"Properties\" rel=\"popover\" data-toggle=\"popover\" tabindex=\"0\" id=\"dropElementSetting_" + count + "\"><i class=\"fa fa-pencil\"></i></span></div>";
            htmlElement += "<label title=\"" + element.label + "\">" + escapeHtml(element.label);
            if (element.required.toLowerCase() == "true") {
                htmlElement += "<font color=\"red\">*</font>"
            }
            htmlElement += "</label>";
            htmlElement += "<button class=\"btn btn-primary\">Button</button>";
            htmlElement += "</div>";
            break;
        case "file":
            htmlElement = "<div class=\"drop-element-div\" id=\"dropElementDiv_" + count + "\"><div class=\"drop-element-div-header\"><span style=\"float: right;\" onclick=\"removeElement(this)\"><i class=\"fa fa-trash-o\"></i></span><span style=\"float: right;padding-right: 3px;margin-right:1px;\" title=\"Properties\" rel=\"popover\" data-toggle=\"popover\" tabindex=\"0\" id=\"dropElementSetting_" + count + "\"><i class=\"fa fa-pencil\"></i></span></div>";
            htmlElement += "<label title=\"" + element.label + "\">" + escapeHtml(element.label);
            if (element.required.toLowerCase() == "true") {
                htmlElement += "<font color=\"red\">*</font>"
            }
            htmlElement += "</label>";
            htmlElement += "<button class=\"btn btn-primary\">Browse</button>";
            htmlElement += "</div>";
            break;
        case "checkbox":
            htmlElement = "<div class=\"drop-element-div\" id=\"dropElementDiv_" + count + "\"><div class=\"drop-element-div-header\"><span style=\"float: right;\" onclick=\"removeElement(this)\"><i class=\"fa fa-trash-o\"></i></span><span style=\"float: right;padding-right: 3px;margin-right:1px;\" title=\"Properties\" rel=\"popover\" data-toggle=\"popover\" tabindex=\"0\" id=\"dropElementSetting_" + count + "\"><i class=\"fa fa-pencil\"></i></span></div>";
            htmlElement += "<label title=\"" + element.label + "\">" + escapeHtml(element.label);
            if (element.required.toLowerCase() == "true") {
                htmlElement += "<font color=\"red\">*</font>"
            }
            htmlElement += "</label>";
            htmlElement += "<input type=\"checkbox\">";
            htmlElement += "</div>";
            break;
        case "html":
            htmlElement = "<div class=\"drop-element-div\" id=\"dropElementDiv_" + count + "\"><div class=\"drop-element-div-header\"><span style=\"float: right;\" onclick=\"removeElement(this)\"><i class=\"fa fa-trash-o\"></i></span><span style=\"float: right;padding-right: 3px;margin-right:1px;\" title=\"Properties\" rel=\"popover\" data-toggle=\"popover\" tabindex=\"0\" id=\"dropElementSetting_" + count + "\"><i class=\"fa fa-pencil\"></i></span></div>";
            htmlElement += "<label title=\"" + element.label + "\">" + escapeHtml(element.label);
            if (element.required.toLowerCase() == "true") {
                htmlElement += "<font color=\"red\">*</font>"
            }
            htmlElement += "</label>";
            htmlElement += "<i class=\"fa fa-html5\"></i>";
            htmlElement += "</div>";
            break;
        case "password":
            htmlElement = "<div class=\"drop-element-div\" id=\"dropElementDiv_" + count + "\"><div class=\"drop-element-div-header\"><span style=\"float: right;\" onclick=\"removeElement(this)\"><i class=\"fa fa-trash-o\"></i></span><span style=\"float: right;padding-right: 3px;margin-right:1px;\" title=\"Properties\" rel=\"popover\" data-toggle=\"popover\" tabindex=\"0\" id=\"dropElementSetting_" + count + "\"><i class=\"fa fa-pencil\"></i></span></div>";
            htmlElement += "<label title=\"" + element.label + "\">" + escapeHtml(element.label);
            if (element.required.toLowerCase() == "true") {
                htmlElement += "<font color=\"red\">*</font>"
            }
            htmlElement += "</label>";
            htmlElement += "<input type=\"password\">";
            htmlElement += "</div>";
            break;

    }
    return htmlElement;
}

function escapeHtml(text) {
    var map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };

    return text.replace(/[&<>"']/g, function (m) {
        return map[m];
    });
}

function updateFormInfo() {
    var form = document.forms.FormDetails;
    //cmt
    try {
        // for (var key in FormDetailsRequired) {
        //     if ($(form).find("[name=" + FormDetailsRequired[key] + "]").val() == "") {
        //         throw "Required field " + FormDetailsRequired[key] + " found blank";
        //     }
        // }
        for (var i = 0; i < form.length; i++) {
            if (form[i] != undefined) {
                // if (form[i].name == "customProperties") {
                //     Form.customProperties = {};
                //     var valueSet = form[i].value.split(";");
                //     for (var index in valueSet) {
                //         var data = valueSet[index];
                //         if (data != "" && data != "\n") {
                //             var kv = data.split("=");
                //             if (kv.length > 1) {
                //                 Form.customProperties[kv[0].trim()] = kv[1];
                //             }
                //             else {
                //                 alert("Custom values are not in proper format");
                //                 return;
                //             }
                //         }
                //     }
                // } else {
                //if (form[i].name.toLowerCase() == "type" && form[i].value.toLowerCase() == "hybrid") {
                //    Form[form[i].name] = "Edit";
                //}
                //else {
                if (form[i].name == "customProperties") {
                    var valueSet = form[i].value.split(";");
                    for (var index in valueSet) {
                        var data = valueSet[index];
                        if (data != "" && data != "\n") {
                            var kv = data.split("=");
                            if (kv.length > 1) {
                                Form[kv[0].trim()] = kv[1];
                            } else {
                                alert("Custom values are not in proper format");
                                return;
                            }
                        }
                    }
                } else {
                    Form[form[i].name] = form[i].value;
                }
                //}
                //}
            }
        }
        $("#formTitle").text(Form.title);
        //alert("Form Information Updated Successfully");
        $.notify({
            icon: 'glyphicon glyphicon-floppy-saved',
            title: '<strong>Saved</strong>',
            message: 'Form information updated successfully'
        }, {
            type: 'success'
        });
        $("#myForm").modal("hide");
    } catch (e) {
        alert(e);
    }
}

function guid() {
    function s4() {
        return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
    }
    return s4() + s4() + s4() + s4() +
        s4() + s4() + s4() + s4();
}

function reNumberPages() {
    //var tabscount = TabCount;
    //var tabCount = $('#pageTab > li').length;
    //$('#pageTab > li').each(function() {
    //    var pageId = $(this).children('a').attr('href');
    //    tabscount++;
    //    $(this).children('a').html('Tab ' + tabscount +
    //    '<button class="close" title="Remove this Tab" type="button">x</button>');
    //});
}

function dropElement(event, ui) {
    if (tour != null) {
        tour.end();
    }
    $("#draggable").removeAttr("style");
    switch (Form.FormType.toLowerCase()) {
        case "crm":
            var colLayout = 1;
            var rowLayout = 1;
            if ($(ui.draggable).prop("id") == "separator" || $(ui.draggable).prop("id") == "grids") {
                colLayout = max_cols;
                if ($(ui.draggable).prop("id") == "grids") {
                    rowLayout = 3;
                }
            } else {
                $(ui.draggable).closest("tr").addClass("used");
            }
            var elementHtml = generateCrmItem(ui.draggable, DropItems);
            gridster[event.target.id.split("_")[1]].add_widget('<li data-row="1" data-col="1" data-sizex="' + colLayout + '" data-sizey="1" id="dropElement_' + DropItems + '">' + elementHtml + '</li>', colLayout, rowLayout);
            $('#dropElementSetting_' + DropItems).popover({
                container: 'body',
                trigger: "manual",
                placement: function (context, source) {
                    var position = $(source).position();

                    if (position.left > 515) {
                        return "left";
                    }

                    if (position.left < 515) {
                        return "right";
                    }

                    if (position.top < 110) {
                        return "bottom";
                    }

                    return "top";
                },
                html: true,
                content: populateElement,
            }).click(function (e) {
                e.stopImmediatePropagation();
                $('[data-toggle="popover"]').not(this).popover('hide');
                $(this).popover('show');
                return false;
            });;
            break;
        case "salesforce":
            var colLayout = 1;
            var rowLayout = 1;
            if ($(ui.draggable).prop("id") == "separator" || $(ui.draggable).prop("id") == "grids") {
                colLayout = max_cols;
                if ($(ui.draggable).prop("id") == "grids") {
                    rowLayout = 3;
                }
            } else {
                $(ui.draggable).closest("tr").addClass("used");
            }
            var elementHtml = generateSalesforceItem(ui.draggable, DropItems);
            gridster[event.target.id.split("_")[1]].add_widget('<li data-row="1" data-col="1" data-sizex="' + colLayout + '" data-sizey="1" id="dropElement_' + DropItems + '">' + elementHtml + '</li>', colLayout, rowLayout);
            $('#dropElementSetting_' + DropItems).popover({
                container: 'body',
                trigger: "manual",
                placement: function (context, source) {
                    var position = $(source).position();

                    if (position.left > 515) {
                        return "left";
                    }

                    if (position.left < 515) {
                        return "right";
                    }

                    if (position.top < 110) {
                        return "bottom";
                    }

                    return "top";
                },
                html: true,
                content: populateElement,
            }).click(function (e) {
                e.stopImmediatePropagation();
                $('[data-toggle="popover"]').not(this).popover('hide');
                //closePopover();
                $(this).popover('show');
                return false;
            });;
            break;
        case "sql":
            var colLayout = 1;
            var rowLayout = 1;
            if ($(ui.draggable).prop("id") == "separator" || $(ui.draggable).prop("id") == "grids") {
                //colLayout = 9;
                colLayout = max_cols;
                if ($(ui.draggable).prop("id") == "grids") {
                    rowLayout = 3;
                }
            } else {
                //$(ui.draggable).closest("tr").addClass("used");
            }
            var elementHtml = generateSqlItem(ui.draggable, DropItems);
            gridster[event.target.id.split("_")[1]].add_widget('<li data-row="1" data-col="1" data-sizex="' + colLayout + '" data-sizey="1" id="dropElement_' + DropItems + '">' + elementHtml + '</li>', colLayout, rowLayout);
            $('#dropElementSetting_' + DropItems).popover({
                container: 'body',
                trigger: "manual",
                placement: function (context, source) {
                    var position = $(source).position();

                    if (position.left > 515) {
                        return "left";
                    }

                    if (position.left < 515) {
                        return "right";
                    }

                    if (position.top < 110) {
                        return "bottom";
                    }

                    return "top";
                },
                html: true,
                content: populateElement,
            }).click(function (e) {
                e.stopImmediatePropagation();
                $('[data-toggle="popover"]').not(this).popover('hide');
                //closePopover();
                $(this).popover('show');
                return false;
            });;
            break;

    }
    //maintainPopover();
    ++DropItems;
}

function maintainPopover() {
    $('body').off("click");
    $('body').on('click', function (e) {
        $('[data-toggle="popover"]').each(function () {
            //the 'is' for buttons that trigger popups
            //the 'has' for icons within a button that triggers a popup
            if ($(e.target).closest("li").hasClass("ui-menu-item")) {
                return;
            }
            //e.stopPropagation();
            if (!$(this).is(e.target) && $(this).has(e.target).length === 0 && $('.popover').has(e.target).length === 0) {
                $(this).popover('hide');
                $(".MoreElements").hide();
                $(".Basic").show();
            }
        });
    });
}

function addGridsterColumn(event) {
    event.stopImmediatePropagation();
    $('.layout-column-menu-icon').removeClass('open');
    if (max_cols == 9) {
        return;
    }
    ++max_cols;
    changeGridsterColumns();
}

function removeGridsterColumn(event) {
    event.stopImmediatePropagation();
    $('.layout-column-menu-icon').removeClass('open');
    if (max_cols == 1) {
        return;
    }
    --max_cols;
    changeGridsterColumns();
}

function changeGridsterColumns(event) {
    var tabText = "Tab ";
    formXML = $.parseXML('<QuickForm />');
    generateFormElements(formXML);
    max_cols = ((event && parseInt(event.target.value)) || max_cols);
    MaxLayoutCount = max_cols;
    var layoutWidth = setLayoutWidth();
    $(".main-container").empty();
    if (BusinessProcessFlow) {
        tabText = "Stage ";
        $(".main-container").append('<ul id="pageTab" class="nav nav-pills nav-wizard"><li class="active"><a href="#page_0" data-toggle="tab"><span id="tabText_0">' + tabText + '0</span>&nbsp;<span class="fa fa-pencil" title="Properties" rel="popover" data-toggle="popover" tabindex="0" id="tabEdit_0"></span><button class="close" title="Remove" type="button"><i class="fa fa-trash-o"></i></button></a></li></ul><div id="pageTabContent" class="tab-content"><div class="tab-pane active col-sm-12 gridster" id="page_0"><div class="for_show"></div><ul></ul></div></div>');
    } else {
        $(".main-container").append('<ul id="pageTab" class="nav main-tabs nav-tabs"><li class="active"><a href="#page_0" data-toggle="tab"><span id="tabText_0">' + tabText + '0</span>&nbsp;<span class="fa fa-pencil editMenu"></span><button class="close" title="Remove" type="button"><i class="fa fa-trash-o"></i></button></a></li><li class=""><div onClick="addTab()" class="add-tab-button"><i class="fa fa-plus"></i></div></li></ul><div id="pageTabContent" class="tab-content"><div class="tab-pane active col-sm-12" id="page_0"><div class="gridster" style="float:left;width:' + layoutWidth + ';"><div class="for_show"></div><ul></ul></div><span class="layout-column-menu-icon"></span></div></div>');
    }
    FormElementState = [];
    console.log(formXML);
    //$("#page_0").empty().append("<div class=\"for_show\"></div><ul></ul>");
    //gridster[0].destroy(true);
    gridster.map(function (item) {
        return item.destroy(true);
    })
    gridster[0] = $("#page_0 ul").gridster({
        widget_margins: [xWidth, yWidth],
        widget_base_dimensions: ['auto', 50],
        autogenerate_stylesheet: true,
        max_cols: max_cols,
        min_cols: 1,
        min_rows: 100,
        max_rows: 100,
        avoid_overlapped_widgets: true,
        serialize_params: function ($w, wgd) {
            return {
                id: parseInt($($w).attr('id').split("_")[1]),
                col: wgd.col,
                row: wgd.row,
                size_x: wgd.size_x,
                size_y: wgd.size_y
            };
        },
        resize: {
            enabled: true,
            max_size: [max_cols, 1],
            min_size: [1, 1]
        }
    }).data('gridster');
    $('.layout-column-menu-icon').html('<a class="dropdown-toggle layout-column-menu-anchor" onClick="openLayoutMenu(event)" data-toggle="dropdown" ><i class="fa fa-ellipsis-v"></i></a><ul class="dropdown-menu layout-column-menu-list"><li><a onClick="addGridsterColumn(event)" >Add Column</a></li><li><a onClick="removeGridsterColumn(event)" >Remove Column</a></li></ul>');
    // gridster[0].options.min_rows = 100;
    // gridster[0].options.max_rows = 100;
    //$('#page_0  ul').css({ 'width': $(window).width() });
    $("#page_0").droppable({
        tolerance: "pointer",
        accept: ".form-elements",
        drop: dropElement
    });
    $('#pageTab').on('click', ' li a .close', removeTab);
    var for_show = generateIllutionContainers();
    DropItems = 0;
    populateFormElement(formXML);
    $(".for_show").html(for_show);
    $("#pageTab").on("click", "a", function (e) {
        e.preventDefault();
        $(this).tab('show');
    });
}

function generateIllutionContainers() {
    var for_show = "<ul style=\"height: 100%;border:0;\">";
    for (i = 1; i <= max_cols; i++) {
        for_show += "<li data-row=\"1\" data-col=\"" + i + "\" data-sizex=\"1\" data-sizey=\"" + max_cols + "\" id=\"\" class=\"gs-w\" style=\"\"></li>";
    }
    for_show += "</ul>";
    return for_show;
}

function enableGridster() {
    var tabText = "Tab ",
        layoutWidth = setLayoutWidth();
    gridster = [];
    if (BusinessProcessFlow) {
        tabText = "Stage ";
        $(".main-container").append('<ul id="pageTab" class="nav nav-pills nav-wizard"><li class="active"><a href="#page_0" data-toggle="tab"><span id="tabText_0">' + tabText + '0</span>&nbsp;<span class="fa fa-pencil" title="Properties" rel="popover" data-toggle="popover" tabindex="0" id="tabEdit_0"></span><button class="close" title="Remove" type="button"><i class=\"fa fa-trash-o\"></i></button></a></li></ul><div id="pageTabContent" class="tab-content"><div class="tab-pane active col-sm-12 gridster" id="page_0"><div class=\"for_show\"></div><ul></ul></div></div>');
    } else {
        $(".main-container").append('<ul id="pageTab" class="nav main-tabs nav-tabs"><li class="active"><a href="#page_0" data-toggle="tab"><span id="tabText_0">' + tabText + '0</span>&nbsp;<span class="fa fa-pencil editMenu"></span><button class="close" data-toogle="tooltip" title="Remove" type="button"><i class=\"fa fa-trash-o\"></i></button></a></li><li class=""><div onClick="addTab()" class="add-tab-button"><i class="fa fa-plus"></i></div></li></ul><div id="pageTabContent" class="tab-content"><div class="tab-pane active col-sm-12 " id="page_0"><div class="gridster" style="width:' + layoutWidth + ';float:left"><div class="for_show"></div><ul></ul></div><span class="layout-column-menu-icon"></span></div></div>');
    }
    $("[id=tabEdit_0]").popover({
        container: 'body',
        trigger: "manual",
        placement: function (context, source) {
            var position = $(source).position();

            if (position.left > 515) {
                return "left";
            }

            if (position.left < 515) {
                return "right";
            }

            if (position.top < 110) {
                return "bottom";
            }

            return "top";
        },
        html: true,
        content: populateTab,
    }).click(function (e) {
        e.stopImmediatePropagation();
        $('[data-toggle="popover"]').not(this).popover('hide');
        //maintainPopover();
        $(this).popover('show');
        return false;
    });
    $(".editMenu").click(function () {
        var pen = $(this);
        pen.css("visibility", "hidden");
        $(this).prev().attr("contenteditable", "true").focusout(function () {
            $(this).removeAttr("contenteditable").off("focusout");
            pen.css("visibility", "visible");
            if ($(this).text() == "") {
                $(this).text("Default Tab");
            }
        }).keypress(function (e) {
            if (e.which == 13) {
                e.preventDefault();
                $(this).removeAttr("contenteditable").off("focusout");
                pen.css("visibility", "visible");
                if ($(this).text() == "") {
                    $(this).text("Default Tab");
                }
            }
        });
        $(this).prev().focus();
    });
    gridster[0] = $("#page_0 ul").gridster({
        widget_margins: [xWidth, yWidth],
        widget_base_dimensions: ['auto', 50],
        autogenerate_stylesheet: true,
        max_cols: max_cols,
        min_cols: 1,
        min_rows: 100,
        max_rows: 100,
        avoid_overlapped_widgets: true,
        serialize_params: function ($w, wgd) {
            return {
                id: parseInt($($w).attr('id').split("_")[1]),
                col: wgd.col,
                row: wgd.row,
                size_x: wgd.size_x,
                size_y: wgd.size_y
            };
        },
        resize: {
            enabled: true,
            max_size: [max_cols, 1],
            min_size: [1, 1]
        }
    }).data('gridster');
    gridster[0].options.min_rows = 100;
    gridster[0].options.max_rows = 100;
    // $('#page_0  ul').css({ 'width': $(window).width() });
    $("#page_0").droppable({
        tolerance: "pointer",
        accept: ".form-elements",
        drop: dropElement
    });
    //$('#btnAddPage').click(addTab);
    /**
     * Remove a Tab
     */
    $('.layout-column-menu-icon').html('<a class="dropdown-toggle layout-column-menu-anchor" onClick="openLayoutMenu(event)" ><i class="fa fa-ellipsis-v"></i></a><ul class="dropdown-menu layout-column-menu-list"><li><a onClick="addGridsterColumn(event)" >Add Column</a></li><li><a onClick="removeGridsterColumn(event)" >Remove Column</a></li></ul>');
    $('#pageTab').on('click', ' li a .close', removeTab);

    /**
     * Click Tab to show its content 
     */
    $("#pageTab").on("click", "a", function (e) {
        e.preventDefault();
        $(this).tab('show');
    });
    //$(".for_show").html("<ul style=\"height: 100%;\"><li data-row=\"1\" data-col=\"2\" data-sizex=\"1\" data-sizey=\"1\" id=\"\" class=\"gs-w\" style=\"\"></li><li data-row=\"1\" data-col=\"1\" data-sizex=\"1\" data-sizey=\"1\" id=\"\" class=\"gs-w\"></li><li data-row=\"1\" data-col=\"3\" data-sizex=\"1\" data-sizey=\"1\" id=\"\" class=\"gs-w\"></li><li data-row=\"1\" data-col=\"5\" data-sizex=\"1\" data-sizey=\"1\" id=\"\" class=\"gs-w\"></li><li data-row=\"1\" data-col=\"6\" data-sizex=\"1\" data-sizey=\"1\" id=\"\" class=\"gs-w\" style=\"\"></li><li data-row=\"1\" data-col=\"4\" data-sizex=\"1\" data-sizey=\"1\" id=\"\" class=\"gs-w\"></li><li data-row=\"1\" data-col=\"7\" data-sizex=\"1\" data-sizey=\"1\" id=\"\" class=\"gs-w\"></li><li data-row=\"1\" data-col=\"8\" data-sizex=\"1\" data-sizey=\"1\" id=\"\" class=\"gs-w\"></li><li data-row=\"1\" data-col=\""+ max_cols +"\" data-sizex=\"1\" data-sizey=\"1\" id=\"\" class=\"gs-w\" style=\"\"></li></ul>");
    $(".for_show").html(generateIllutionContainers());
}

function addTab() {
    //if ($("#pageTab li").length == 1 && !$("#pageTab li:only-child").is(":visible")) {
    //    $("#pageTab li:only-child").css("display", "block");
    //    return;
    //}
    var tabText = "Tab ",
        layoutWidth = setLayoutWidth();
    TabCount++;
    if (BusinessProcessFlow) {
        tabText = "Stage ";
        var temp = {
            tabId: TabCount.toString()
        };
        for (var index in TabProperties) {
            if (TabProperties[index] == "label") {
                temp[TabProperties[index]] = tabText + TabCount;
            } else {
                temp[TabProperties[index]] = "";
            }
        }
        Tabs.push(temp);
        if ($('#pageTab').children().length == 0) {
            $('#pageTab').append(
                $('<li><a href="#page_' + TabCount + '">' +
                    '<span id="tabText_' + TabCount + '">' + tabText + TabCount +
                    '</span>&nbsp;<span class="fa fa-pencil" title="Properties" rel="popover" data-toggle="popover" tabindex="0" id="tabEdit_' + TabCount + '"></span><button class="close" type="button" ' +
                    'title="Remove"><i class=\'fa fa-trash-o\'></i></button>' +
                    '</a></li>'));
        } else {
            $('#pageTab').children().last().append('<div class="nav-arrow"></div>');
            $('#pageTab').append(
                $('<li><div class="nav-wedge"></div><a href="#page_' + TabCount + '">' +
                    '<span id="tabText_' + TabCount + '">' + tabText + TabCount +
                    '</span>&nbsp;<span class="fa fa-pencil" title="Properties" rel="popover" data-toggle="popover" tabindex="0" id="tabEdit_' + TabCount + '"></span><button class="close" type="button" ' +
                    'title="Remove"><i class=\'fa fa-trash-o\'></i></button>' +
                    '</a></li>'));
        }
    } else {
        $('#pageTab').children().last().before(
            $('<li><a href="#page_' + TabCount + '">' +
                '<span id="tabText_' + TabCount + '">' + tabText + TabCount +
                '</span>&nbsp;<span class="fa fa-pencil editMenu"></span><button class="close" type="button" ' +
                'title="Remove"><i class=\'fa fa-trash-o\'></i></button>' +
                '</a></li>'));
    }
    $("[id=tabEdit_" + TabCount + "]").popover({
        container: 'body',
        trigger: "manual",
        placement: function (context, source) {
            var position = $(source).position();

            if (position.left > 515) {
                return "left";
            }

            if (position.left < 515) {
                return "right";
            }

            if (position.top < 110) {
                return "bottom";
            }

            return "top";
        },
        html: true,
        content: populateTab,
    }).click(function (e) {
        e.stopImmediatePropagation();
        $('[data-toggle="popover"]').not(this).popover('hide');
        //maintainPopover();
        $(this).popover('show');
        return false;
    });
    $(".editMenu").unbind("click");
    $(".editMenu").click(function () {
        var pen = $(this);
        pen.css("visibility", "hidden");
        $(this).prev().attr("contenteditable", "true").focusout(function () {
            $(this).removeAttr("contenteditable").off("focusout");
            pen.css("visibility", "visible");
            if ($(this).text() == "") {
                $(this).text("Default Tab");
            }
        }).keypress(function (e) {
            if (e.which == 13) {
                e.preventDefault();
                $(this).removeAttr("contenteditable").off("focusout");
                pen.css("visibility", "visible");
                if ($(this).text() == "") {
                    $(this).text("Default Tab");
                }
            }
        });
        $(this).prev().focus();
    });
    $('#pageTabContent').append(
        $('<div class="tab-pane col-sm-12"  id="page_' + TabCount + '"><div class="gridster" style="width:' + layoutWidth + ';float:left;"><div class=\"for_show\"></div><ul></ul></div><span class="layout-column-menu-icon"></span></div>'));
    $('a[href="#page_' + TabCount + '"]').tab('show');
    gridster[TabCount] = $("#page_" + TabCount + " ul").gridster({
        widget_margins: [xWidth, yWidth],
        widget_base_dimensions: ['auto', 50],
        autogenerate_stylesheet: true,
        max_cols: max_cols,
        min_cols: max_cols,
        min_rows: 100,
        avoid_overlapped_widgets: true,
        serialize_params: function ($w, wgd) {
            return {
                id: parseInt($($w).attr('id').split("_")[1]),
                col: wgd.col,
                row: wgd.row,
                size_x: wgd.size_x,
                size_y: wgd.size_y
            };
        },
        resize: {
            enabled: true,
            max_size: [max_cols, 1],
            min_size: [1, 1]
        }
    }).gridster().data('gridster');
    gridster[TabCount].options.min_rows = 100;
    gridster[TabCount].options.max_rows = 100;
    // $('#page_' + TabCount + '  ul').css({ 'width': $(window).width() });
    $("#page_" + TabCount).droppable({
        tolerance: "pointer",
        accept: ".form-elements",
        drop: dropElement
    });
    $('.layout-column-menu-icon').html('<a class="dropdown-toggle layout-column-menu-anchor" onClick="openLayoutMenu(event)" data-toggle="dropdown" ><i class="fa fa-ellipsis-v"></i></a><ul class="dropdown-menu layout-column-menu-list"><li><a onClick="addGridsterColumn(event)" >Add Column</a></li><li><a onClick="removeGridsterColumn(event)" >Remove Column</a></li></ul>');
    $(".for_show").html(generateIllutionContainers());
}

function openLayoutMenu(event) {
    $(event.currentTarget).parent('.layout-column-menu-icon').addClass('open');
    event.stopImmediatePropagation();
}

function populateTab() {
    var tabId = $(this).attr("id").split("_")[1];
    var tabObject = getTabElement(tabId);
    for (var index in tabObject) {
        $("[name='tab-" + index + "']").attr("value", tabObject[index]);
    }
    return $("#TabMenu").html();
}

function saveTab(obj) {
    var tabId = $(obj).closest("ul").find("[name='tab-tabId']").val();
    var tabObject = getTabElement(tabId);
    for (var index in tabObject) {
        tabObject[index] = $("[name='tab-" + index + "']").last().val();
        if (index == "label") {
            if (tabObject[index] == "") {
                tabObject[index] = "Default Stage";
            }
            $("#tabText_" + tabId).text(tabObject[index]);
        }
    }
    closePopover();
}

function removeTab() {
    if (confirm("Do you want to Remove this Tab")) {
        var tabId = $(this).parents('li').children('a').attr('href');
        var id = tabId.split('_')[1];
        $(gridster[id].serialize()).each(function () {
            var element = FormElementState[$(this).attr("id")];
            $("#" + element.name).closest("tr").removeClass("used");
            FormElementState[$(this).attr("id")] = null;
        });
        if (BusinessProcessFlow) {
            if ($(this).parents("li").siblings().length == 1) {
                $.notify({
                    icon: 'glyphicon glyphicon-exclamation-sign',
                    title: '<strong>Warning</strong>',
                    message: "Cannot have less than two items in business process flow"
                }, {
                    type: 'warning',
                    z_index: 99999
                });
                return false;
            }
            if ($(this).parents("li").is(":first-child")) {
                $(this).parents("li").next().find(".nav-wedge").remove();
            } else if ($(this).parents("li").is(":last-child")) {
                $(this).parents("li").prev().find(".nav-arrow").remove();
            }
        }
        $(this).parents('li').remove('li');
        $(tabId).remove();
        //var id = tabId.split('_')[1];
        //gridster[id].serialize().each
        reNumberPages();
        $('#pageTab a:first').tab('show');
    }
    return false;
}

function generateSqlItem(Element, count) {
    var htmlElement = "";
    var jsonElement = {
        ElementId: count,
        class: "form-field",
        field: "",
        type: "",
        "orignal-type": "",
        "data-ModelApis": "",
        "data-attchmentAPI": "",
        "data-allowMulti": "",
        "orignal-type": "",
        "map-list": "",
        "map-field": "",
        "map-filter": "",
        "display-field": "",
        step: "",
        required: "false",
        label: ""
        // type: "",
        // name: "",
        // label: "",
        // sqlSeq: "",
        // cssClass: "",
        // dataType: "",
        // jsonUrl: "",
        // required: "",
        // viewOnly: "",
        // defaultValue: "",
        // onClick: "",
        // fileFor: "",
        // allowedExtensions: "",
        // sizeLimit: "",
        // multiple: "",
        // min: "",
        // max: "",
        // options: "",
        // showIn: "",
        // showSaveAndCloseButton: "",
        // value: "",
        // minLength: "",
        // maxLength: "",
        // populateElementId: "",
        // readonly: "",
        // editor: "",
        // isFrame: "",
        // onBlur: "",
        // tab: "",
        // errorInfo: "",
        // formatter: "",
        // inlineEditing: "",
        // reflectValue: "",
        // populateEvent: "",
        // target: "",
        // relationShip: "",


    };
    if ($(Element).hasClass("pten-elements")) {
        switch ($(Element).prop("id").toLowerCase()) {
            case "grids":
                jsonElement.type = "Grid";
                jsonElement.label = "Grid";
                htmlElement = "<div class=\"drop-element-div grid-div\" id=\"dropElementDiv_" + count + "\" style=\"background: url('/Content/FormDesignerUpgraded/images/Grid-image.jpg');background-repeat: no-repeat!important;background-size: cover;\"><div class=\"drop-element-div-header\"><span class=\"element-close-span\" onclick=\"removeElement(this)\"><i class=\"fa fa-trash-o\"></i></span><span class=\"element-setting-span\" title=\"Properties\" rel=\"popover\" data-toggle=\"popover\" tabindex=\"0\" id=\"dropElementSetting_" + count + "\"><i class=\"fa fa-pencil\"></i></span></div>";
                //htmlElement += "<label>Grid</label> <i class=\"material-icons\">grid_on</i>";
                FormElementState.push(jsonElement);
                return htmlElement;
                break;
            case "separator":
                jsonElement.type = "Separator";
                jsonElement.label = "Section";
                jsonElement.name = "Separator";
                htmlElement = "<div class=\"drop-element-div separator-div\" id=\"dropElementDiv_" + count + "\"><div class=\"drop-element-div-header\"><span class=\"element-close-span\" onclick=\"removeElement(this)\"><i class=\"fa fa-trash-o\"></i></span><span class=\"element-setting-span\" title=\"Properties\" rel=\"popover\" data-toggle=\"popover\" tabindex=\"0\" id=\"dropElementSetting_" + count + "\"><i class=\"fa fa-pencil\"></i></span></div>";
                htmlElement += "<span style='height:100%;width:100%;text-align:center!important;'><label style=\"width:100%;\">Section</label><div class=\"separator-div\"></div> </span>";
                FormElementState.push(jsonElement);
                return htmlElement;
                break;
        }
    } else {
        htmlElement = "<div class=\"drop-element-div\" id=\"dropElementDiv_" + count + "\"><div class=\"drop-element-div-header\"><span class=\"element-close-span\" onclick=\"removeElement(this)\"><i class=\"fa fa-trash-o\"></i></span><span class=\"element-setting-span\" title=\"Properties\" rel=\"popover\" data-toggle=\"popover\" tabindex=\"0\" id=\"dropElementSetting_" + count + "\"><i class=\"fa fa-pencil\"></i></span></div>";
        //var logicalName = $(Element).prop("id");
        //var arrayIndex = $(Element).attr("data-arrayid");
        //var element = SQL.Fields[arrayIndex];
        //jsonElement.label = jsonElement.name = element.ColumnName;
        //htmlElement += "<label title=\"" + jsonElement.label + "\">" + jsonElement.label;
        //htmlElement += "</label>";
        //jsonElement.type = "TextBox";
        //htmlElement += "<input type='text' />";
        //htmlElement += "</div>";
        var elementType = $(Element).prop("id"),
            modelName = $(Element).attr("model-name") || "",
            propertyRequired = $(Element).attr("property-required") == "true",
            propertyName = $(Element).attr("property-name") || "";
        jsonElement.label = capitalize(propertyName) || capitalize(elementType);
        jsonElement.field = propertyName;
        jsonElement.required = propertyRequired.toString();
        htmlElement += "<label title=\"" + capitalize(jsonElement.label) + "\">" + capitalize(jsonElement.label);
        htmlElement += `${propertyRequired &&  "<font color='red'>*</font>" || ""}</label>`;
        switch (elementType.toLowerCase()) {
            case "dropdown":
                jsonElement.type = "DropDown";
                htmlElement += "<select></select>";
                break;
            case "textbox":
                jsonElement.type = "TextBox";
                htmlElement += "<input type='text' />";
                break;
            case "button":
                jsonElement.type = "Button";
                htmlElement += "<button class=\"btn btn-primary\">Button</button>";
                break;
            case "checkbox":
                jsonElement.type = "CheckBox";
                htmlElement += "<input type='checkbox' />";
                break;
            case "file":
                jsonElement.type = "File";
                htmlElement += "<button class=\"btn btn-primary\">Browse</button>";
                break;
            case "password":
                jsonElement.type = "Password";
                htmlElement += "<input type='password' />";
                break;
            case "textarea":
                jsonElement.type = "Textarea";
                htmlElement += "<textarea></textarea>";
                break;
            case "html":
                jsonElement.type = "Html";
                htmlElement += "<i class=\"fa fa-html5\"></i>";
                break;
        }
        FormElementState.push(jsonElement);
        return htmlElement;
    }
}

function generateCrmItem(Element, count) {
    var htmlElement = "";
    var jsonElement = {
        ElementId: count,
        type: "",
        name: "",
        label: "",
        sqlSeq: "",
        cssClass: "",
        dataType: "",
        jsonUrl: "",
        required: "",
        viewOnly: "",
        defaultValue: "",
        onClick: "",
        fileFor: "",
        allowedExtensions: "",
        sizeLimit: "",
        multiple: "",
        min: "",
        max: "",
        options: "",
        showSaveAndCloseButton: "",
        value: "",
        minLength: "",
        maxLength: "",
        showIn: "",
        populateElementId: "",
        readonly: "",
        editor: "",
        isFrame: "",
        onBlur: "",
        tab: "",
        errorInfo: "",
        formatter: "",
        inlineEditing: "",
        reflectValue: "",
        populateEvent: "",
        target: "",
        relationShip: "",

    };
    if ($(Element).hasClass("pten-elements")) {
        switch ($(Element).prop("id").toLowerCase()) {
            case "grids":
                jsonElement.type = "Grid";
                jsonElement.label = "Grid";
                htmlElement = "<div class=\"drop-element-div grid-div\" id=\"dropElementDiv_" + count + "\" style=\"background: url('/Content/FormDesignerUpgraded/images/Grid-image.jpg');background-repeat: no-repeat!important;background-size: cover;\"><div class=\"drop-element-div-header\"><span class=\"element-close-span\" onclick=\"removeElement(this)\"><i class=\"fa fa-trash-o\"></i></span><span class=\"element-setting-span\" title=\"Properties\" rel=\"popover\" data-toggle=\"popover\" tabindex=\"0\" id=\"dropElementSetting_" + count + "\"><i class=\"fa fa-pencil\"></i></span></div>";
                //htmlElement += "<label>Grid</label> <i class=\"material-icons\">grid_on</i>";
                FormElementState.push(jsonElement);
                return htmlElement;
                break;
            case "separator":
                jsonElement.type = "Separator";
                jsonElement.label = "Section";
                jsonElement.name = "Separator";
                htmlElement = "<div class=\"drop-element-div separator-div\" id=\"dropElementDiv_" + count + "\"><div class=\"drop-element-div-header\"><span class=\"element-close-span\" onclick=\"removeElement(this)\"><i class=\"fa fa-trash-o\"></i></span><span class=\"element-setting-span\" title=\"Properties\" rel=\"popover\" data-toggle=\"popover\" tabindex=\"0\" id=\"dropElementSetting_" + count + "\"><i class=\"fa fa-pencil\"></i></span></div>";
                htmlElement += "<span style='height:100%;width:100%;text-align:center!important;'><label style=\"width:100%;\">Section</label><div class=\"separator-div\"></div> </span>";
                FormElementState.push(jsonElement);
                return htmlElement;
                break;
        }
    } else {
        htmlElement = "<div class=\"drop-element-div\" id=\"dropElementDiv_" + count + "\"><div class=\"drop-element-div-header\"><span class=\"element-close-span\" onclick=\"removeElement(this)\"><i class=\"fa fa-trash-o\"></i></span><span class=\"element-setting-span\" title=\"Properties\" rel=\"popover\" data-toggle=\"popover\" tabindex=\"0\" id=\"dropElementSetting_" + count + "\"><i class=\"fa fa-pencil\"></i></span></div>";
        var logicalName = $(Element).prop("id");
        var arrayIndex = $(Element).attr("data-arrayid");
        var element = MSCRM.Attributes[arrayIndex];
        var isRequired = false;
        var isDisabled = false;
        jsonElement.name = element.LogicalName;
        jsonElement.label = element.DisplayName.LocalizedLabels[0].Label;
        htmlElement += "<label title=\"" + jsonElement.label + "\">" + jsonElement.label;
        //RequiredLevel=1 for attributes whoose value is given by crm.
        if (element.RequiredLevel.Value == 2) {
            isRequired = true;
            jsonElement.required = "true";
            htmlElement += "<font color='red'>*</font>";
        }
        if (typeof (element.IsDisabled) != "undefined" && element.IsDisabled) {
            isDisabled = true;
            jsonElement.readonly = "true";
        }
        htmlElement += "</label>";
        var entityType = element.AttributeTypeName.Value.toLowerCase();
        if (entityType == "lookuptype" || entityType == "ownertype" || entityType == "customertype") {
            jsonElement.type = "TextBox";
            jsonElement.dataType = "lookup";
            jsonElement.target = element.Targets[0];
            htmlElement += "<div class=\"lookup-div\"><input type=\"text\"><a class=\"lookupClick\"><img src=\"/Content/FormDesignerUpgraded/images/search_mag.png\" id=\"lkserarchbutton\"></a></div>";
        } else if (entityType == "picklisttype" || entityType == "booleantype") {
            jsonElement.type = "DropDown";
            jsonElement.populateEvent = "onLoad";
            jsonElement.target = entityType;
            htmlElement += "<select></select>";
        } else if (entityType == "memotype") {
            jsonElement.type = "Textarea";
            htmlElement += "<textarea></textarea>";
        } else {
            jsonElement.type = "TextBox";
            htmlElement += "<input type='text' />";
            if (entityType == "datetimetype") {
                jsonElement.dataType = "date";
                jsonElement.target = entityType;
            } else if (entityType == "moneytype" || entityType == "integertype") {
                jsonElement.dataType = "float";
                jsonElement.target = entityType;
            }
        }
        FormElementState.push(jsonElement);
        htmlElement += "</div>";
        return htmlElement;
    }
}

function generateSalesforceItem(Element, count) {
    var htmlElement = "";
    var jsonElement = {
        ElementId: count,
        type: "",
        name: "",
        label: "",
        sqlSeq: "",
        cssClass: "",
        dataType: "",
        jsonUrl: "",
        required: "",
        viewOnly: "",
        defaultValue: "",
        onClick: "",
        fileFor: "",
        allowedExtensions: "",
        sizeLimit: "",
        multiple: "",
        min: "",
        max: "",
        options: "",
        showIn: "",
        showSaveAndCloseButton: "",
        value: "",
        minLength: "",
        maxLength: "",
        populateElementId: "",
        readonly: "",
        editor: "",
        isFrame: "",
        onBlur: "",
        tab: "",
        errorInfo: "",
        formatter: "",
        inlineEditing: "",
        reflectValue: "",
        populateEvent: "",
        target: "",
        relationShip: "",

    };
    if ($(Element).hasClass("pten-elements")) {
        switch ($(Element).prop("id").toLowerCase()) {
            case "grids":
                jsonElement.type = "Grid";
                jsonElement.label = "Grid";
                htmlElement = "<div class=\"drop-element-div grid-div\" id=\"dropElementDiv_" + count + "\" style=\"background: url('/Content/FormDesignerUpgraded/images/Grid-image.jpg');background-repeat: no-repeat!important;background-size: cover;\"><div class=\"drop-element-div-header\"><span class=\"element-close-span\" onclick=\"removeElement(this)\"><i class=\"fa fa-trash-o\"></i></span><span class=\"element-setting-span\" title=\"Properties\" rel=\"popover\" data-toggle=\"popover\" tabindex=\"0\" id=\"dropElementSetting_" + count + "\"><i class=\"fa fa-pencil\"></i></span></div>";
                //htmlElement += "<label>Grid</label> <i class=\"material-icons\">grid_on</i>";
                FormElementState.push(jsonElement);
                return htmlElement;
                break;
            case "separator":
                jsonElement.type = "Separator";
                jsonElement.label = "Section";
                jsonElement.name = "Separator";
                htmlElement = "<div class=\"drop-element-div separator-div\" id=\"dropElementDiv_" + count + "\"><div class=\"drop-element-div-header\"><span class=\"element-close-span\" onclick=\"removeElement(this)\"><i class=\"fa fa-trash-o\"></i></span><span class=\"element-setting-span\" title=\"Properties\" rel=\"popover\" data-toggle=\"popover\" tabindex=\"0\" id=\"dropElementSetting_" + count + "\"><i class=\"fa fa-pencil\"></i></span></div>";
                htmlElement += "<span style='height:100%;width:100%;text-align:center!important;'><label style=\"width:100%;\">Section</label><div class=\"separator-div\"></div> </span>";
                FormElementState.push(jsonElement);
                return htmlElement;
                break;
        }
    } else {
        htmlElement = "<div class=\"drop-element-div\" id=\"dropElementDiv_" + count + "\"><div class=\"drop-element-div-header\"><span class=\"element-close-span\" onclick=\"removeElement(this)\"><i class=\"fa fa-trash-o\"></i></span><span class=\"element-setting-span\" title=\"Properties\" rel=\"popover\" data-toggle=\"popover\" tabindex=\"0\" id=\"dropElementSetting_" + count + "\"><i class=\"fa fa-pencil\"></i></span></div>";
        var logicalName = $(Element).prop("id");
        var arrayIndex = $(Element).attr("data-arrayid");
        var element = SALESFORCE.Attributes[arrayIndex];
        var isRequired = false;
        var isDisabled = false;
        jsonElement.name = element.name;
        jsonElement.label = element.label;
        htmlElement += "<label title=\"" + jsonElement.label + "\">" + jsonElement.label;
        if (element.nillable == false && element.createable == true && element.defaultedOnCreate != true) {
            isRequired = true;
            jsonElement.required = "true";
            htmlElement += "<font color='red'>*</font>";
        }
        if (element.createable == false && element.updateable == false) {
            jsonElement.readonly = "true";
        }
        htmlElement += "</label>";
        var entityType = element.type;
        switch (entityType) {
            case SALESFORCE.FieldTypeEnum.reference:
                jsonElement.type = "TextBox";
                jsonElement.dataType = "lookup";
                jsonElement.target = element.referenceTo[0];
                jsonElement.relationShip = element.relationshipName;
                htmlElement += "<div class=\"lookup-div\"><input type=\"text\"><a class=\"lookupClick\"><img src=\"/Content/FormDesignerUpgraded/images/search_mag.png\" id=\"lkserarchbutton\"></a></div>";
                break;
            case SALESFORCE.FieldTypeEnum.picklist:
                jsonElement.type = "DropDown";
                jsonElement.populateEvent = "onLoad";
                //jsonElement.target = entityType;
                htmlElement += "<select></select>";
                break;
            case SALESFORCE.FieldTypeEnum.boolean:
                jsonElement.type = "DropDown";
                jsonElement.populateEvent = "onLoad";
                //jsonElement.target = entityType;
                htmlElement += "<select></select>";
                break;
                //case SALESFORCE.FieldTypeEnum.address:
                //    break;
            case SALESFORCE.FieldTypeEnum.date:
                jsonElement.type = "TextBox";
                htmlElement += "<input type='date' />";
                jsonElement.dataType = "date";
                break;
            case SALESFORCE.FieldTypeEnum.textarea:
                jsonElement.type = "Textarea";
                htmlElement += "<textarea></textarea>";
                break;
            default:
                jsonElement.type = "TextBox";
                htmlElement += "<input type='text' />";
                break;


        }
        FormElementState.push(jsonElement);
        htmlElement += "</div>";
        return htmlElement;
    }
}

function openGif(id) {
    switch (id.toLowerCase()) {
        case "draganddrop":
            $("#myGif").modal("show");
            $("#gifLink").html("<img src=\"/Content/FormDesignerUpgraded/images/draganddrop.gif\" style=\"height: 300px;width: 870px;\" />");
            break;
    }
}

function getFormType(value) {
    if ($("#formTypeSelect").closest(".form-group").hasClass("has-error")) {
        $("#formTypeSelect").closest(".form-group").removeClass("has-error has-feedback");
        $("#formTypeSelect").next().remove();
    }
    Form.FormType = value;
    $('#formTypeList').html("");
    if (value.toLowerCase() == "sql") {
        $('#mySelectFormLoader').css("text-align", "center");
    } else {
        $.ajax({
            url: "/FormDesignerUpgraded/GetMetaData",
            data: {
                Type: value
            },
            Type: "POST",
            beforeSend: function () {
                $('#mySelectFormLoader').css("text-align", "center");
                $('#mySelectFormLoader').html("<img src=\"/Content/FormDesignerUpgraded/icons/ajaxloader.gif\" />");
            },
            success: function (data) {
                switch (Form.FormType.toLowerCase()) {
                    case "crm":
                        if (data == "") {
                            $('#mySelectFormLoader').html("<span style=\"color:red\">Something Went Wrong. Please Try Again.</span>");
                            $("#formTypeSelect").children().first().prop("selected", true);
                            return false;
                        }
                        $('#mySelectFormLoader').html("");
                        var dataArray = $.parseJSON(data);
                        var html = "<label class=\"col-sm-3 control-label\">Entity</label><div class=\"col-sm-9\"><select class=\"form-control\" id=\"entityMetadataSelect\">"
                        for (var index in dataArray) {
                            html += "<option value=\"";
                            html += dataArray[index]["Name"];
                            html += "\">";
                            html += dataArray[index]["Label"];
                            html += "</option>";
                        }
                        html += "</select></div>";
                        $('#formTypeList').html(html);
                        break;
                    case "sql":
                        //$(".crm-enable").css("display", "none");
                        //if (data == "") {
                        //    $('#mySelectFormLoader').html("<span style=\"color:red\">Something Went Wrong. Please Try Again.</span>");
                        //    $("#formTypeSelect").children().first().prop("selected", true);
                        //    return false;
                        //}
                        //$('#mySelectFormLoader').html("");
                        //var dataArray = $.parseJSON(data);
                        //var html = "<label class=\"col-sm-3 control-label\">Table</label><div class=\"col-sm-9\"><select class=\"form-control\" id=\"entityMetadataSelect\">"
                        //for (var index in dataArray) {
                        //    html += "<option value=\"";
                        //    html += dataArray[index]["TableName"];
                        //    html += "\">";
                        //    html += dataArray[index]["TableName"];
                        //    html += "</option>";
                        //}
                        //html += "</select></div>";
                        //$('#formTypeList').html(html);
                        break;
                    case "salesforce":
                        $(".crm-enable").css("display", "none");
                        if (data == "") {
                            $('#mySelectFormLoader').html("<span style=\"color:red\">Something Went Wrong. Please Try Again.</span>");
                            $("#formTypeSelect").children().first().prop("selected", true);
                            return false;
                        }
                        $('#mySelectFormLoader').html("");
                        var dataArray = $.parseJSON(data);
                        var html = "<label class=\"col-sm-3 control-label\">Entity</label><div class=\"col-sm-9\"><select class=\"form-control\" id=\"entityMetadataSelect\">"
                        for (var index in dataArray) {
                            html += "<option value=\"";
                            html += dataArray[index]["Name"];
                            html += "\">";
                            html += dataArray[index]["Label"];
                            html += "</option>";
                        }
                        html += "</select></div>";
                        $('#formTypeList').html(html);
                        break;
                }
                //$("#populateAllDropDown").on("change", function () {
                //    Form.Attributes.populateDropDown = $(this).val().toLowerCase() == "none" ? "" : $(this).val().toLowerCase();
                //});
                $("#tourRequest").prop("disabled", false);
                $("#formSelectSubmit").removeClass("disabled");
            },
            error: function (data) {
                $('#mySelectFormLoader').html("<span style=\"color:red\">Something Went Wrong. Please Try Again.</span>");
                console.dir(data);
            }
        });
    }
}

function changeModel(event) {
    let {
        target: {
            value
        }
    } = event;
    if (value == "HTMLCONTROLS") {
        $(`#appElementsContainer`).html(`<div class="content-menu form-elements" onclick="this.blur();" id="textbox"><span style="font-size:16px; margin-right:5px"><i class="fa fa-file-text-o" aria-hidden="true"></i></span><span class="content-span">Text</span></div>`);
        $('.form-elements').draggable({
            helper: 'clone',
            start: function (event, ui) {
                ui.helper.css('z-index', "1000");
            },
            cancel: false
        });
        return;
    }
    let {
        properties,
        required = []
    } = swaggerJSON.definitions[value];
    $(`#appElementsContainer`).html(Object
        .keys(properties)
        .map((prop, key) => `<div class="content-menu form-elements ${required.includes(prop) && 'required-attr' || ''}" onclick="this.blur();" id="textbox" model-name=${value} property-name=${prop} property-type=${properties[prop]['type']} property-required=${required.includes(prop)}  >
                        <span style="font-size:16px; margin-right:5px">
                            <i class="fa fa-file-text-o" aria-hidden="true"></i>
                        </span>
                        <span class="content-span">${prop}</span>
                </div>`).join(""));
    $('.form-elements').draggable({
        helper: 'clone',
        start: function (event, ui) {
            ui.helper.css('z-index', "1000");
        },
        cancel: false
    });
}
//New Form On Submit Calls this Function
function SetAsset() {
    let frmType = "sql";
    let name = "new form"
    // if ($("#formTypeSelect").val() == null || !userNameValid) {
    //     if (!userNameValid) {
    //         $("#formContentname").closest(".form-group").addClass("has-error has-feedback");
    //         $("#formContentname").after("<span class=\"glyphicon glyphicon-remove form-control-feedback\" ></span>");
    //     }
    //     if ($("#formTypeSelect").val() == null) {
    //         $("#formTypeSelect").closest(".form-group").addClass("has-error has-feedback");
    //         $("#formTypeSelect").after("<span class=\"glyphicon glyphicon-remove form-control-feedback\" ></span>");
    //     }
    //     return;
    // }
    contentName = name //$("#formContentname").val();

    $(".designer-form-name").dblclick(function (e) {
        let htm = `<input type="text"  id="createFormName" value="new form"/>`;
        $(this).html(htm);
        $("#createFormName").focusout(function (e) {
            $(this).parent().html($(this).val() || "new form");
            contentName = $(this).val() || "new form";
        });
    });

    $("#formSelectSubmit").addClass("disabled");
    $("#tourRequest").prop("disabled", true);
    $("#formSelectSubmit").off("click");
    switch (frmType) {
        case "crm":
            if ($("#entityMetadataSelect").val() === undefined) {
                return;
            }
            var EntityName = $("#entityMetadataSelect").val();
            var EntityDisplayName = $("#entityMetadataSelect option:selected").text();
            $.ajax({
                url: "/FormDesignerUpgraded/GetEntityAttributes",
                data: {
                    Type: frmType,
                    Entity: EntityName
                },
                beforeSend: function () {
                    $('#mySelectFormLoader').html("<img src=\"/Content/FormDesignerUpgraded/icons/ajaxloader.gif\" />");
                },
                success: function (data) {
                    switch (Form.FormType.toLowerCase()) {
                        case "crm":
                            var jsonServerObject = JSON.parse(data);
                            $('#mySelectFormLoader').html("");
                            MSCRM.EntityName = EntityName;
                            MSCRM.DisplayName = EntityDisplayName;
                            MSCRM.Attributes = jsonServerObject[0].Value;
                            Form.Grids = jsonServerObject[1].Value;
                            //DisplayNameArray = [];
                            var tempHtml = $("#crmElements .panel-body").html();
                            $("#crmElements .panel-body").html("<div class=\"right-inner-addon \"><span class=\"glyphicon glyphicon-search\"></span><input type=\"search\" id=\"searchCrmElements\"  class=\"form-control\" placeholder=\"Search\" /></div>" + tempHtml);
                            for (var index in MSCRM.Attributes) {
                                // DisplayNameArray.push(MSCRM.Attributes[index].LogicalName + "-" + MSCRM.Attributes[index].DisplayName.LocalizedLabels[0].Label);
                                var description = MSCRM.Attributes[index].Description.LocalizedLabels.length != 0 ? MSCRM.Attributes[index].Description.LocalizedLabels[0].Label : "";
                                if (MSCRM.Attributes[index].RequiredLevel.Value == 2) {
                                    $("#crmElementTable").append("<tr><td><button type=\"button\" class=\"btn btn-default btn-sm form-elements required-attr\" onclick=\"this.blur();\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"" + description + "\" id=\"" + MSCRM.Attributes[index].LogicalName + "\" data-arrayid=\"" + index + "\"><b>" + MSCRM.Attributes[index].DisplayName.LocalizedLabels[0].Label + "</b></button></td></tr>");
                                } else {
                                    $("#crmElementTable").append("<tr><td><button type=\"button\" class=\"btn btn-default btn-sm form-elements\" onclick=\"this.blur();\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"" + description + "\" id=\"" + MSCRM.Attributes[index].LogicalName + "\" data-arrayid=\"" + index + "\"><b>" + MSCRM.Attributes[index].DisplayName.LocalizedLabels[0].Label + "</b></button></td></tr>");
                                }
                            }
                            $("#searchCrmElements").bind('keyup', function () {
                                var searchTerm = jQuery.trim($(this).val());
                                searchTable($(this).val(), '#crmElementTable');
                            });
                            $("#crmElements").show();
                            $("#crmElements .panel-heading").html(MSCRM.DisplayName + "<span style=\"float:right;\"><span onclick=\"toggleCrmMenu()\" id=\"toggleCrmElements\" title=\"Toggle\" class=\"btn btn-default\"><span class=\"fa fa-bars\"></span></span><span id=\"btnAddPage\" onclick=\"addTab()\" title=\"Add Tab\" class=\"btn btn-default\"><span class=\"glyphicon glyphicon-plus-sign\"></span></span></span>");
                            $('.form-elements').draggable({
                                helper: 'clone',
                                start: function (event, ui) {
                                    ui.helper.css('z-index', "1000");
                                },
                                cancel: false
                            });
                            tour = new Tour({
                                steps: [{
                                        element: "#formInfoLink",
                                        title: "Form Details",
                                        content: "Change Form Title, Success Message,  Here",
                                        placement: "bottom"
                                    },
                                    {
                                        element: "#transactionInfoLink",
                                        title: "Transaction Details",
                                        content: "Add/Modify Transaction Here",
                                        placement: "left"
                                    },
                                    {
                                        element: "#hierarchyInfoLink",
                                        title: "Hierarchy Details",
                                        content: "Add/Modify Hierarchy Here",
                                        placement: "bottom"
                                    },
                                    {
                                        element: "#settingsInfoLink",
                                        title: "Settings",
                                        content: "Find Form Designer Setting.",
                                        placement: "bottom"
                                    },
                                    {
                                        element: "#crmElements",
                                        title: "Getting Started With Drag And Drop",
                                        content: "Select an Element Drag on the Canvas To Start Designing.<br /><a href='#' onclick='openGif(\"draganddrop\")'>check how it works</a>",
                                        placement: "left"
                                    },
                                    {
                                        element: "#formDesignerLogo",
                                        title: "Form Designer",
                                        content: "Enjoy. You Are Ready To Go.",
                                        placement: "bottom"
                                    }
                                ]
                            });
                            //$('[data-toggle="tooltip"]').tooltip();
                            showTour = $('#tourRequest').prop("checked");
                            $("#mySelectForm").modal("hide");
                            if (showTour) {
                                // Initialize the tour
                                tour.init();
                                // Start the tour
                                tour.restart(true);
                            }
                            //TabEnabled = $("#tabRequest").prop("checked");
                            //if (!TabEnabled) {
                            //    $("#btnAddPage").hide();
                            //}
                            enableGridster();
                            if (BusinessProcessFlow) {
                                var defaultTabObject = {
                                    tabId: "0"
                                };
                                for (var index in TabProperties) {
                                    defaultTabObject[TabProperties[index]] = "";
                                }
                                defaultTabObject["label"] = "Stage 0";
                                Tabs.push(defaultTabObject);
                                addTab();
                            }
                            //$("#pageTab").children().removeClass("active").first().addClass("active")
                            $('#pageTab a:first').tab('show');
                            $("#preview").click(showPreview);
                            break;
                    }
                },
                error: function (data) {
                    $('#mySelectFormLoader').html("<span style=\"color:red\">Something Went Wrong. Please Try Again.</span>");
                    console.dir(data);
                }
            });

            break;
        case "salesforce":
            if ($("#entityMetadataSelect").val() === undefined) {
                return;
            }
            var EntityName = $("#entityMetadataSelect").val();
            var EntityDisplayName = $("#entityMetadataSelect option:selected").text();
            $.ajax({
                url: "/FormDesignerUpgraded/GetEntityAttributes",
                data: {
                    Type: $("#formTypeSelect").val(),
                    Entity: EntityName
                },
                beforeSend: function () {
                    $('#mySelectFormLoader').html("<img src=\"/Content/FormDesignerUpgraded/icons/ajaxloader.gif\" />");
                },
                success: function (data) {
                    var jsonServerObject = JSON.parse(data);
                    $('#mySelectFormLoader').html("");
                    SALESFORCE.EntityName = EntityName;
                    SALESFORCE.DisplayName = EntityDisplayName;
                    SALESFORCE.Attributes = jsonServerObject[0].Value;
                    Form.Grids = jsonServerObject[1].Value;
                    var tempHtml = $("#salesforceElements .panel-body").html();
                    $("#salesforceElements .panel-body").html("<div class=\"right-inner-addon \"><span class=\"glyphicon glyphicon-search\"></span><input type=\"search\" id=\"searchSalesforceElements\"  class=\"form-control\" placeholder=\"Search\" /></div>" + tempHtml);
                    for (var index in SALESFORCE.Attributes) {
                        if (SALESFORCE.Attributes[index].nillable == false && SALESFORCE.Attributes[index].createable == true && SALESFORCE.Attributes[index].defaultedOnCreate != true) {
                            $("#salesforceElementTable").append("<tr><td><button type=\"button\" class=\"btn btn-default btn-sm form-elements required-attr\" onclick=\"this.blur();\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"" + SALESFORCE.Attributes[index].label + "\" id=\"" + SALESFORCE.Attributes[index].name + "\" data-arrayid=\"" + index + "\"><b>" + SALESFORCE.Attributes[index].label + "</b></button></td></tr>");
                        } else {
                            $("#salesforceElementTable").append("<tr><td><button type=\"button\" class=\"btn btn-default btn-sm form-elements\" onclick=\"this.blur();\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"" + SALESFORCE.Attributes[index].label + "\" id=\"" + SALESFORCE.Attributes[index].name + "\" data-arrayid=\"" + index + "\"><b>" + SALESFORCE.Attributes[index].label + "</b></button></td></tr>");
                        }
                    }
                    $("#searchSalesforceElements").bind('keyup', function () {
                        var searchTerm = jQuery.trim($(this).val());
                        searchTable($(this).val(), '#salesforceElementTable');

                    });
                    $("#salesforceElements").show();
                    $("#salesforceElements .panel-heading").html(SALESFORCE.DisplayName + "<span style=\"float:right;\"><span onclick=\"toggleSalesforceMenu()\" id=\"toggleSalesforceElements\" title=\"Toggle\" class=\"btn btn-default\"><span class=\"fa fa-bars\"></span></span><span id=\"btnAddPage\" title=\"Add Tab\" onclick=\"addTab()\" class=\"btn btn-default\"><span class=\"glyphicon glyphicon-plus-sign\"></span></span></span>");
                    $('.form-elements').draggable({
                        helper: 'clone',
                        start: function (event, ui) {
                            ui.helper.css('z-index', "1000");
                        },
                        cancel: false
                    });
                    tour = new Tour({
                        steps: [{
                                element: "#formInfoLink",
                                title: "Form Details",
                                content: "Change Form Title, Success Message,  Here",
                                placement: "bottom"
                            },
                            {
                                element: "#transactionInfoLink",
                                title: "Transaction Details",
                                content: "Add/Modify Transaction Here",
                                placement: "left"
                            },
                            {
                                element: "#hierarchyInfoLink",
                                title: "Hierarchy Details",
                                content: "Add/Modify Hierarchy Here",
                                placement: "bottom"
                            },
                            {
                                element: "#settingsInfoLink",
                                title: "Settings",
                                content: "Find Form Designer Setting.",
                                placement: "bottom"
                            },
                            {
                                element: "#salesforceElements",
                                title: "Getting Started With Drag And Drop",
                                content: "Select an Element Drag on the Canvas To Start Designing.<br /><a href='#' onclick='openGif(\"draganddrop\")'>check how it works</a>",
                                placement: "left"
                            },
                            {
                                element: "#formDesignerLogo",
                                title: "Form Designer",
                                content: "Enjoy. You Are Ready To Go.",
                                placement: "bottom"
                            }
                        ]
                    });
                    //$('[data-toggle="tooltip"]').tooltip();
                    showTour = $('#tourRequest').prop("checked");
                    $("#mySelectForm").modal("hide");
                    if (showTour) {
                        // Initialize the tour
                        tour.init();
                        // Start the tour
                        tour.restart(true);
                    }
                    enableGridster();
                    if (BusinessProcessFlow) {
                        var defaultTabObject = {
                            tabId: "0"
                        };
                        for (var index in TabProperties) {
                            defaultTabObject[TabProperties[index]] = "";
                        }
                        defaultTabObject["label"] = "Stage 0";
                        Tabs.push(defaultTabObject);
                        addTab();
                    }
                    //$("#pageTab").children().removeClass("active").first().addClass("active")
                    $('#pageTab a:first').tab('show');
                    $("#preview").click(showPreview);
                },
                error: function (data) {
                    $('#mySelectFormLoader').html("<span style=\"color:red\">Something Went Wrong. Please Try Again.</span>");
                    console.dir(data);
                }
            });
            break;
        case "sql":
            $.ajax({
                url: sourceURL,
                type: "GET",
                beforeSend: function () {
                    $('#mySelectFormLoader').html("<img src=\"/Content/FormDesignerUpgraded/icons/ajaxloader.gif\" />");
                },
                success: function (data) {
                    swaggerJSON = data;
                    let modelList = Object.keys(data.definitions).map(def => `<option value="${def}">${def}</option>`).join("");
                    $(`#modelList`).append(modelList.concat('<option value="HTMLCONTROLS">HTML CONTROLS</option>'));
                    $('[name=list-name]').html(modelList);
                    $('[name=column-name]').html(modelList);
                    let newModelList = `<option selected="selected">None</option>${modelList}`;
                    $('[data-key=display-field]').html(newModelList);
                    $('[data-key=map-list]').html(newModelList);
                    var mssqlTransaction = $.parseXML($(window.EditFormXML).find("TransactionXml").text());
                    $(".sql-show").removeClass("hide");
                    $("#appElements").show();
                    $('.form-elements').draggable({
                        helper: 'clone',
                        start: function (event, ui) {
                            ui.helper.css('z-index', "1000");
                        },
                        cancel: false
                    });
                    tour = new Tour({
                        steps: [{
                                element: "#formInfoLink",
                                title: "Form Details",
                                content: "Change Form Title, Success Message,  Here",
                                placement: "bottom"
                            },
                            {
                                element: "#transactionInfoLink",
                                title: "Transaction Details",
                                content: "Add/Modify Transaction Here",
                                placement: "left"
                            },
                            {
                                element: "#appElements",
                                title: "Getting Started With Drag And Drop",
                                content: "Select an Element Drag on the Canvas To Start Designing.<br /><a href='#' onclick='openGif(\"draganddrop\")'>check how it works</a>",
                                placement: "left"
                            },
                            {
                                element: "#formDesignerLogo",
                                title: "Form Designer",
                                content: "Enjoy. You Are Ready To Go.",
                                placement: "bottom"
                            }
                        ]
                    });
                    //$('[data-toggle="tooltip"]').tooltip();
                    showTour = $('#tourRequest').prop("checked");
                    $("#mySelectForm").modal("hide");
                    enableGridster();
                    if (BusinessProcessFlow) {
                        var defaultTabObject = {
                            tabId: "0"
                        };
                        for (var index in TabProperties) {
                            defaultTabObject[TabProperties[index]] = "";
                        }
                        defaultTabObject["label"] = "Stage 0";
                        Tabs.push(defaultTabObject);
                        addTab();
                    }
                    //$("#pageTab").children().removeClass("active").first().addClass("active")
                    $('#pageTab a:first').tab('show');
                    $("#transactionInfoLink").click(function () {
                        $("#myTransactions").modal("show");
                    });
                    $("#hierarchyInfoLink").click(function () {
                        $("#myHierarchy").modal("show");
                    });
                    $("#addTab").click(addTab);
                    if (showTour) {
                        // Initialize the tour
                        tour.init();
                        // Start the tour
                        tour.restart(true);
                    }
                },
                error: function (data) {
                    $('#mySelectFormLoader').html("<span style=\"color:red\">Something Went Wrong. Please Try Again.</span>");
                    console.dir(data);
                }
            })
            //     },
            //     error: function (data) {
            //         alert("Something Went Wrong while Fetching Grids From Server");
            //         console.log(data);
            //     }
            // });
            break;

    }
    maintainPopover();
}

function toggleCrmMenu() {
    $("#crmElementsDiv").toggle();
    $("#crmPtenElements").toggle();
}

function toggleSalesforceMenu() {
    $("#salesforceElementsDiv").toggle();
    $("#salesforcePtenElements").toggle();
}

function toggleSqlMenu() {
    $("#sqlElementsDiv").toggle();
    $("#sqlPtenElements").toggle();
}

function searchTable(inputVal, id) {
    var table = $(id);
    table.find('tr').not(".used").each(function (index, row) {
        var allCells = $(row).find('td');
        if (allCells.length > 0) {
            var found = false;
            allCells.each(function (index, td) {
                var regExp = new RegExp(inputVal, 'i');
                if (regExp.test($(td).children().text())) {
                    found = true;
                    return false;
                }
            });
            if (found == true) $(row).css("display", "block");
            else $(row).css("display", "none");
        }
    });
}

function removeElement(element) {
    if (confirm("Are you sure you want to remove element?") == true) {
        var value = $(element).closest("div[id^='page_']").prop("id").split('_')[1];
        gridster[value].remove_widget($(element).parent().parent().parent());
        var elementId = $(element).parent().parent().prop("id");
        $("#" + FormElementState[elementId.split("_")[1]].name).closest("tr").removeClass("used");
        FormElementState[elementId.split("_")[1]] = null;
    }
}

function getMaxLayoutCount(gridsterArray) {
    var maxLayout = 0;
    for (var index in gridsterArray) {
        var element = gridsterArray[index];
        if (element != null) {
            if (!(getFormElement(element["id"]).type.toLowerCase() == "separator" || getFormElement(element["id"]).type.toLowerCase() == "grid")) {
                var elementLayout = element.col + (element.size_x - 1)
                if (elementLayout > maxLayout) {
                    maxLayout = elementLayout;
                }
            }
        }
    }
    if (gridsterArray.length != 0 && maxLayout == 0) {
        maxLayout = 1;
    }
    return maxLayout;
}

function slideMenu(obj) {
    if ($(".Basic").css("display") == "none") {
        $(obj).text("More Properties");
    } else {
        $(obj).text("Basic Properties");
    }
    $(".MoreElements").toggle();
    $(".Basic").toggle();
}

function getFormElement(id) {
    for (var index in FormElementState) {
        if (FormElementState[index] != null) {
            if (FormElementState[index]["ElementId"] == id) {
                return FormElementState[index];
            }
        }
    }
}

function setFormElement(id, object) {
    for (var index in FormElementState) {
        if (FormElementState[index] != null)
            if (FormElementState[index]["ElementId"] == id) {
                FormElementState[index] = object;
                return true;
            }
    }
    return false;
}

function populateElement() {
    var elementId = $(this).parent().parent().prop("id").split("_")[1];
    var jsonObject = getFormElement(elementId);
    if (jsonObject.type.toLowerCase() == "grid" || jsonObject.type.toLowerCase() == "separator") {
        $("[data-key=isHidden]").parent().addClass("hide");
        if (Form.FormType.toLowerCase() == "sql") {
            $("[data-key=name]").parent().addClass("hide");
        }
        $(".grid-hide").css("display", "none");
        $(".file-show").addClass("hide");
        $(".file-hide").removeClass("hide");
    } else {
        if (jsonObject.type.toLowerCase() == "file") {
            $(".file-show").removeClass("hide");
            $(".file-hide").addClass("hide");
        } else {
            $(".file-show").addClass("hide");
            $(".file-hide").removeClass("hide");
        }
        $("[data-key=isHidden]").parent().removeClass("hide");
        if (Form.FormType.toLowerCase() == "sql") {
            $("[data-key=name]").parent().removeClass("hide");
        }
        $(".grid-hide").css("display", "block");
    }
    //Every grid has Autocomplete(Dropdown Select) menu. so for grid bind autocomplete
    if (jsonObject.type.toLowerCase() == "grid") {
        $("[data-key=label]").prop("readonly", "readonly");
        setTimeout(function () {
            $("[data-key=label]").last().bind("keydown", function (event) {
                if (event.keyCode === $.ui.keyCode.TAB &&
                    $(this).autocomplete("instance").menu.active) {
                    event.preventDefault();
                }
            }).on('focus', function (event) {
                $(this).autocomplete("search", "");;
            }).on('click', function (event) {
                $(this).autocomplete("search", "");;
            }).autocomplete({
                minLength: 0,
                source: Form.Grids,
                select: function (event, ui) {
                    var key = ui.item.Key
                    var value = ui.item.Value;
                    $(this).val(value);
                    $("[data-key=name]").last().val(key);
                    event.preventDefault();
                }
            }).autocomplete("instance")._renderItem = function (ul, item) {
                return $("<li>").append("<a>" + item.Value + "</a>").appendTo(ul);
            };
        }, 1000);

    } else {
        //Remove readonly if applied by grid object(i.e Grid Element Menu is opened Before)
        $("[data-key=label]").removeAttr("readonly");
    }
    $("[data-key=ElementId]").val(jsonObject.ElementId);
    for (var index in TextBoxes) {
        if (TextBoxes[index].toLowerCase() == "jsonurl") {
            var jsonValue = jsonObject[TextBoxes[index]].split("/");
            $("[data-key=" + TextBoxes[index] + "]").attr("value", jsonValue[jsonValue.length - 1]);
        } else {
            $("[data-key=" + TextBoxes[index] + "]").attr("value", jsonObject[TextBoxes[index]]);
        }
    }
    for (var index in Select) {
        $("[data-key=" + Select[index] + "] option").each(function () {
            if (jsonObject[Select[index]] == "") {
                if ($(this).text().toLowerCase() == "none") {
                    $(this).attr("selected", "selected");
                } else {
                    $(this).removeAttr("selected");
                }
            } else {
                if ($(this).text().toLowerCase() == jsonObject[Select[index]].toLowerCase()) {
                    $(this).attr("selected", "selected");
                } else {
                    $(this).removeAttr("selected");
                }

            }
        });
    }
    var customOption = "";
    $.each(jsonObject, function (i, v) {
        if ($.inArray(i, TextBoxes) == -1) {
            if ($.inArray(i, Select) == -1) {
                if ($.inArray(i, Internals) == -1) {
                    if (!(i.toLowerCase() == "elementid" || i.toLowerCase() == "type" || i.toLowerCase() == "colspan" || i.toLowerCase() == "displayseq" || i.toLowerCase() == "rownum")) {
                        if (v != "") {
                            customOption += i + "=" + v + ";";
                        }
                    }
                }
            }
        }
    });
    $("[data-key=customOption]").text(customOption);
    if (jsonObject.type.toLowerCase() == "hidden") {
        $("[data-key=isHidden] option").each(function () {
            if ($(this).text().toLowerCase() == "true") {
                $(this).attr("selected", "selected");
            } else {
                $(this).removeAttr("selected");
            }
        });
    } else {
        $("[data-key=isHidden] option").each(function () {
            if ($(this).text().toLowerCase() == "false") {
                $(this).attr("selected", "selected");
            } else {
                $(this).removeAttr("selected");
            }
        });
    }
    return $('#ElementMenu').html();
}

function addJsFunction(obj) {
    if ($(obj).val().toLowerCase() == "edit") {
        $("[name=jsfunction]").val("Edit(this)");
    } else if ($(obj).val().toLowerCase() == "new") {
        $("[name=jsfunction]").val("Add(this)");
    } else if ($(obj).val().toLowerCase() == "hybrid") {
        $("[name=jsfunction]").val("Hybrid(this)");
    }
}

function saveState(obj) {

    var elementId = $(obj).parent().parent().find("[data-key=ElementId]").val();
    var jsonObject = getFormElement(elementId);
    //Remove Previous custom Attribute value if any.
    $.each(jsonObject, function (i, v) {
        if ($.inArray(i, TextBoxes) == -1) {
            if ($.inArray(i, Select) == -1) {
                if (!(i.toLowerCase() == "elementid" || i.toLowerCase() == "type" || i.toLowerCase() == "colspan" || i.toLowerCase() == "displayseq" || i.toLowerCase() == "rownum")) {
                    if (v != "") {
                        jsonObject[i] = "";
                    }
                }
            }
        }
    });
    if ($(obj).parent().parent().find("[data-key=customOption]").val() != "") {
        var valueSet = $(obj).parent().parent().find("[data-key=customOption]").val().split(";");
        for (var index in valueSet) {
            var data = valueSet[index];
            if (data != "" && data != "\n") {
                var kv = data.split("=");
                if (kv.length > 1) {
                    jsonObject[kv[0]] = kv[1];
                } else {
                    alert("Custom Values are not in proper Format");
                    return false;
                }
            }
        }
    }
    if (jsonObject.type.toLowerCase() == "grid") {
        jsonObject.name = $(obj).parent().parent().find("[data-key=name]").val();
    }
    if (!(jsonObject.type.toLowerCase() == "grid" || jsonObject.type.toLowerCase() == "separator")) {
        // if ($("[data-key=isHidden]").last().val().toLowerCase() == "true") {
        //     if (jsonObject.type.toLowerCase() != "hidden") {
        //         //hide this
        //         $("#dropElementDiv_" + elementId).find("label").siblings().last().remove();
        //         $("#dropElementDiv_" + elementId).find("label").after("<span><font color=\"red\">Hidden</font></span>");
        //         jsonObject.type = "Hidden";
        //         jsonObject.dataType = "";
        //         jsonObject.onClick = "";
        //     }
        // }
        //else {
        $("#dropElementDiv_" + elementId).find("label").siblings().last().remove();
        var htmlElement = "";
        switch (Form.FormType.toLowerCase()) {
            case "crm":
                for (var index in MSCRM.Attributes) {
                    if (MSCRM.Attributes[index].LogicalName == jsonObject.name) {
                        var entityType = MSCRM.Attributes[index].AttributeTypeName.Value.toLowerCase();
                        if (entityType == "lookuptype" || entityType == "ownertype" || entityType == "customertype") {
                            jsonObject.type = "TextBox";
                            jsonObject.dataType = "lookup";
                            jsonObject.target = MSCRM.Attributes[index].Targets[0];
                            htmlElement += "<div class=\"lookup-div\"><input type=\"text\"><a class=\"lookupClick\"><img src=\"/Content/FormDesignerUpgraded/images/search_mag.png\" id=\"lkserarchbutton\"></a></div>";
                        } else if (entityType == "picklisttype" || entityType == "booleantype") {
                            jsonObject.type = "DropDown";
                            jsonObject.populateEvent = "onLoad";
                            jsonObject.target = entityType;
                            htmlElement += "<select></select>";
                        } else if (entityType == "memotype") {
                            jsonObject.type = "Textarea";
                            htmlElement += "<textarea></textarea>";
                        } else {
                            jsonObject.type = "TextBox";
                            htmlElement += "<input type='text' />";
                            if (entityType == "datetimetype") {
                                jsonObject.dataType = "date";
                                jsonObject.target = entityType;
                            } else if (entityType == "moneytype" || entityType == "integertype") {
                                jsonObject.dataType = "float";
                                jsonObject.target = entityType;
                            }
                        }
                    }
                }
                break;
            case "salesforce":
                for (var index in SALESFORCE.Attributes) {
                    if (SALESFORCE.Attributes[index].name == jsonObject.name) {
                        var entityType = SALESFORCE.Attributes[index].type;
                        switch (entityType) {
                            case SALESFORCE.FieldTypeEnum.reference:
                                jsonObject.type = "TextBox";
                                jsonObject.dataType = "lookup";
                                jsonObject.target = SALESFORCE.Attributes[index].referenceTo[0];
                                htmlElement += "<div class=\"lookup-div\"><input type=\"text\"><a class=\"lookupClick\"><img src=\"/Content/FormDesignerUpgraded/images/search_mag.png\" id=\"lkserarchbutton\"></a></div>";
                                break;
                            case SALESFORCE.FieldTypeEnum.picklist:
                                jsonObject.type = "DropDown";
                                jsonObject.populateEvent = "onLoad";
                                //jsonElement.target = entityType;
                                htmlElement += "<select></select>";
                                break;
                            case SALESFORCE.FieldTypeEnum.boolean:
                                jsonObject.type = "DropDown";
                                jsonObject.populateEvent = "onLoad";
                                //jsonElement.target = entityType;
                                htmlElement += "<select></select>";
                                break;
                                //case SALESFORCE.FieldTypeEnum.address:
                                //    break;
                            case SALESFORCE.FieldTypeEnum.date:
                                jsonObject.type = "TextBox";
                                htmlElement += "<input type='date' />";
                                jsonObject.dataType = "date";
                                break;
                            case SALESFORCE.FieldTypeEnum.textarea:
                                jsonObject.type = "Textarea";
                                htmlElement += "<textarea></textarea>";
                                break;
                            default:
                                jsonObject.type = "TextBox";
                                htmlElement += "<input type='text' />";
                                break;
                        }

                    }
                }
                break;
            case "sql":
                switch (jsonObject.type.toLowerCase()) {
                    case "textbox":
                        htmlElement += "<input type='text' />";
                        break;
                    case "checkbox":
                        htmlElement += "<input type='checkbox' />";
                        break;
                    case "dropdown":
                        htmlElement += "<select></select>";
                        break;
                    case "textarea":
                        htmlElement += "<textarea></textarea>";
                        break;
                    case "button":
                        htmlElement += "<button class=\"btn btn-primary\">Button</button>";
                        break;
                    case "file":
                        htmlElement += "<button class=\"btn btn-primary\">Browse</button>";
                        break;
                    case "password":
                        htmlElement += "<input type=\"password\" />";
                        break;
                    case "html":
                        htmlElement += "<i class=\"fa fa-html5\"></i>";
                        break;
                    default:
                        jsonObject.type = "TextBox";
                        htmlElement += "<input type='text' />";
                        break;
                }
                break;


        }
        $("#dropElementDiv_" + elementId).find("label").after(htmlElement);
        //}
    }
    $("#dropElementDiv_" + elementId).find("label").text($(obj).parent().parent().find("[data-key=label]").val());
    $("#dropElementDiv_" + elementId).find("label").attr("title", $(obj).parent().parent().find("[data-key=label]").val());
    if ($(obj).parent().parent().find("[data-key=required]").val().toLowerCase() == "true")
        $("#dropElementDiv_" + elementId).find("label").append("<font color=\"red\">*</font>");
    for (var index in TextBoxes) {
        if (TextBoxes[index].toLowerCase() == "jsonurl" && jsonObject.type.toLowerCase() == "dropdown") {
            jsonObject[TextBoxes[index]] = "/Home/GetDropDownJson/" + $(obj).parent().parent().find("[data-key=" + TextBoxes[index] + "]").val();
        } else {
            jsonObject[TextBoxes[index]] = $(obj).parent().parent().find("[data-key=" + TextBoxes[index] + "]").val();
        }
    }
    for (var index in Select) {
        jsonObject[Select[index]] = $(obj).parent().parent().find("[data-key=" + Select[index] + "]").val().toLowerCase() == "none" ? "" : $(obj).parent().parent().find("[data-key=" + Select[index] + "]").val().toLowerCase();
    }
    setFormElement(elementId, jsonObject);
    //alert("saved");
    $.notify({
        icon: 'glyphicon glyphicon-floppy-saved',
        title: '<strong>Saved</strong>',
        message: 'Element Details Updated'
    }, {
        type: 'success'
    });
    closePopover();
    return false;
}

function closePopover() {
    $('[data-toggle="popover"]').popover('hide');
}

function showPreview() {
    var rows = gridster.get_highest_occupied_cell().row;
    var widgets = gridster.serialize();
    //var maxColumnLayout = gridster.get_highest_occupied_cell().col;
    var maxColumnLayout = getMaxLayoutCount(widgets);
    var displaySeq = 0;
    var FinalArray = [];
    var improperUi = false;
    var html = '<div class="toppad" style="margin-top:24px;"><table border="0" cellpadding="5" cellspacing="0" align="left" width="100%"><tr><td height="35" align="left" valign="top" class="x-panel-header-text-default"><label>' + document.forms.FormDetails.title.value + '</label>&nbsp;&nbsp;<div style="display:inline-block;text-transform:none;"><sub><i class="fa fa-ellipsis-h"></i></sub></div></td></tr></table></div>';
    html += '<div class="formtabBox"><table class="formobx" border="0" cellpadding="5" cellspacing="0" align="left" width="100%">';
    //Foreach row
    for (var i = 0; i < rows; i++) {
        var row = [];
        //push all the widgets in row array
        for (var index in widgets) {
            if (widgets[index].row == (i + 1)) {
                row.push(widgets[index]);
            }
        }
        //sort widget array to arrange widgets in columns
        row.sort(function (a, b) {
            return parseInt(a.col) - parseInt(b.col);
        });
        var column = 0;
        //Check if row is in proper order.
        if (!improperUi) {
            for (var index in row) {
                column += row[index].size_x;
            }
            if (column != maxColumnLayout) {
                improperUi = confirm("Improper Form. Do you wish to continue. This could result in improper Layout of Form");
            }
        }
        html += '<tbody><tr>';
        for (var index in row) {
            var element = row[index];
            var json = FormElementState[element.id];
            if (element.size_x != 1)
                json.colSpan = (element.size_x);
            json.displaySeq = displaySeq;
            displaySeq++;
            FinalArray.push(json);
            if (!(json.colSpan === undefined)) {
                html += '<td class="lpad" colspan="' + json.colSpan + '">';
            } else {
                html += '<td class="lpad" colspan="1">';
            }
            switch (json.type.toLowerCase()) {
                case "separator":
                    html += '<div class="subbrd Separator"><label>' + json.label + '</label></div>';
                    break;
                case "textbox":
                    switch (json.dataType.toLowerCase()) {
                        case "date":
                            html += '<div class="lefttoplable"><label>' + json.label + '</label>' + (json.required == "true" ? '<strong class="field-validation-error">*</strong></div>' : '</div>') + '<div class="rightbtmcontrol"><input type="date" value="" class="date inputdate' + (json.required == "true" ? ' required' : '') + '" placeholder="' + json.label + '"></div>';
                            break;
                        case "lookup":
                            html += '<div class="lefttoplable"><label>' + json.label + '</label>' + (json.required == "true" ? '<strong class="field-validation-error">*</strong></div>' : '</div>') + '<div class="rightbtmcontrol"><div class="lookup-div"><input type="text"class="inputtxt' + (json.required == "true" ? ' required' : '') + '" value=""><a class="lookupClick"><img src="/Content/FormDesignerUpgraded/images/search_mag.png" id="lkserarchbutton"></a></div></div>';
                            break;
                        default:
                            html += '<div class="lefttoplable"><label>' + json.label + '</label>' + (json.required == "true" ? '<strong class="field-validation-error">*</strong></div>' : '</div>') + '<div class="rightbtmcontrol"><input type="text" value="" class="inputtxt' + (json.required == "true" ? ' required' : '') + '" placeholder="' + json.label + '"></div>';
                            break;
                    }
                    break;
                case "dropdown":
                    html += '<div class="lefttoplable"><div style="display: block;"><label>' + json.label + '</label>' + (json.required == "true" ? '<strong class="field-validation-error">*</strong></div>' : '</div>') + '</div>' + '<div class="rightbtmcontrol"><div style="display: block;"><select class="dropdownInput inputtxt' + (json.required == "true" ? ' required' : '') + '" style=" cursor:pointer;"></select></div><div style="display: none;"></div></div>';
                    break;
                case "grid":
                    break;

            }
            html += "</td>";
        }
        html += "</tr></tbody>";

    }
    html += "</table></div>";
    $.window({
        title: "Form Preview",
        content: html,
        draggable: false,
        resizable: false,
        maximizable: false,
        minimizable: false,
        showModal: true,
        width: $("body").width(),
        height: $("body").height()
    });
}

function submitForm() {
    try {
        let style = `<style>${finalCSS}</style>`;
        let script = `<script>${finalScript}</script>`;
        MaxLayoutCount = 0;
        if (!(gridster.length === undefined)) {

            $("[id^=tabText_]").each(function (index, length) {
                var TabId = $(this).prop("id").split("_")[1];
                var layoutcount = getMaxLayoutCount(gridster[TabId].serialize());
                if (MaxLayoutCount < layoutcount) {
                    MaxLayoutCount = layoutcount;
                }
            });
        } else {
            MaxLayoutCount = getMaxLayoutCount(gridster.serialize());
        }
        let layout = convertToStringNumber(MaxLayoutCount);
        var contextXml = $.parseXML("<QuickForm />");
        formDetailsLoad(null);
        var contextXML = generateFormElements(contextXml);
        let formTitle = `<div class='form-title' mode='add'>Add ${Form.title}</div><div class='form-title' mode='edit'>Edit ${Form.title}</div>`;
        let Template = `${style}\n<form id='listForm'>\n<div class='form-body' layout='${layout}' list-name='${Form['list-name']}' managePermission='${Form['managePermission']}' column-name='${Form['column-name']}' data-showFormActions='${Form['data-showFormActions']}' ${Form['validate'] == true && 'validate' || ''}>\n${formTitle}\n${contextXML}\n</div>\n</form>\n${script}`;
        let token = sessionStorage.getItem('AccessToken');
        if (sessionStorage.getItem('EditFormId')) {
            let {
                Template:tempBody,
                ...rest
            } = JSON.parse(sessionStorage.getItem('EditFormData'));
            $.ajax({
                    url: `${window.parent.hostURL}/svc/api/Templates`,
                    method: 'POST',
                    data: JSON.stringify({
                        Template,
                        ...rest
                    }),
                    dataType: "json",
                    contentType: 'application/json',
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                })
                .then(() => alert('Form updated successfully.'))
                .fail((error) => {
                })
        } else {
            let d = new Date();
            $.ajax({
                    url: `${window.parent.hostURL}/svc/api/Templates`,
                    method: 'POST',
                    data: JSON.stringify({
                        Template,
                        Name: contentName,
                        Version: 1,
                        Type: "Form"
                    }),
                    contentType: 'application/json',
                    dataType: "json",
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                })
                .then(() => alert('Form saved successfully.'))
        }
        // $("#submitSecondStep").removeClass("disabled").addClass("active");
        // generateTransactionXML(contextXML);
    } catch (exception) {
        $.notify({
            icon: 'glyphicon glyphicon-alert',
            title: '<strong>Error</strong>',
            message: exception
        }, {
            type: 'danger'
        });
        $("#mySubmit").modal('hide');
    }
}

function verifyForm() {
    var totalElements = 0;
    if (Form.FormType.toLowerCase() == "salesforce" || Form.FormType.toLowerCase() == "crm") {
        $(".required-attr").closest("tr").each(function () {
            if ($(this).hasClass("used") == false) {
                throw "All required properties are not used in form.";
            }
        });
    }
    var tabsArray = [];
    var elements = [];
    $("[id^=tabText_]").each(function (index, length) {
        var TabId = $(this).prop("id").split("_")[1];
        var grid = gridster[TabId].serialize();
        if (grid.length == 0) {
            if (BusinessProcessFlow) {
                throw "Cannot submit form with blank stage";
            } else {
                throw "Cannot submit form with blank tabs";
            }
        }
        if (BusinessProcessFlow) {
            tabsArray.push(Tabs[TabId]["label"].replace(/ /g, ""));
            for (var index in Tabs[TabId]) {
                if (index != "tabId") {
                    if (Tabs[TabId][index] === undefined || Tabs[TabId][index] == "") {
                        throw Tabs[TabId]["label"] + " stage values are not populated.";
                    }
                    if (index != "tabId" && index != "label") {
                        var transFound = false;
                        for (var transIndex in oldFormDesigner.Transactions) {
                            if (oldFormDesigner.Transactions[transIndex]["Attributes"]["id"] == Tabs[TabId][index]) {
                                transFound = true;
                                break;
                            }
                        }
                        if (!transFound) {
                            throw Tabs[TabId]["label"] + " transaction not found.";
                        }
                    }
                }
            }
            if (Form.getactivestage == "") {
                throw "<strong>Get Active Stage</strong> transaction cannot be blank for business process flow";
            }
            if (Form.setactivestage == "") {
                throw "<strong>Set Active Stage</strong> transaction cannot be blank for business process flow";
            }
            if (Form.populateEntityId == "") {
                throw "<strong>Populate Entity Id</strong> cannot be blank for business process flow";
            }
        }
        $(grid).each(function (i, l) {
            if (FormElementState[$(this).attr("id")] != null) {
                if (FormElementState[$(this).attr("id")].type.toLowerCase() == "grid") {
                    if (FormElementState[$(this).attr("id")].name == "") {
                        throw "All grids are not populated. Please verify grid labeled as <strong>" + FormElementState[$(this).attr("id")].label + "</strong>";
                    }
                }
                if (Form.FormType.toLowerCase() == "sql") {
                    if (FormElementState[$(this).attr("id")].type.toLowerCase() == "dropdown") {
                        if (FormElementState[$(this).attr("id")].jsonUrl == "") {
                            throw "All dropdown transactions are not added. Please verify <strong>Query</strong> of dropdown labeled as <strong>" + FormElementState[$(this).attr("id")].label + "</strong>";
                        }
                    }
                    //condition to check sql seq javascript yield true if u compare 0=="".
                    if ((FormElementState[$(this).attr("id")].sqlSeq === "" || isNaN(FormElementState[$(this).attr("id")].sqlSeq))) {
                        if (!(FormElementState[$(this).attr("id")].type.toLowerCase() == "separator" || FormElementState[$(this).attr("id")].type.toLowerCase() == "grid")) {
                            throw "Invalid sql sequence in element labeled as <strong>" + FormElementState[$(this).attr("id")].label + "</strong>";
                        }
                    } else {
                        elements.push(FormElementState[$(this).attr("id")].sqlSeq);
                    }

                    if ((FormElementState[$(this).attr("id")].sqlSeq.trim() == "0" && BusinessProcessFlow)) {
                        throw "Business process flow cannot use reserved sql sequence 0";
                    }
                    if (FormElementState[$(this).attr("id")].name == "") {
                        throw "Element name cannot be blank. Please check element labeled as <strong>" + FormElementState[$(this).attr("id")].label + "</strong>";
                    }
                }
            }
            totalElements++;
        });
    });
    if (BusinessProcessFlow) {
        var sorted_arr = tabsArray.slice().sort();
        var results = [];
        for (var i = 0; i < tabsArray.length - 1; i++) {
            if (sorted_arr[i + 1] == sorted_arr[i]) {
                results.push(sorted_arr[i]);
            }
        }
        if (results.length) {
            throw "Two stage cannot have same label";
        }

    }
    if (Form.type.toLowerCase() == "hybrid" && !BusinessProcessFlow && Form.FormType.toLowerCase() == "sql") {
        if (Form.insertTransaction == "") {
            throw "Form <strong>Insert Transaction</strong> is required for hybrid forms.";
        }
        if (Form.updateTransaction == "") {
            throw "Form <strong>Update Transaction</strong> is required for hybrid forms.";
        }
        if (Form.populateEntityId == "") {
            throw "<strong>Populate Entity Id</strong> cannot be blank for hybrid forms.";
        }
    }
    if (Form.FormType.toLowerCase() == "sql") {
        var sorted_arr = elements.slice().sort();
        var results = [];
        for (var i = 0; i < elements.length - 1; i++) {
            if (sorted_arr[i + 1] == sorted_arr[i]) {
                results.push(sorted_arr[i]);
            }
        }
        if (results.length) {
            throw "Two elements can't have same sql sequence.";
        }
        //No Transaction Added
        var transactionFound = false;
        //Transaction Can Be Null in array.
        for (var index in oldFormDesigner.Transactions) {
            if (oldFormDesigner.Transactions[index] != null) {
                transactionFound = true;
                break;
            }
        }
        var hierarchyFound = false;
        for (var index in oldFormDesigner.Hierarchies) {
            if (oldFormDesigner.Hierarchies[index] != null) {
                hierarchyFound = true;
                break;
            }
        }
        if (hierarchyFound && !transactionFound) {
            throw "Batch cannot exsists without query";
        }
        var insertTransFound = false;
        var updateTransFound = false;
        var setActiveTransFound = false;
        var getActiveTransFound = false;
        var transIdFound = false;
        var populateEntityIdFound = false;
        for (var index in oldFormDesigner.Transactions) {
            if (oldFormDesigner.Transactions[index] != null) {
                //if (oldFormDesigner.Transactions[index]["Attributes"]["id"] == Form["setactivestage"]) {
                //    setActiveTransFound = true;
                //}
                //switch (oldFormDesigner.Transactions[index]["Attributes"]["id"]) {
                //    case Form["setactivestage"]:
                //        setActiveTransFound = true;
                //        break;
                //    case Form["getactivestage"]:
                //        getActiveTransFound = true;
                //        break;
                //    case Form["updateTransaction"]:
                //        updateTransFound = true;
                //        break;
                //    case Form["insertTransaction"]:
                //        insertTransFound = true;
                //        break;
                //    case Form["transactionId"]:
                //        transIdFound = true;
                //        break;
                //}
                if (oldFormDesigner.Transactions[index]["Attributes"]["id"] == Form["setactivestage"]) {
                    setActiveTransFound = true;
                }
                if (oldFormDesigner.Transactions[index]["Attributes"]["id"] == Form["getactivestage"]) {
                    getActiveTransFound = true;
                }
                if (oldFormDesigner.Transactions[index]["Attributes"]["id"] == Form["updateTransaction"]) {
                    updateTransFound = true;
                }
                if (oldFormDesigner.Transactions[index]["Attributes"]["id"] == Form["insertTransaction"]) {
                    insertTransFound = true;
                }
                if (oldFormDesigner.Transactions[index]["Attributes"]["id"] == Form["transactionId"]) {
                    transIdFound = true;
                }
                if (oldFormDesigner.Transactions[index]["Attributes"]["id"] == Form["populateEntityId"]) {
                    populateEntityIdFound = true;
                }
            }
        }
        if ((BusinessProcessFlow || Form.type.toLowerCase() == "hybrid") && !populateEntityIdFound) {
            throw "Invalid <strong>Populate entity transaction</strong>";
        }
        if (BusinessProcessFlow && !getActiveTransFound) {
            throw "Invalid <strong>Get active transaction</strong>";
        } else if (BusinessProcessFlow && !setActiveTransFound) {
            throw "Invalid <strong>Set active transaction</strong>";
        } else if (!BusinessProcessFlow && Form.type.toLowerCase() == "hybrid") {
            if (!insertTransFound) {
                throw "Invalid <strong>Insert transaction</strong>";
            }
            if (!updateTransFound) {
                throw "Invalid <strong>Update transaction</strong>";
            }
        } else if (!BusinessProcessFlow && Form.type.toLowerCase() != "hybrid") {
            if (!transIdFound) {
                throw "Invalid <strong>Transaction Id</strong>";
            }
        }



        //if (!transactionFound) {
        //    throw "Cannot Submit Form Transaction Not Found";
        //}
        //var transFound = false;
        //for (var index in oldFormDesigner.Transactions) {
        //    if (oldFormDesigner.Transactions[index].Attributes.id == Form.transactionId) {
        //        transFound = true;
        //    }
        //}
        //if (!transFound) {
        //    throw "Form Transaction Id Does Not Match With Any Transaction.";
        //}
    }
    if (totalElements == 0) {
        throw "Can't submit blank form";
    }
}

function generateTransactionXML(ContextString) {
    var contextXML = $.parseXML(ContextString);
    var cXML = new XMLSerializer().serializeToString(contextXML);
    var tXML = "<Transactions>";
    var primaryentity = "";
    var dbType = "";
    switch (Form.FormType.toLowerCase()) {
        case "crm":
            primaryentity = MSCRM.EntityName;
            dbType = "mscrm";
            break;
        case "salesforce":
            primaryentity = SALESFORCE.EntityName;
            dbType = "salesforce";
            break;
        case "sql":
            dbType = "mssql";
            if (oldFormDesigner != null) {
                for (var index in oldFormDesigner.Hierarchies) {
                    tXML += "<Hierarchy ";
                    for (var j in oldFormDesigner.Hierarchies[index]["Attributes"]) {
                        tXML += j + "=\"";
                        tXML += oldFormDesigner.Hierarchies[index]["Attributes"][j] + "\" ";
                    }
                    tXML += ">";
                    for (var j in oldFormDesigner.Hierarchies[index]["TransactionInfo"]) {
                        tXML += "<TransactionInfo id=\"" + oldFormDesigner.Hierarchies[index]["TransactionInfo"][j]["id"] + "\" ";
                        tXML += " seq=\"" + oldFormDesigner.Hierarchies[index]["TransactionInfo"][j]["seq"] + "\" />";
                    }
                    tXML += "</Hierarchy>";
                }
                for (var index in oldFormDesigner.Transactions) {
                    var Transaction = oldFormDesigner.Transactions[index];
                    tXML += "<Transaction ";
                    for (var j in Transaction["Attributes"]) {
                        tXML += j + "=\"" + Transaction["Attributes"][j] + "\" ";
                    }
                    tXML += ">";
                    for (var i in Transaction) {
                        if (!(i.toLowerCase() == "attributes" || i.toLowerCase() == "filters")) {
                            tXML += "<Property ";
                            tXML += "name=\"" + i + "\"";
                            tXML += " value=\"" + Transaction[i] + "\"></Property>";
                        }
                    }
                    if (Transaction["Filters"] != undefined && Transaction["Filters"] != null) {
                        tXML += "<Filters>";
                        for (var i in Transaction["Filters"]) {
                            tXML += "<Filter ";
                            for (var attr in Transaction["Filters"][i]) {
                                tXML += attr + "=\"" + Transaction["Filters"][i][attr] + "\" ";
                            }
                            tXML += "></Filter>";
                        }
                        tXML += "</Filters>";
                    }
                    tXML += "</Transaction>";
                }
                tXML += "</Transactions>";
                console.log(tXML);
                console.dir(tXML);
                var transactionFound = false;
                //Transaction Can Be Null in array.
                for (var index in oldFormDesigner.Transactions) {
                    if (oldFormDesigner.Transactions[index] != null) {
                        transactionFound = true;
                        break;
                    }
                }
                if (!transactionFound) {
                    tXML = "";
                }
            }
            break;
    }
    $.ajax({
        url: "/FormDesignerUpgraded/GenerateTransactionXML",
        method: "POST",
        data: {
            ContextXML: cXML,
            DbType: dbType,
            PrimaryEntity: primaryentity,
            JsFunction: Form.jsfunction,
            IsDialog: Form.isdialog,
            EditFormcontentId: formcontentid,
            EditFormLookupId: lookupcontentid,
            IsEditForm: isEditForm,
            SqlTransactionXML: tXML,
            IsBusinessProcessFlow: BusinessProcessFlow,
            ContentName: contentName
        },
        beforeSend: function () {
            $("#closeSubmitModal").prop("disabled", true);
        },
        success: function (data) {
            if (data) {
                $("#submitThirdStep").removeClass("disabled").addClass("complete");
                $("#submitSecondStep").removeClass("active").addClass("complete");
                $("#submitFinish").removeClass("disabled").addClass("complete");
            } else {
                alert("System Error. Please Contact System Adminstrator.");
                $("#mySubmit").modal('hide');
            }
            $("#closeSubmitModal").removeProp("disabled");
        },
        error: function (data) {
            alert("Could Not Connect To Server.");
            $("#closeSubmitModal").removeProp("disabled");
            console.log(data);
            console.dir(data);
        }
    });
}

function generateFormProperties(contentXML) {
    var isFormTypeEdit = false;
    var containsTransactionId = false;
    var containspopulateEntityId = false;
    try {
        var FormDetails = document.forms.FormDetails;
        for (felement = 0; felement < FormDetails.elements.length; felement++) {
            if (FormDetails[felement] != undefined && FormDetails[felement].value != "") {
                if (!(FormDetails[felement].name == "isdialog" || FormDetails[felement].name == "jsfunction")) {
                    if (FormDetails[felement].name == "id" || FormDetails[felement].name == "title" || FormDetails[felement].name == "cssPath" || FormDetails[felement].name == "cssClass" || FormDetails[felement].name == "height" || FormDetails[felement].name == "width") {
                        if (FormDetails[felement].name == "viewOnly") {
                            if (FormDetails[felement].selectedIndex == 0) {
                                $(contentXML).find("QuickForm").attr(FormDetails[felement].name, "true");
                            } else {
                                $(contentXML).find("QuickForm").attr(FormDetails[felement].name, "false");
                            }
                        } else {
                            $(contentXML).find("QuickForm").attr(FormDetails[felement].name, FormDetails[felement].value);
                        }
                    } else if (FormDetails[felement] != undefined && FormDetails[felement].type != "submit") {
                        if (FormDetails[felement].name.toLowerCase() == "customproperties") {
                            $.each(Form.customProperties, function (key, value) {
                                var childProperty = contentXML.createElement('Property');
                                $(childProperty).attr("name", key);
                                $(childProperty).attr("value", value);
                                contentXML.documentElement.appendChild(childProperty);
                            });
                        } else {
                            var childProperty = contentXML.createElement('Property');
                            //if (FormDetails[felement].name.toLowerCase() == "type" && FormDetails[felement].value.toLowerCase() == "hybrid") {
                            //    $(childProperty).attr("name", FormDetails[felement].name);
                            //    $(childProperty).attr("value", "Edit");
                            //}
                            //else {
                            $(childProperty).attr("name", FormDetails[felement].name);
                            $(childProperty).attr("value", FormDetails[felement].value);
                            //}
                            contentXML.documentElement.appendChild(childProperty);
                        }
                        if (FormDetails[felement].name == "type" && (FormDetails[felement].value.toLowerCase() == "edit" || FormDetails[felement].value.toLowerCase() == "hybrid")) {
                            isFormTypeEdit = true;
                        }
                    }
                    if (FormDetails[felement].name == "id" && FormDetails[felement].value == "") {
                        $(contentXML).find("QuickForm").attr(FormDetails[felement].name, guid());
                    }
                }
            }
        }
        $(contentXML).find("QuickForm").attr("cssPath", "~/Content/themes/formobx.css");
        //Add Max Column count property
        MaxLayoutCount = 0;
        //Check if its a Tabed Form(Form with tabs will have length property)
        if (!(gridster.length === undefined)) {

            $("[id^=tabText_]").each(function (index, length) {
                var TabId = $(this).prop("id").split("_")[1];
                var layoutcount = getMaxLayoutCount(gridster[TabId].serialize());
                if (MaxLayoutCount < layoutcount) {
                    MaxLayoutCount = layoutcount;
                }
            });
        } else {
            MaxLayoutCount = getMaxLayoutCount(gridster.serialize());
        }
        var childProperty = contentXML.createElement('Property');
        $(childProperty).attr("name", "layoutColumnsCount");
        $(childProperty).attr("value", MaxLayoutCount);
        contentXML.documentElement.appendChild(childProperty);

        $(contentXML).find("Property").each(function () {
            if ($(this).attr("name").toLowerCase() == "transactionid") {
                containsTransactionId = true;
            } else if ($(this).attr("name").toLowerCase() == "populateentityid") {
                containspopulateEntityId = true;
            }
        });
        if (!containsTransactionId) {
            var transactionEntity = contentXML.createElement('Property');
            $(transactionEntity).attr("name", "transactionId");
            $(transactionEntity).attr("value", "");
            contentXML.documentElement.appendChild(transactionEntity);
        }
        if (isFormTypeEdit && !containspopulateEntityId) {
            var populateEntity = contentXML.createElement('Property');
            $(populateEntity).attr("name", "populateEntityId");
            $(populateEntity).attr("value", "");
            contentXML.documentElement.appendChild(populateEntity);
        }

    } catch (e) {
        console.log(e.stack);
        alert("Something Went Wrong While Generating XML");
    }
}

function convertToStringNumber(number) {
    switch (number) {
        case 1:
            return "one";
        case 2:
            return "two";
        case 3:
            return "three";
        case 4:
            return "four";
        case 5:
            return "five";
        case 6:
            return "six";
        case 7:
            return "seven";
        case 8:
            return "eight";
        case 9:
            return "nine";
    }
}

function convertToNumber(str = "one") {
    switch (str.toLowerCase()) {
        case "one":
            return 1;
        case "two":
            return 2;
        case "three":
            return 3;
        case "four":
            return 4;
        case "five":
            return 5;
        case "six":
            return 6;
        case "seven":
            return 7;
        case "eight":
            return 8;
        case "nine":
            return 9;
    }
}


function generateFormElements(contextXml) {
    try {
        //var formElements = $.parseXML("<QuickFormElements />");
        var formElements = $.parseXML(`<div class="form-field" />`);
        switch (Form.FormType.toLowerCase()) {
            case "crm":
            case "salesforce":
            case "sql":
                var sequence = {
                    sqlSeq: 0,
                    displaySeq: 0,
                    separatorCount: TabConfigSeq,
                };
                var TotalTabs = $("[id^=tabText_]").length;
                if (TotalTabs == 1) {
                    return generateGridsterElementXML(sequence, gridster[$("[id^=tabText_]").attr("id").split("_")[1]], formElements, contextXml);
                } else {
                    $("[id^=tabText_]").each(function (index, length) {
                        var TabId = $(this).prop("id").split("_")[1];
                        var element = formElements.createElement("QuickFormElement");
                        //$(element).attr("sqlSeq", sequence.separatorCount);
                        $(element).attr("displaySeq", sequence.displaySeq);
                        $(element).attr("isFrame", "true");
                        $(element).attr("type", "Tab");
                        $(element).attr("cssClass", "");
                        $(element).attr("name", $(this).text().replace(/ /g, ""));
                        $(element).attr("label", $(this).text());
                        $(element).attr("value", "");
                        if (BusinessProcessFlow) {
                            var tabObject = getTabElement(TabId);
                            for (var index in tabObject) {
                                if (index != "tabId") {
                                    $(element).attr(index, tabObject[index]);
                                }
                            }
                        }
                        //sequence.sqlSeq++;
                        sequence.separatorCount++;
                        sequence.displaySeq++;
                        formElements.documentElement.appendChild(element);
                        //call to function to get gridster Element by id.
                        generateGridsterElementXML(sequence, gridster[TabId], formElements, contextXml);
                    });
                    var element = formElements.createElement("QuickFormElement");
                    $(element).attr("name", "EndTab");
                    $(element).attr("type", "EndTab");
                    $(element).attr("label", "End Tab");
                    $(element).attr("value", "");
                    $(element).attr("cssClass", "");
                    $(element).attr("isFrame", "true");
                    $(element).attr("sqlSeq", sequence.separatorCount);
                    $(element).attr("displaySeq", sequence.displaySeq);
                    sequence.sqlSeq++;
                    sequence.displaySeq++;
                    formElements.documentElement.appendChild(element);
                    if (Form.type.toLowerCase() == "edit") {

                    }
                }
                contextXml.documentElement.appendChild(formElements.documentElement);
                var cxml = new XMLSerializer().serializeToString(contextXml);
                //if (sequence.separatorCount > 0) {
                //    for (var i = 0; i < sequence.separatorCount; i++) {
                //        cxml = cxml.replace("{" + i + "}", sequence.sqlSeq);
                //        sequence.sqlSeq++;
                //    }
                //}
                return cxml;
                break;
        }
    } catch (e) {
        alert("Something went wrong while generating XML");
        console.dir(e);
    }
}

function addCssToJson(json) {
    switch (json.type.toLowerCase()) {
        case "textbox":
            json.cssClass = "inputtxt";
            break;
        case "dropdown":
            json.cssClass = "dropdownInput inputtxt"
            break;
        case "separator":
            json.cssClass = "subbrd";
            break;
        case "textarea":
            json.cssClass = "inputcontent";
            break;
        case "tab":
            break;
        case "password":
            json.cssClass = "inputtxt";
            break;
    }
    switch (json.dataType.toLowerCase()) {
        case "date":
            json.cssClass = json.cssClass + " date";
            break;
    }
    switch (json.required.toLowerCase()) {
        case "true":
            json.cssClass = json.cssClass + " required";
            break;
    }
}

function checkNumber(e) {
    var keynum;
    if (window.event) { // IE                   
        keynum = e.keyCode;
    } else
    if (e.which) { // Netscape/Firefox/Opera                    
        keynum = e.which;
    }
    if (isNaN(String.fromCharCode(keynum))) {
        e.target.value = 0;
        alert("Non Numberic Values Not Accepted");
        e.preventDefault();
    }
}

function capitalize(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

function getFormElementFromJSON(json) {
    switch (json.type.toLowerCase()) {
        case "textbox":
            let colspan = json['col-span'];
            json = _.omit(json, Internals);
            json = _.omitBy(json, _.isEmpty);
            let required = (json.required == 'true' || json.required == true);
            let label = json.label;
            json = _.omit(json, ['required', 'label']);
            //return  `<div class='form-field' id="${json.field}" ${colspan && `col-span="${colspan}"` || ``}><span class='field-label' type='text' field='${json.field}' required>${json.label}<label class="red"> *</label></span></div>`;
            return `<div class='form-field' id="${json.field || ""}" ${colspan && `col-span="${colspan}"` || ``}><span class='field-label'${_.map(json,(v,k)=>`${k}='${v}'`).join(" ")} ${required && `required` || ``}>${label}${required && `<label class="red"> *</label>` || ""}</span></div>`;
            break;
    }
}

function generateGridsterElementXML(sequence, gridsterObject, quickFormElementsObject, contextXml) {
    switch (Form.FormType.toLowerCase()) {
        case "crm":
        case "salesforce":
        case "sql":
            var rows = gridsterObject.get_highest_occupied_cell().row;
            var widgets = gridsterObject.serialize();
            //var maxColumnLayout = gridsterObject.get_highest_occupied_cell().col;
            var maxColumnLayout = getMaxLayoutCount(widgets);
            //var displaySeq = 0;
            //var sqlSeq = 0;
            var FinalArray = [];
            //var separatorCount = 0;
            var improperUi = false;
            //Foreach row
            for (var i = 0; i < rows; i++) {
                var row = [];
                //push all the widgets in row array
                for (var index in widgets) {
                    if (widgets[index].row == (i + 1)) {
                        row.push(widgets[index]);
                    }
                }
                //sort widget array to arrange widgets in columns(sort all widgets of a row by column position)
                row.sort(function (a, b) {
                    return parseInt(a.col) - parseInt(b.col);
                });
                var column = 0;
                //Check if row is in proper order.
                if (!improperUi) {
                    for (var index in row) {
                        column += row[index].size_x;
                    }
                    if (column != maxColumnLayout) {
                        //improperUi = confirm("Improper Form. Do you wish to continue. This could result in improper Layout of Form");
                    }
                }
                for (var index in row) {
                    var element = row[index];
                    var json = FormElementState[element.id];
                    if (element.size_x != 1)
                        //json.colSpan = (element.size_x);
                        json['col-span'] = (element.size_x);
                    if (json.type.toLowerCase() == "separator" || json.type.toLowerCase() == "grid" || json.type.toLowerCase() == "tab") {
                        //separatorCount++;
                        // json.sqlSeq = "{" + sequence.separatorCount + "}";
                        json.sqlSeq = sequence.separatorCount;
                        sequence.separatorCount++;
                    } else {
                        if (Form.FormType.toLowerCase() != "sql") {
                            json.sqlSeq = sequence.sqlSeq;
                        }
                        sequence.sqlSeq++;
                    }
                    //Give Separators and Grids MaxLayout.
                    if ($.inArray(json.type, FullLayoutElements) != -1) {
                        json['col-span'] = MaxLayoutCount;
                    }
                    json.displaySeq = sequence.displaySeq;
                    sequence.displaySeq++;
                    //addCssToJson(json);
                    json.rowNum = i;
                    FinalArray.push(json);
                }

            }
            let elements = "";
            for (var index in FinalArray) {
                var element = quickFormElementsObject.createElement("div");
                // for (var data in FinalArray[index]) {
                //     if ($.inArray(data, RequiredQuickFormElements) != -1) {
                //         $(element).attr(data, FinalArray[index][data]);
                //     }
                //     else if (FinalArray[index][data] != "") {
                //         //ElementId does not Exsists in Array
                //         if (data != "ElementId") {
                //             $(element).attr(data, FinalArray[index][data]);
                //         }
                //     }
                //     let span = element.createElement('span');

                //     element.documentElement.appendChild(span);
                // }
                elements += getFormElementFromJSON(FinalArray[index]);
                //quickFormElementsObject.documentElement.appendChild(element);
            }
            return `<div class='list-form'>${elements}</div>`;
            break;
    }
}
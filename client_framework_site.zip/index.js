let hostURLProduction = window.location.origin;
let testApplicationHost = "https://eventwnnwx.test.bitpod.io";
let hostURL = window.location.hostname == "localhost" ? testApplicationHost : hostURLProduction;
let authState = {};

const cssLinks = [
  "https://fonts.googleapis.com/css?family=Open+Sans:300",
  "https://cdnjs.cloudflare.com/ajax/libs/chosen/1.4.2/chosen.css",
  "https://hayageek.github.io/jQuery-Upload-File/4.0.11/uploadfile.css",
  "https://propeller.in/components/datetimepicker/css/bootstrap-datetimepicker.css",
  "https://propeller.in/components/datetimepicker/css/pmd-datetimepicker.css",
  "https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.8.2/fullcalendar.min.css",
  "https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote.css"
]
const themeCSS =[
  {url:"CSS/custom/style-lavender.css",title:"lavender"},
  {url:"CSS/custom/style-red.css",title:"red"},
  {url:"CSS/custom/style-green.css",title:"green"},
  {url:"CSS/custom/style-blue.css",title:"blue"},
  {url:"CSS/custom/style-orange.css",title:"black-white"},
  {url:"CSS/custom/style-maroon.css",title:"maroon"},
  {url:"CSS/custom/style-yellow.css",title:"yellow"},
  {url:"CSS/custom/style-dark.css",title:"dark"}
]
const cssDependendancies = [
  "https://fonts.googleapis.com/css?family=Roboto",
  "https://res.cloudinary.com/mytestlogo/raw/upload/v1573628681/Icons/style.css",
  "https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css",
  "https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css",
  "https://fonts.googleapis.com/icon?family=Material+Icons",
  "https://propeller.in/components/icons/css/google-icons.css",
  "https://cdnjs.cloudflare.com/ajax/libs/izimodal/1.5.1/css/iziModal.min.css",
]


const unauthrizedMessage = "Access not granted, contact support to request access.";
const resourceNotFound = "Resource not found";

// import "./src/CSS/custom/loginPage.css";
// import "./src/CSS/custom/burgerNav.css";
// import "./src/CSS/custom/materialstyle.css";
// import "./src/CSS/lib/bootstrap-custom.css";
// import "./src/CSS/custom/base.css";
// import "./src/CSS/custom/pagination.css";
const landingPageWrapper = '<div class="container landingPage"> <div class="row"><div class="ld-apps"><span id="p10">p10</span><span id="Apps"> Apps</span></div></div><div id="reactTiles"></div></div>';

if(window.location.hostname == "localhost"){
    window["$config"] = {
        oauth: {
            flow: "token",
            loginUrl: "https://login.bitpod.io/auth/connect/authorize",
            logoutUrl: "https://login.bitpod.io/auth/connect/endsession",
            tokenUrl: "https://login.bitpod.io/auth/connect/token",
            userInfoUrl: "https://login.bitpod.io/auth/connect/userinfo",
            clientId: "hnpwpvEdHY0rWAmmxQtU0GftaXe0g4qsZ6QiKrEmV4w=",
            clientSecret: "wHldkTtmE/bmJI4XcSpizYK88veVMjl2SosD4E1y8H8=",
            scope: ['baas','notification'],
            logoutRedirectUrl: window.location.origin.toString() + "/" ,
            loginRedirectUrl: window.location.origin.toString() + "/"
        },
        ps: {
            serviceUrl: "https://devps.bitpod.io"
        }
    }
}

/*
    plugin name: router
    jquery plugin to handle routes with both hash and push state
    why? why another routing plugin? because i couldnt find one that handles both hash and pushstate
    created by 24hr // camilo.tapia
    author twitter: camilo.tapia
  
    Copyright 2011  camilo tapia // 24hr (email : camilo.tapia@gmail.com)
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as 
    published by the Free Software Foundation.
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
 

(function($){
    
    var hasPushState = (history && history.pushState);    
    var hasHashState = !hasPushState && ("onhashchange" in window) && false;
    var router = {};
    var routeList = [];
    var eventAdded = false;
    var currentUsedUrl = location.href; //used for ie to hold the current url
    var firstRoute = true;
    
    // hold the latest route that was activated
    router.currentId = "";
    router.currentParameters = {};
    
    router.capabilities = {
        hash: hasHashState,
        pushState: hasPushState,
        timer: !hasHashState && !hasPushState
    };
    
    // reset all routes
    router.reset = function()
    {
        var router = {};
        var routeList = [];
        router.currentId = "";
        router.currentParameters = {};
    }
 
    router.add = function(route, id, callback)
    {
        // if we only get a route and a callback, we switch the arguments
        if (typeof id == "function")
        {
            callback = id;
           // delete id;
        }
        
        var isRegExp = typeof route == "object";
        
        if (!isRegExp)
        {
            
            // remove the last slash to unifiy all routes
            if (route.lastIndexOf("/") == route.length - 1)
            {
                route = route.substring(0, route.length - 1);
            }
            
            // if the routes where created with an absolute url ,we have to remove the absolut part anyway, since we cant change that much
            route = route.replace(location.protocol + "//", "").replace(location.hostname, "");
        }

        var routeItem = {
            route: route,
            callback: callback,
            type: isRegExp ? "regexp" : "string",
            id: id
        }

        routeList.push(routeItem);
        
        // we add the event listener after the first route is added so that we dont need to listen to events in vain
        if (!eventAdded)
        {
            bindStateEvents();
        }
    };
    
    function bindStateEvents()
    {
        eventAdded = true;
        
        // default value telling router that we havent replaced the url from a hash. yet.
        router.fromHash = false;

        
        if (hasPushState)
        {
            // if we get a request with a qualified hash (ie it begins with #!)
            if (location.hash.indexOf("#!/") === 0)
            {
                // replace the state
                var url = location.pathname + location.hash.replace(/^#!\//gi, "");
                history.replaceState({}, "", url);
                
                // this flag tells router that the url was converted from hash to popstate
                router.fromHash = true;
            }
            
            $(window).bind("popstate", handleRoutes);
        }
        else if (hasHashState)
        {
            $(window).bind("hashchange.router", handleRoutes);
        }
        else
        {
            // if no events are available we use a timer to check periodically for changes in the url
            setInterval(
                function()
                {
                    if (location.href != currentUsedUrl)
                    {
                        handleRoutes();
                        currentUsedUrl = location.href;
                    }
                }, 500
            );
        }
       
    }
    
    bindStateEvents();
    
    router.go = function(url, title,state)
    {   
        if (hasPushState)
        {
            history.pushState({}, title, url);
            checkRoutes(state);
        }
        else
        {
            // remove part of url that we dont use
            url = url.replace(location.protocol + "//", "").replace(location.hostname, "");
            var hash = url.replace(location.pathname, "");
            
            if (hash.indexOf("!") < 0)
            {
                hash = "!/" + hash;
            }
            location.hash = hash;
        }
    };
    
    // do a check without affecting the history
    router.check = router.redo = function()
    {   
        checkRoutes(true);
    };
    
    // parse and wash the url to process
    function parseUrl(url)
    {
        var currentUrl = url ? url : location.pathname;
        
        currentUrl = decodeURI(currentUrl);
        
        // if no pushstate is availabe we have to use the hash
        if (!hasPushState)
        {   
            if (location.hash.indexOf("#!/") === 0)
            {
                currentUrl += location.hash.substring(3);
            }
            else
            {
                return '';
            }
        }
        
        // and if the last character is a slash, we just remove it
        currentUrl = currentUrl.replace(/\/$/, "");

        return currentUrl;
    }
    
    // get the current parameters for either a specified url or the current one if parameters is ommited
    router.parameters = function(url)
    {
        // parse the url so that we handle a unified url
        var currentUrl = parseUrl(url);
        
        // get the list of actions for the current url
        var list = getParameters(currentUrl);
        
        // if the list is empty, return an empty object
        if (list.length == 0)
        {
            router.currentParameters = {};
        }
        
        // if we got results, return the first one. at least for now
        else 
        {
            router.currentParameters = list[0].data;
        }
        
        return router.currentParameters;
    }
    
    function getParameters(url)
    {

        var dataList = [];
        
       // console.log("ROUTES:");

        for(var i = 0, ii = routeList.length; i < ii; i++)
        {
            var route = routeList[i];
            
            // check for mathing reg exp
            if (route.type == "regexp")
            {
                var result = url.match(route.route);
                if (result)
                {
                    var data = {};
                    data.matches = result;
                    
                    dataList.push(
                        {
                            route: route,
                            data: data
                        }
                    );
                    
                    // saves the current route id
                    router.currentId = route.id;
                    
                    // break after first hit
                    break;
                }
            }
            
            // check for mathing string routes
            else
            {
                var currentUrlParts = url.split("/");
                var routeParts = route.route.split("/");
                
                //console.log("matchCounter ", matchCounter, url, route.route)

                // first check so that they have the same amount of elements at least
                if (routeParts.length == currentUrlParts.length)
                {
                    var data = {};
                    var matched = true;
                    var matchCounter = 0;

                    for(var j = 0, jj = routeParts.length; j < jj; j++)
                    {
                        var isParam = routeParts[j].indexOf(":") === 0;
                        if (isParam)
                        {
                            data[routeParts[j].substring(1)] = decodeURI(currentUrlParts[j]);
                            matchCounter++;
                        }
                        else
                        {
                            if (routeParts[j] == currentUrlParts[j])
                            {
                                matchCounter++;
                            }
                        }
                    }

                    // break after first hit
                    if (routeParts.length == matchCounter)
                    {
                        dataList.push(
                            {
                                route: route,
                                data: data
                            }
                        );

                        // saved the current route id
                        router.currentId = route.id;
                        router.currentParameters = data;
                        
                        break; 
                    }
                    
                }
            }
            
        }
        
        return dataList;
    }
    
    function checkRoutes(state)
    {
        var currentUrl = parseUrl(location.pathname);

        // check if something is catched
        var actionList = getParameters(currentUrl);
        
        // ietrate trough result (but it will only kick in one)
        for(var i = 0, ii = actionList.length; i < ii; i++)
        {
            actionList[i].route.callback(_.merge(actionList[i].data,state));
        }
    }
    

    function handleRoutes(e)
    {
        if (e != null && e.originalEvent && e.originalEvent.state !== undefined)
        {
            checkRoutes();
        }
        else if (hasHashState)
        {
            checkRoutes();
        }
        else if (!hasHashState && !hasPushState)
        {
            checkRoutes();
        }
    }



    if (!$.router)
    {
        $.router = router;
    }
    else
    {
        if (window.console && window.console.warn)
        {
            console.warn("jQuery.status already defined. Something is using the same name.");
        }
    }
        
})( jQuery );



var fullScreen = false;
var baseUrl = $("base").attr("href") || "";
const splitedBasePath = baseUrl;
var imageLoader = `<div class="img-loader"><img class="inner-loader" src="images/configuration/loading-large.gif"></img></div>`;
var BurgerMenuHandler = {
  fullScreenInternal: false,
  fullScreenListener: function (val) {
    alert("changed")
  },
  set fullScreen(val) {
    this.fullScreenInternal = val;
    this.fullScreenListener(val);
  },
  get fullScreen() {
    return this.fullScreenInternal;
  },
  registerListener: function (listener) {
    this.fullScreenListener = listener;
  }
}
let escapeRoutes = [];
var platformbar = {
  initialize: function (initOptions, divId) {
    var contentDiv =
      '<div class="app-bar" style="background: #fff!important;color:#666!important;     box-shadow: 0 1px 0 rgba(0,0,0,.3)!important;height: 52px!important;width: 100%;position: relative; "><div style="display:flex;padding-left:24px;padding-right:24px;"><div class="app-info" style="flex: 1 1 0%;"><span type="title" class="app-info-title" style="display: inline-block; font-size: 20px; vertical-align: middle; line-height: 100%;"></span><div class="empty-host-label" style="display: inline-block; border-left: 1px solid rgb(238, 238, 238); margin: 15px; height: 23px; position: relative; top: -3px;">&nbsp;</div><span type="title" class="app-host-Label" style="display: inline-block;"> </span></div><div class="right-nav" style="flex: 2 1 0%;display: flex;color: rgba(102,102,102,0.3);justify-content: flex-end;"><div class="basic-nav-appdrawer" style="padding: 0px 4px 0px 4px;align-items: center;justify-content: center;width: 48px;position: relative;display: flex;top: -2px; "><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAl0lEQVRIS+2WWw2AMAxFzxzgBCSAArCAA5xgAQmgACSAEySQJf3YyMKjgX1tvzfrXdvTZoafj/k5PmeDDKjFdAJ25wEqzTWwAWagkKArUImJVvMy6ID+VLIWGACtFtfAlmEBcsliA0qnRBot2ORGDMZAk19rCVM7J1cIx6VIy/rVPS+DhGlwMadterdp485BwvQRpp9/Mg6Aan4ZbfE77QAAAABJRU5ErkJggg==" style="opacity: 0.3;height:24px;width: 24px; "></div><div class="basic-notification" style="flex: 0 0 auto; width: 48px; z-index: 1; display: inline-flex; font-size: 24px; align-items: center; justify-content: center;"><div class="notification-component-badge"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAAAzklEQVQ4T+WT2xEBQRBFz0aACMiAzYAMiAAZyIQQiIAMCIEIlAxkQN2q6a0xNY+t5U//zW7f07f6UfGjqDKcDbAEJi7nCuyAQ0wTA/WBswcIdQLOgKf/IwZS4hh4AHKlt0LO5GjovtU5kIRbB5HwoyogtwILtgb2BgsdmZsFcEr0bw4cQ1ch6OXEg4gb446Au3s0+hQoN00xrOA/gWxaXQ5G2tqa9Q3opmUtTae1wxLIxpxa4KZQCaQT6bls3Z6WMRol0NS7pxVw6Qpq3aM3/0woE4+0gDIAAAAASUVORK5CYII=" style="     opacity: 0.3;height: 24px;width: 24px; "></div></div><div class="user-profile" style="width: 48px;height: 50px;"><div class="user-profile-dropmenu-image" style="height: 24px;margin: 0px auto;width: 24px;position: relative;top:14px;"><div title="profile image" class="loading"></div></div></div></div></div></div>';
    document.getElementById(divId).innerHTML = contentDiv;
    var cssItem = document.createElement("style");
    cssItem.innerText =
      '.loading{font-size:30px}.loading:after{overflow:hidden;display:inline-block;vertical-align:middle;-webkit-animation:ellipsis steps(4,end) .9s infinite;animation:ellipsis steps(4,end) .9s infinite;position:absolute;margin-top:-10px;content:"\\2026";width:0}@keyframes ellipsis{to{width:1.25em}}@-webkit-keyframes ellipsis{to{width:1.25em}}';
    document.querySelector("head").appendChild(cssItem);
    var version = initOptions["version"],
      serviceApiUrl = initOptions["serviceApiUrl"],
      url = `https://unpkg.com/@bitpod/p10-platform-bar@${version}/dist/platformbar/`,
      cssPath = url + "index.css",
      scriptPath = url + "index.js";
    loadCSS(cssPath, document.head);
    fetch(scriptPath)
      .then(function (response) {
        return response.text();
      })
      .then(function (text) {
        $("body .img-loader").remove();
        var se = document.createElement("script");
        se.type = "text/javascript";
        se.text = text;
        document.querySelector("head").appendChild(se);
        p10platformbar.setWebpackPath(url);
        p10platformbar.PlatformServices.mountplatformbar(
          document.getElementById(divId), {
            initConfig: initOptions
          }
        );
      })
      .catch(e => {
        console.log(e);
        $("body .img-loader").remove();
        $.router.go(`${baseUrl}error`, "error");
      });
  }
};

async function onauthstatechanged(state) {
  // console.timeEnd("initialLoading");
  console.log(state);
  authState = state||{};
  showPlateformbarOptions();
  if(isAnonymousRoute()){
    fetchResources(state,startSinglePageTemplate)
    return ;
  }
  if (state||isPublicApps()) {
    fetchResources(state,startFrameworkCode);
    console.log("You have logged in successfully.");
  } else {
    console.log("Please login first.");
    let search = window.location.search || "";
    let returnUrl = createReturnUrl();
    
    $.router.go(`${baseUrl}login?${returnUrl}`, "login");
    // if (_.isEmpty(returnUrl)) {
    //   $.router.go(`${baseUrl}docs`, "docs");
    // } else {
    //   $.router.go(`${baseUrl}login?${returnUrl}`, "login");
    // }
  }
}

var justLoggedIn = false;

$(document).ready(function () {
  // console.time("initialLoading");
  let baseURL = getBaseUrl()
  escapeRoutes = [baseURL, `${baseURL}login`];
  // var baseAppPath = isOrgRequiredInRoute ? baseUrl + ":OrgName/:apps" : baseUrl + ":apps";
  console.log("baseurl = " + baseUrl);
  $.router.add(baseUrl + "login", "login", login);
  $.router.add(baseUrl + "error", "error", error);
  $("body").append(imageLoader);
  setupBootStrap();
});

const initializeOfflineJS = () => {
  Offline.options = {
    checkOnLoad: true,
    requests: true
  };
  Offline.off("down");
  Offline.on("down", () => {
    // toastNotification("There is no Internet connection.");
    $(".img-loader").remove();
    $(".img-loader1").remove();
  });
};

const registerRoutes = () => {
  // let baseAppPath = `${baseUrl}apps`;
  // console.log(`baseurl = ${baseUrl}`);
  // $.router.add(`${baseUrl}login`, "login", login);
  // $.router.add(`${baseUrl}about`, "about", about);
  // $.router.add(`${baseUrl}contact`, "contact", contact);
  // $.router.add(`${baseUrl}pricing`, "pricing", pricing);
  // $.router.add(`${baseUrl}error`, "error", error);
  // $.router.add(`${baseAppPath}`, "apps", createTiles);
  // $.router.add(`${baseAppPath}/forms/:formId`, "forms", renderForms);
  // $.router.add(`${baseAppPath}/:appName`, "application", applicationRoute);
  // $.router.add(`${baseAppPath}/:appName/:section/:navLink`,"module",$.debounce(300, Para.Util.Termset.selectNav));
  // $.router.add(`${baseAppPath}/:appName/:section/:navLink/views/:viewName/:id`,"details",listDetails);
  // $.router.add(`${baseAppPath}/:appName/:section/:navLink/views/:viewName`,"details",viewRender);
  setupDyanamicRouteTable()
};
const login = () => {
  $("#about").hide();
  $("#contact").hide();
  $("#pricing").hide();

  $(".pageNotFound").hide();
  $("#new-banner").show();
  $(".login-homepage").show();
  $("#header").hide();
  //$("#App").hide();
  $("#main").css("margin-top", 0);
  let provider = getParameterByName("p");
  if(provider){
    $(".multi-provider-signin").trigger("click");
    $(".c113").each(function(){
      $(this).text().toLowerCase() === provider ? $(this).trigger("click"):"";
    })
  }
  $(".sign-in-button").trigger("click");
};
const error = () => {
  $("#new-banner").hide();
  $(".pageNotFound").show();
  $(".login-homepage").show();
};
const checkHasFromsQuery = () => {
  let queryParameter = getParameterByName("formId");
  if (_.isEmpty(queryParameter)) {
    return false;
  }
  return true;
};
const getParameterByName = name => {
  let url = window.location.href;
  name = name.replace(/[\[\]]/g, "\\$&");
  let regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
    results = regex.exec(url);
  if (!results) return null;
  if (!results[2]) return "";
  return decodeURIComponent(results[2].replace(/\+/g, " "));
};
const about = () => {
  setRouterPage();
  $("#about").show();
};

const setRouterPage = () => {
  $(".pageNotFound").hide();
  $("#new-banner").show();
  $(".login-homepage").hide();
  $("#header").hide();
  $("#main").css("margin-top", 0);
};

const contact = () => {
  setRouterPage();
  $("#contact").show();
};
const pricing = () => {
  setRouterPage();
  $("#pricing").show();
};

const extractReturnUrl = url => {
  let queryStringParams = parseQueryString(url),
    returnUrl = _.get(queryStringParams, "returnUrl");
  return returnUrl;
};

const createReturnUrl = () => {
  let pathname = window.location.pathname;
  if (_.includes(escapeRoutes, pathname)) {
    let provider = getParameterByName("p");
    return provider ? `p=${provider}`:"";
  }
  let search = window.location.search;

  return `returnUrl=${window.location.pathname || ""}${search}`;
};

const getBaseUrl = () => {
  if (baseUrl == "/") {
    return baseUrl;
  }
  return splitedBasePath;
};

$(document).click(function (e) {
  if (e.target.id != "theme" && !$("#theme").find(e.target).length) {
    $("#theme").hide();
  }
});


function handleHamburgerMenu(e) {
  let fullScreen = BurgerMenuHandler.fullScreen;
  if (fullScreen) {
    console.log("is fullscreen view")
    drawerMenu(e);
    return;
  }
  if (isMobile()) {
    console.log("is mobile view");
    drawerMenu(e);
    return;
  }
}
BurgerMenuHandler.registerListener(function (val) {
  handleHamburgerMenu();
});


function isMobile() {
  var newWindowWidth = $(window).width();
  if (newWindowWidth < 769) {
    return true;
  }
  return false;
}

function drawerMenu(e) {
  let hasClosed = $(".left-nav").hasClass("closed")
  if (hasClosed) {
    $(".left-nav").removeClass("closed").removeClass("half-closed");
    $(".head-menu").addClass("left-20").removeClass("move-left");
    $("#mainbody").removeClass("main-full-container")
    return;
  }
  $(".left-nav").addClass("closed");
  $(".head-menu").removeClass("left-20").addClass("move-left");
  $("#mainbody").addClass("main-full-container")
  return;
}


function drawerMenu1(e) {
  console.log("burgerNavClicked.");
  //e.stopPropagation();
  var isClosed = $(".left-nav").hasClass("half-closed");
  if (isClosed) {
    $(".left-nav").removeClass("half-closed");
    $(".left-nav")
      .find(".burger-nav-head")
      .addClass("ext-width");
    moveLogo();
    moveBody();
    moveAction();
    hideShowLevelText();
    $("a.level-2").css("width", "96%");
    $(".tabs .scroller-right").addClass("scroll-trm");
  } else {
    $(".left-nav").addClass("half-closed");
    $(".left-nav")
      .find(".burger-nav-head")
      .removeClass("ext-width");
    moveLogo();
    moveBody();
    moveAction();
    hideShowLevelText();
    $(".tabs .scroller-right").removeClass("scroll-trm");
  }
  let isOverlapped = $("#formdesignerModel").length;
  if (!$(".left-nav").hasClass("overlapped") && isOverlapped) {
    $(".left-nav")
      .addClass("overlapped")
      .removeClass("half-closed");
    $(".hide-text").removeClass("hide-text");
  } else {
    $(".overlapped").removeClass("overlapped");
  }
}

function closedDesigner() {
  let hasClosed = $(".left-nav").hasClass("closed")
  if (hasClosed) {
    drawerMenu();
  }
  $('#formdesignerModel').iziModal('close');
  $(".active-class").trigger("click");
}

function startFormDesigner(e) {
  event.stopPropagation();
  $("#formdesignerModel").remove();
  let accessToken = authState.access_token,
    selectType = "new";
  let pageUrl = "Pages/p10-form-designer/edit.html";
  var url = ($("base").attr("href") || "") + pageUrl;
  let iframeUrl = `${url}?accessToken=${accessToken}&selectType=${selectType}`
  $("body").append(`         <div id="formdesignerModel" style="display: none">            <iframe id="form-designer-container" src="${iframeUrl}" style="height:100vh;width:100%"></iframe>        </div>`);
  $('#formdesignerModel').iziModal({
    title: "Form Designer",
    headerColor: "transparent",
    fullscreen: true,
    openFullscreen: true,
    onOpening: (e) => {
      BurgerMenuHandler.fullScreen = true;
    },
    onOpened: (e) => {},
    onClosed: (e) => {
      $("#form-designer-container").empty();
      BurgerMenuHandler.fullScreen = false;
      let hasClosed = $(".left-nav").hasClass("closed")
      if (hasClosed) {
        drawerMenu();
      }

    },
  });
  $('#formdesignerModel').iziModal('open');
}


function registerAnonymousRoutes(){
  $.router.add(`${baseAppPath}t`, "template", renderAnonymousTemplate);
   $.router.add(`${baseAppPath}t`, "template", renderAnonymousTemplate);
}

function renderAnonymousTemplate(){
  console.log("anonymous template rendering");
}





function setupDyanamicRouteTable(res){
    let  data=res['data'];
    data.push({"Controller": "DocsPublicApps",
    "Model": "initilizeFramework",
    "Route": "/docs",
    "View": ""})
    addRouteToLocalStore(data);
    data.forEach((item)=>{
      let {
        Route:route,Controller:controller,View:view,Model:model
      } = item;
      let path = getRoutesPath(route,view);
      //let baseRoutePath = `${baseUrl}${route.replace("/","")}`;
      $.router.add(`${path}`, view, Controllers[controller].bind(item));
    });
    return;
}

function getRoutesPath(route,view){
  let baseRoutePath = `${baseUrl}${route.replace("/","")}`;
  if(_.last(baseRoutePath) == "/"){
    return `${baseRoutePath}${view}`;
  }
  return `${baseRoutePath}/${view}`;
}



function isAnonymousRoute(){
  let path = location.pathname;
  if(path.indexOf("/p/")!=-1 || path.indexOf("/a/")!=-1 ){
    return true;
  }
  return false;
}

function isPublicRoute(){
  let path = location.pathname;
  return path.indexOf("/p/")!=-1;
}

let axiosInterceptor = null;

function isPublicApp(){
  if(!_.isEmpty(authState)){
    return false;
  }
  return true;
}

function setupBootStrap(){
  fetchRouteConfig()
  .then(setupDyanamicRouteTable)
  .then(platformbarRenderDecision)
  // .then(initializeOfflineJS)
  .catch((error) => {     
    setupBootErrors(error);      
    // this.error = {
    //     controller:"FrameworkController",
    //     error
    // }
    // history.state = this.error;
    // $.router.go(`/error/error_details`, "path",this.error);
  })
}
function platformbarRenderDecision(){
  isPublicRoute() ? fetchResources({},startSinglePageTemplate):initializePlatformar();
}
function initializePlatformar(){  
    $(window).on("resize", function (e) {
      // handleHamburgerMenu();
      // let hasClosed = $(".left-nav").hasClass("closed")
      // if (hasClosed) {
      //   drawerMenu();
      // }
    });
    handleHamburgerMenu();
    platformbar.initialize({
        stateVariable: "state",
        serviceApiUrl: `${$config.ps.serviceUrl}`,
        hostLabel: "",
        version: "2.0.2",
        settings: true,
        on_auth_state_change: $.debounce(300, onauthstatechanged),
        setting_state_change: function () {
          $("#theme").animate({
            width: "toggle"
          });
          console.log("setting state changed called.");
        },
        serializeExtra: function () {
          return window.location.search || "";
        },
        deserializeExtra: function (state) {
          justLoggedIn = true;
        },
        hamburger_state_change: function (e) {
          console.log("burgerNavClicked.");
          e.stopPropagation();
          var isClosed = $(".left-nav").hasClass("half-closed");
          if (isClosed) {
            $(".left-nav").removeClass("half-closed");
            $(".left-nav")
              .find(".burger-nav-head")
              .addClass("ext-width");
            moveLogo();
            moveBody();
            moveAction();
            hideShowLevelText();
            $("a.level-2").css("width", "96%");
            $(".tabs .scroller-right").addClass("scroll-trm");
          } else {
            $(".left-nav").addClass("half-closed");
            $(".left-nav")
              .find(".burger-nav-head")
              .removeClass("ext-width");
            moveLogo();
            moveBody();
            moveAction();
            hideShowLevelText();
            $(".tabs .scroller-right").removeClass("scroll-trm");
          }
          let isOverlapped = $("#formdesignerModel").length;
          if (!$(".left-nav").hasClass("overlapped") && isOverlapped) {
            $(".left-nav")
              .addClass("overlapped")
              .removeClass("half-closed");
            $(".hide-text").removeClass("hide-text");
          } else {
            $(".overlapped").removeClass("overlapped");
          }
        },
        hamburger_state_change: handleHamburgerMenu,
        hamburger: true
      },
      "App"
    );
    // console.timeLog("initialLoading");
    return;
}
function addRouteToLocalStore(data){
  data.forEach((item)=>{
    let { id } = item;
    let key = "Route." + id;
    localStorage.setItem(key, JSON.stringify(item));
  });
}

function showPlateformbarOptions(){
  if(isMobile()){
  //  $('.system-edit-mode').hide();
  //  $('.setting-application-icon .c43').hide();
  $('.basic-nav-appdrawer').hide();
  if(_.isEmpty(authState))
    return;
  //  $('.c55').hide();
   $('.c71').hide(); 
  // $('.right-nav').hide();
    $('.right-nav').find('.m_platform-options').remove();
      $('.right-nav').after(`<span class='m_platform-options'><div class="plaformbar-actions">
        <span class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v" aria-hidden="true"></i></span>
                <ul class="dropdown-menu platform-actions">
                  <li trigger-class="user-profile"><i class="fa fa-user-o" aria-hidden="true"></i>User</li>
                  <li trigger-class="basic-notification"><i class="fa fa-bell-o" aria-hidden="true"></i>Notifications</li>
                  <li trigger-class="application-icon"><i class="fa fa-th-large" aria-hidden="true"></i>Apps</li>
                  <li trigger-class="setting-application-icon"><i class="fa fa-cog" aria-hidden="true"></i>Themes</li>
                </ul>
                </div></span>`);
      $('.m_platform-options li').off();
      $('.m_platform-options li').click(showPlatformOption);
  }
}

function showPlatformOption(event){
  // event.stop​Propagation()
  let triggerClass = $(this).attr("trigger-class");
  if(triggerClass==="setting-application-icon"){
    $(".platform-actions").removeClass("show");
    $("#theme").show();
    event.stopPropagation();
  }else{
    $(`.${triggerClass}`).trigger('click');
  }
}

function addcardValidatorScript(){
  let usedLaterScript = document.createElement('script');
  usedLaterScript.src = 'https://cdn.jsdelivr.net/npm/jquery-creditcardvalidator@1.0.0/jquery.creditCardValidator.min.js';
  document.body.appendChild(usedLaterScript);
}

let fetchRouteConfig = ()=>{
  let url = `${hostURL}/svc/api/RouteConfigs`;
  let headers = {
    accept: "application/json"
  };
  let isPrimeTenant = true
  return axiosWrapper("get", url,{},headers,isPrimeTenant);
//   return Promise.resolve(RouteConfig);
}

const axiosWrapper = (
  method = "get",
  url,
  data = {},
  headers ,
  isPrimeTenant = false
) => {
  if(url.startsWith("/") && window.location.hostname == "localhost"){
    url = `${hostURL}${url}`
  }
  if (_.isEmpty(headers) && !_.isEmpty(authState)) {
    headers = {
      accept: "application/json",
      authorization: `Bearer ${authState.access_token}`
    }
  }
  
  if (isPrimeTenant) {
    const primeTenantAxios = axios.create();
    headers = _.assign(headers,{"x-org-id":1,resolver: "requestHeader"})
    return primeTenantAxios({
      method,
      url,
      headers,
      data
    });
  } else {
    return axios({
      method,
      url,
      headers,
      data
    });
  }
};

function fetchResources(state,callback){
  // $("body").append(imageLoader);
 addLandingPageSkeleton()
 loadCSSResources();
 const peerDeps = [
   "https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js",
   "https://cdnjs.cloudflare.com/ajax/libs/immutable/3.7.6/immutable.min.js",
   "https://momentjs.com/downloads/moment-with-locales.min.js",
   "https://unpkg.com/popper.js/dist/umd/popper.min.js",
  ]
  addPreloadScripts()
  $script(peerDeps,'peerDeps', function() {
    $script(dependendancy,'dependendancy', function() {
      registerFrameworkSubRoutes(false);
      $("body .img-loader").remove();
      callback(state);
    })
  })
}

function startFrameworkCode(state){
  authState = state;
  !_.isEmpty(state && state.state) && state.state.includes("?p") ? authState.state="":"";
  if (!_.isEmpty(state && state.state)) {
    let returnUrl = extractReturnUrl(state.state) || "";
    if (!_.isEmpty(returnUrl) && !_.includes(escapeRoutes, returnUrl)) {
      $.router.go(`${returnUrl}`, "tiles");
    }
  }
  getSwaggerSchema().then(persistRequestData);
  appInitialize();
}

function startSinglePageTemplate(){
  $("body").append(imageLoader);
  addcardValidatorScript()
  $('.container .row.fn-body').addClass('fm-body');
  $.router.go(`${location.pathname}${location.search}`, "path");
}

function loadCSSResources(){
  let mainCss = "CSS/custom/stylemain.css";
  let themeLinks="";
  themeCSS.forEach(({url,title})=>{
    themeLinks += `<link rel=" alternate stylesheet " as="style" href="${url}" title="${title}">`;
  });
  $(themeLinks).insertAfter(`link[href="${mainCss}"]`);
  let lastPreloadCSS = "CSS/custom/style-dark.css";
  cssDependendancies.forEach((url)=>{
    loadCSS(url, $(`link[href="${lastPreloadCSS}"]`)[0]);
    lastPreloadCSS =url; 
  })
}

function preloadScriptOnload(href){
  var preloadedScript = document.createElement('script');
  preloadedScript.src = href;
  document.body.appendChild(preloadedScript)
}

function addPreloadScripts(){
  let preloadLinks = "";
  cssLinks.forEach((url)=>{
    preloadLinks += `<link href="${url}" as="style" onload="this.rel = 'stylesheet'" rel="preload" >`;
  });
  let lastCSS = cssDependendancies[cssDependendancies.length-1];
  $(preloadLinks).insertAfter(`link[href='${lastCSS}']`);
  const jsLinks = [
    "https://cdn.jsdelivr.net/npm/jquery-creditcardvalidator@1.0.0/jquery.creditCardValidator.min.js",
    "https://www.gstatic.com/charts/loader.js",
    "https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote.js",
    "//mozilla.github.io/pdf.js/build/pdf.js",
    "https://hayageek.github.io/jQuery-Upload-File/4.0.11/jquery.uploadfile.min.js",
    "https://cdnjs.cloudflare.com/ajax/libs/jsoneditor/5.14.1/jsoneditor.min.js",
    "https://cdnjs.cloudflare.com/ajax/libs/lscache/1.3.0/lscache.min.js",
    "Script/lib/importtool.js",
    "Script/lib/epos-2.7.0.js"
  ]
  jsLinks.forEach((url)=>{
    $("body").append(`<link rel="preload" as="script" href="${url}" onload="preloadScriptOnload(this.href)">`)
  });
}


var burgerMenuNav = function () {
    var nav = $(".left-nav");
    $("#openNav").on("click",function (e) {
        e.stopPropagation();
        var isClosed = $(nav).hasClass("half-closed");
        if (isClosed) {
            $(nav).removeClass("half-closed");
            $(nav).find(".burger-nav-head").addClass("ext-width");
            moveLogo();
            moveBody();
            moveAction();
            hideShowLevelText();
            $("a.level-2").css("width", "96%");
            $(".tabs .scroller-right").addClass("scroll-trm");

            $(".logo").show();
        } else {
            $(".logo").hide();
            //$(nav).addClass("half-closed");
            $(nav).find(".burger-nav-head").removeClass("ext-width");
            moveLogo();
            moveBody();
            moveAction();
            hideShowLevelText();
            $("a.level-2").css("width", "42px");
            $(".tabs .scroller-right").removeClass("scroll-trm");

        }
    });
    $(nav).on("mouseover", function (e) {
        e.stopPropagation();
        $(this).addClass("lQ-scroll");
    });
    $(nav).on("mouseout", function (e) {
        e.stopPropagation();
        $(this).removeClass("lQ-scroll");
    });
    $(nav).on("scroll", function (e) {
        e.stopPropagation();
    })
    $(nav).find("ul li a.level-2").on("mouseover", function (e) {
        //$(document).on("mouseover","a.level-2", function (e) {
        var iconBackground = $(this).attr("data-background");
        $(this).find("i.fa").addClass("icon-hover").css("background-color", iconBackground);
    });
    $(nav).find("ul li a.level-2").on("mouseout", function (e) {
        if (!$(this).hasClass("active-class")) $(this).find("i.fa").removeClass("icon-hover").css("background-color", "");
    });

    $("nav ul:first li:first a:first[data-cf='Orphan']").css("display", "none")//hide orphan 
    return true;
};
var navToolTip = function () {
    $(".left-nav a i").on("mouseover", function () {
        if ($(".left-nav").hasClass("half-closed")) {
            $("body").append("<div class='nav-tooltip fixed'><div class='trm-tt'><div class='arrow-left'></div><div class='tooltip-title'>" + $(this).parent().text() + "</div></div></div>");
            $(".nav-tooltip").find(".trm-tt").css("top", ($(this).position().top + 40 - $(".left-nav")[0].scrollTop) + 58).css("left", 62);
        }
    });
    $(".left-nav a i").on("mouseout", function () {
        $(".nav-tooltip").remove();
        $(this).parent().find(".nav-text").removeClass("relative");
    });
};

function moveLogo() {
    if (!$(".left-nav").hasClass("half-closed")) {
        $(".head-menu").addClass("left-20");
    } else {
        $(".head-menu").removeClass("left-20");
    }
}

function moveBody() {
    if (!$("#mainbody").hasClass("content-trm")) {
        $("#mainbody").addClass("content-trm");
    } else {
        $("#mainbody").removeClass("content-trm");
    }
}

function moveAction() {
    var action = $(".custom-list-content");
    if (!$(action).hasClass("action-trm")) {
        $(action).addClass("action-trm");
    } else {
        $(action).removeClass("action-trm");
    }
}

function hideShowLevelText() {
    var levelOneText = $("a.level-1")
    if (!$(levelOneText).hasClass("hide-text")) {
        $(levelOneText).addClass("hide-text");
    } else {
        $(levelOneText).removeClass("hide-text");
    }
}
$(window).on("load, resize", function() {
    var viewportWidth = $(window).width();
    if (viewportWidth < 600) {
        //$(".left-nav").addClass("half-closed");
    }
});
function mobileViewUpdate() {
    var viewportWidth = $(window).width();
    if (viewportWidth < 600) {
        //$(".left-nav").addClass("half-closed");
    }
}


const Controllers = {
    SinglePage: function () {
        //1. fetch view template 
        //2. complite view template
        //3. find model function from lib
        //4. execute model function 
        //5. render view on page

        let {
            View:view,
            Model:model
        } = this;
        let filter = {
            where: {
                Name: view
            }
        };
        AppRoute.update({view});
        return getCompiledHandleBarTemplate(filter,this)
            .then(fetchViewModel)
            .then(viewModelCall)
            .then(executeHandlebarTemplate)
            .then(fetchTemplateActions)
            .then(bindHtmlToElement)
            .then(() => {
                $("body .img-loader").remove();
                console.log(`${view} rendered successfully!`);
            })
            .catch((error) => {
                
                this.error = {
                    controller:"SinglePage",
                    error
                }
                history.state = this.error;
                $.router.go(`/error/error_details`, "path",this.error);
            })
    },
    ErrorHandler: function (data) {
        
        let {Model:model,View:view} = this;
        let filter = {
            where: {
                Name: view
            }
        };
        return getCompiledHandleBarTemplate(filter,this)
            .then(()=>({data}))
            .then(executeHandlebarTemplate)
            .then(bindHtmlToElement)
    },
    FrameworkController:function(data){
        // registerFrameworkSubRoutes();
        createTiles(data);
    },
    DocsPublicApps:function(data){     
      $('.container .row.fn-body').removeClass('fm-body');
        createTiles();
    }
}


//Helpers

function getCompiledHandleBarTemplate(filter,data){
    return fetchTemplates(filter)
    .bind(data)
    .then(readTemplate)
    .then(compileHandlerBarTemplate)
    .then(registerHandleBarHelpers)
}



function compileHandlerBarTemplate(template = "") {
    this.template = Handlebars.compile(template);
    return
}

function readTemplate({
    data = []
}) {
    if (_.isEmpty(data)) {
        return Promise.reject({
            message: "template not found"
        })
    }
    data && storeTemplSessionStore(data[0]);
    return data && data.length ? _.get(data, ["0", "Template"]) :_.isUndefined(_.get(data,"Template"))? data:_.get(data,"Template");
}

function viewModelCall(result = []) {
    let res = result.data.length ? _.get(result.data,"0") : result.data;
    let {
        Template: fn,
        Name: name
    } = res;
    if (name != this.Model) {
        return Promise.reject("function miss match!!")
    }
    storeTemplSessionStore(res);
    window.eval(fn);
    return window[this.Model].call();
}

function executeHandlebarTemplate({
    data = []
}) {
    return this.template({
        item: data
    });
}

function bindHtmlToElement(htm = "") {
  //  $(".fm-body").html(htm);
   $('#content').html(htm);
   $('#content').show();
   $('#content').attr('systemedit',true).attr('type','anonymoustemplate');
   $('#content').addClass('unauth-template');
   $('.head-menu').hide();
    return;
}

function fetchViewModel() {

    if (_.isEmpty(this.Model)) {
        return Promise.reject({
            message: "view does not have"
        })
    }

    return fetchModel(this);
}
function projectRoute(data){
    console.log("in project Route",data);
}

function registerFrameworkSubRoutes(isOrgRequiredInRoute){
    let baseAppPath = isOrgRequiredInRoute ? `${baseUrl}:OrgName/apps`:`${baseUrl}apps` ;
    console.log(`baseurl = ${baseUrl}`);
    $.router.add(`${baseUrl}login`, "login", login);
    $.router.add(`${baseUrl}error`, "error", error);
    //$.router.add(`${baseAppPath}`, "apps", createTiles);
    if(isOrgRequiredInRoute){
      $.router.add(`${baseAppPath}`, "apps", createTiles);
    }
    $.router.add(`${baseAppPath}/:appName/p`,projectRoute);
    $.router.add(`${baseAppPath}/:appName/p/:prejectName/:section/:navLink`,"module",$.debounce(300, createContent));
    $.router.add(`${baseAppPath}/:appName/p/:section/:navLink/views/:viewName/search`,"search",searchRouteHandler);
    $.router.add(`${baseAppPath}/:appName/p/:prejectName/:section/:navLink/views/:viewName/:id`,"details",listDetails);
    $.router.add(`${baseAppPath}/:appName/p/:prejectName/:section/:navLink/views/:viewName`,"details",viewRender);

    // let asd=new RegExp(/(P_)\w+/);
    // $.router.add(`${baseAppPath}/:appName/${asd}`, "application", projectDisplay);
    $.router.add(`${baseAppPath}/forms/:formId`, "forms", renderForms);
    $.router.add(`${baseAppPath}/:appName`, "application", applicationRoute);
    $.router.add(`${baseAppPath}/:appName/:section/:navLink`,"module",$.debounce(300, createContent));
    $.router.add(`${baseAppPath}/:appName/:section/:navLink/views/:viewName/search`,"search",searchRouteHandler);
    $.router.add(`${baseAppPath}/:appName/:section/:navLink/views/:viewName/:id`,"details",listDetails);
    $.router.add(`${baseAppPath}/:appName/:section/:navLink/views/:viewName`,"details",viewRender);


    $.router.add(`${baseUrl}docs/forms/:formId`, "forms", renderForms);
    $.router.add(`${baseUrl}docs/:appName`, "application", applicationRoute);
    $.router.add(`${baseUrl}docs/:appName/:section/:navLink`,"module",$.debounce(300, createContent));
    $.router.add(`${baseUrl}docs/:appName/:section/:navLink/views/:viewName/search`,"search",searchRouteHandler);
    $.router.add(`${baseUrl}docs/:appName/:section/:navLink/views/:viewName/:id`,"details",listDetails);
    $.router.add(`${baseUrl}docs/:appName/:section/:navLink/views/:viewName`,"details",viewRender);
    // $.router.add(`${baseAppPath}/:appName/:projectName/:section/:navLink`,"module",$.debounce(300, Para.Util.Termset.selectNav));
    // $.router.add(`${baseAppPath}/:appName/:projectName/:section/:navLink/views/:viewName/:id`,"details",listDetails);
    // $.router.add(`${baseAppPath}/:appName/:projectName/:section/:navLink/views/:viewName`,"details",viewRender);
}


function fetchTemplateActions(htm){
    //1. action fetch 
    //2. action dynamic load
    //3. html render 
    //this.htm=htm;
    
    return fetchActions(this)
   // .bind(this)
    .then(getScripts)
    .then(createScriptTag)
    .then((data)=>{
        return `${data}${htm}`;
    })
    
}
function getScripts(res){
    let {data}=res;
    data && storeTemplSessionStore(data[0]);
    return data && data.length?_.get(data,["0","Template"]):_.get(data,"Template");
}
function createScriptTag(actionsString=""){
   return `<script>${actionsString.trim()}</script>`
}
const storeTemplSessionStore = function storeTemplSessionStore(data){
    let key = `Template.${_.get(data,'id')}`;
    setSessionStorage(key, data);
}
const setSessionStorage = function setSessionStorage(key, value){
    sessionStorage.setItem(key, JSON.stringify(value));
}
const getSessionTemplateByName = function getSessionTemplateByName(name) {
    let template = {};
    _.find(_.keys(sessionStorage),function (key) {
      let isTemplateKey = _.startsWith(key, "Template.");
      if (isTemplateKey) {
        let templateString = sessionStorage.getItem(key) || "{}";
        let templateObj = JSON.parse(templateString);
        let localCopyName = templateObj.Name;
        if (localCopyName == name) {
          template = templateObj;
          return true;
        }
      }
    });
    return template;
};

/*!
 * jQuery throttle / debounce - v1.1 - 3/7/2010
 * http://benalman.com/projects/jquery-throttle-debounce-plugin/
 * 
 * Copyright (c) 2010 "Cowboy" Ben Alman
 * Dual licensed under the MIT and GPL licenses.
 * http://benalman.com/about/license/
 */

// Script: jQuery throttle / debounce: Sometimes, less is more!
//
// *Version: 1.1, Last updated: 3/7/2010*
// 
// Project Home - http://benalman.com/projects/jquery-throttle-debounce-plugin/
// GitHub       - http://github.com/cowboy/jquery-throttle-debounce/
// Source       - http://github.com/cowboy/jquery-throttle-debounce/raw/master/jquery.ba-throttle-debounce.js
// (Minified)   - http://github.com/cowboy/jquery-throttle-debounce/raw/master/jquery.ba-throttle-debounce.min.js (0.7kb)
// 
// About: License
// 
// Copyright (c) 2010 "Cowboy" Ben Alman,
// Dual licensed under the MIT and GPL licenses.
// http://benalman.com/about/license/
// 
// About: Examples
// 
// These working examples, complete with fully commented code, illustrate a few
// ways in which this plugin can be used.
// 
// Throttle - http://benalman.com/code/projects/jquery-throttle-debounce/examples/throttle/
// Debounce - http://benalman.com/code/projects/jquery-throttle-debounce/examples/debounce/
// 
// About: Support and Testing
// 
// Information about what version or versions of jQuery this plugin has been
// tested with, what browsers it has been tested in, and where the unit tests
// reside (so you can test it yourself).
// 
// jQuery Versions - none, 1.3.2, 1.4.2
// Browsers Tested - Internet Explorer 6-8, Firefox 2-3.6, Safari 3-4, Chrome 4-5, Opera 9.6-10.1.
// Unit Tests      - http://benalman.com/code/projects/jquery-throttle-debounce/unit/
// 
// About: Release History
// 
// 1.1 - (3/7/2010) Fixed a bug in <jQuery.throttle> where trailing callbacks
//       executed later than they should. Reworked a fair amount of internal
//       logic as well.
// 1.0 - (3/6/2010) Initial release as a stand-alone project. Migrated over
//       from jquery-misc repo v0.4 to jquery-throttle repo v1.0, added the
//       no_trailing throttle parameter and debounce functionality.
// 
// Topic: Note for non-jQuery users
// 
// jQuery isn't actually required for this plugin, because nothing internal
// uses any jQuery methods or properties. jQuery is just used as a namespace
// under which these methods can exist.
// 
// Since jQuery isn't actually required for this plugin, if jQuery doesn't exist
// when this plugin is loaded, the method described below will be created in
// the `Cowboy` namespace. Usage will be exactly the same, but instead of
// $.method() or jQuery.method(), you'll need to use Cowboy.method().

(function(window,undefined){
    '$:nomunge'; // Used by YUI compressor.
    
    // Since jQuery really isn't required for this plugin, use `jQuery` as the
    // namespace only if it already exists, otherwise use the `Cowboy` namespace,
    // creating it if necessary.
    var $ = this.jQuery || this.Cowboy || ( this.Cowboy = {} ),
      
      // Internal method reference.
      jq_throttle;
    
    // Method: jQuery.throttle
    // 
    // Throttle execution of a function. Especially useful for rate limiting
    // execution of handlers on events like resize and scroll. If you want to
    // rate-limit execution of a function to a single time, see the
    // <jQuery.debounce> method.
    // 
    // In this visualization, | is a throttled-function call and X is the actual
    // callback execution:
    // 
    // > Throttled with `no_trailing` specified as false or unspecified:
    // > ||||||||||||||||||||||||| (pause) |||||||||||||||||||||||||
    // > X    X    X    X    X    X        X    X    X    X    X    X
    // > 
    // > Throttled with `no_trailing` specified as true:
    // > ||||||||||||||||||||||||| (pause) |||||||||||||||||||||||||
    // > X    X    X    X    X             X    X    X    X    X
    // 
    // Usage:
    // 
    // > var throttled = jQuery.throttle( delay, [ no_trailing, ] callback );
    // > 
    // > jQuery('selector').bind( 'someevent', throttled );
    // > jQuery('selector').unbind( 'someevent', throttled );
    // 
    // This also works in jQuery 1.4+:
    // 
    // > jQuery('selector').bind( 'someevent', jQuery.throttle( delay, [ no_trailing, ] callback ) );
    // > jQuery('selector').unbind( 'someevent', callback );
    // 
    // Arguments:
    // 
    //  delay - (Number) A zero-or-greater delay in milliseconds. For event
    //    callbacks, values around 100 or 250 (or even higher) are most useful.
    //  no_trailing - (Boolean) Optional, defaults to false. If no_trailing is
    //    true, callback will only execute every `delay` milliseconds while the
    //    throttled-function is being called. If no_trailing is false or
    //    unspecified, callback will be executed one final time after the last
    //    throttled-function call. (After the throttled-function has not been
    //    called for `delay` milliseconds, the internal counter is reset)
    //  callback - (Function) A function to be executed after delay milliseconds.
    //    The `this` context and all arguments are passed through, as-is, to
    //    `callback` when the throttled-function is executed.
    // 
    // Returns:
    // 
    //  (Function) A new, throttled, function.
    
    $.throttle = jq_throttle = function( delay, no_trailing, callback, debounce_mode ) {
      // After wrapper has stopped being called, this timeout ensures that
      // `callback` is executed at the proper times in `throttle` and `end`
      // debounce modes.
      var timeout_id,
        
        // Keep track of the last time `callback` was executed.
        last_exec = 0;
      
      // `no_trailing` defaults to falsy.
      if ( typeof no_trailing !== 'boolean' ) {
        debounce_mode = callback;
        callback = no_trailing;
        no_trailing = undefined;
      }
      
      // The `wrapper` function encapsulates all of the throttling / debouncing
      // functionality and when executed will limit the rate at which `callback`
      // is executed.
      function wrapper() {
        var that = this,
          elapsed = +new Date() - last_exec,
          args = arguments;
        
        // Execute `callback` and update the `last_exec` timestamp.
        function exec() {
          last_exec = +new Date();
          callback.apply( that, args );
        };
        
        // If `debounce_mode` is true (at_begin) this is used to clear the flag
        // to allow future `callback` executions.
        function clear() {
          timeout_id = undefined;
        };
        
        if ( debounce_mode && !timeout_id ) {
          // Since `wrapper` is being called for the first time and
          // `debounce_mode` is true (at_begin), execute `callback`.
          exec();
        }
        
        // Clear any existing timeout.
        timeout_id && clearTimeout( timeout_id );
        
        if ( debounce_mode === undefined && elapsed > delay ) {
          // In throttle mode, if `delay` time has been exceeded, execute
          // `callback`.
          exec();
          
        } else if ( no_trailing !== true ) {
          // In trailing throttle mode, since `delay` time has not been
          // exceeded, schedule `callback` to execute `delay` ms after most
          // recent execution.
          // 
          // If `debounce_mode` is true (at_begin), schedule `clear` to execute
          // after `delay` ms.
          // 
          // If `debounce_mode` is false (at end), schedule `callback` to
          // execute after `delay` ms.
          timeout_id = setTimeout( debounce_mode ? clear : exec, debounce_mode === undefined ? delay - elapsed : delay );
        }
      };
      
      // Set the guid of `wrapper` function to the same of original callback, so
      // it can be removed in jQuery 1.4+ .unbind or .die by using the original
      // callback as a reference.
      if ( $.guid ) {
        wrapper.guid = callback.guid = callback.guid || $.guid++;
      }
      
      // Return the wrapper function.
      return wrapper;
    };
    
    // Method: jQuery.debounce
    // 
    // Debounce execution of a function. Debouncing, unlike throttling,
    // guarantees that a function is only executed a single time, either at the
    // very beginning of a series of calls, or at the very end. If you want to
    // simply rate-limit execution of a function, see the <jQuery.throttle>
    // method.
    // 
    // In this visualization, | is a debounced-function call and X is the actual
    // callback execution:
    // 
    // > Debounced with `at_begin` specified as false or unspecified:
    // > ||||||||||||||||||||||||| (pause) |||||||||||||||||||||||||
    // >                          X                                 X
    // > 
    // > Debounced with `at_begin` specified as true:
    // > ||||||||||||||||||||||||| (pause) |||||||||||||||||||||||||
    // > X                                 X
    // 
    // Usage:
    // 
    // > var debounced = jQuery.debounce( delay, [ at_begin, ] callback );
    // > 
    // > jQuery('selector').bind( 'someevent', debounced );
    // > jQuery('selector').unbind( 'someevent', debounced );
    // 
    // This also works in jQuery 1.4+:
    // 
    // > jQuery('selector').bind( 'someevent', jQuery.debounce( delay, [ at_begin, ] callback ) );
    // > jQuery('selector').unbind( 'someevent', callback );
    // 
    // Arguments:
    // 
    //  delay - (Number) A zero-or-greater delay in milliseconds. For event
    //    callbacks, values around 100 or 250 (or even higher) are most useful.
    //  at_begin - (Boolean) Optional, defaults to false. If at_begin is false or
    //    unspecified, callback will only be executed `delay` milliseconds after
    //    the last debounced-function call. If at_begin is true, callback will be
    //    executed only at the first debounced-function call. (After the
    //    throttled-function has not been called for `delay` milliseconds, the
    //    internal counter is reset)
    //  callback - (Function) A function to be executed after delay milliseconds.
    //    The `this` context and all arguments are passed through, as-is, to
    //    `callback` when the debounced-function is executed.
    // 
    // Returns:
    // 
    //  (Function) A new, debounced, function.
    
    $.debounce = function( delay, at_begin, callback ) {
      return callback === undefined
        ? jq_throttle( delay, at_begin, false )
        : jq_throttle( delay, callback, at_begin !== false );
    };
    
  })(this);

// require("script-loader!./src/Script/lib/jqueryrouter.js");
// require("script-loader!./src/Script/custom/platformBar/index.js");
// require("script-loader!./src/Script/custom/Framework/burgerMenu.js");
// require("script-loader!./src/Script/custom/Framework/controllers.js");
// require("script-loader!./src/Script/lib/jquerydebounce.js");

function removeLoadder(){
  $(".img-loader").remove();
  $(".img-loader1").remove();
} 

function setupBootErrors(error){
  removeLoadder();
  showError(error);
}

const showError = (error) => {
  console.error(error);
  const errorStatusCode = _.get(error,["response","status"]); 
  if(errorStatusCode === 401){
    appsRenderErr(unauthrizedMessage,{color:"red"});
  }else if(errorStatusCode === 404){
    appsRenderErr(resourceNotFound);
  }else if(!_.get(error,["response"])){
    appsRenderErr("Something Went Wrong, Try again");
  }else{
    !isPublicApp()?appsRenderErr(`There was an unexpected error`):"";
  }
}
function appsRenderErr(errorMsg,options={}){
  // const isSubscriptionExpired = $("free-trail-msg").length === 0;
  // if(!isSubscriptionExpired){
  $("#header").find(".apps-render-error").remove();
  $("#header").append(`<div class="apps-render-error display-error">${errorMsg}</div>`);
  if(options.color){
    $("#header .apps-render-error").css("color", options.color);
  }
  $(".tile-banner").hide();
  $("#header").show();
  $("#content").hide();
  // }
}

function addAppsPageSkeleton(){
  $(".tile-banner").show();
  $("#header").hide();
  $(".hamburger-application-icon").hide();
  $("#content").addClass("content-on-tile");
  let tilesContent = $("#content");
  tilesContent.html(landingPageWrapper);
  let categorySection=`<div class="row text-center tiles">
  <div class="app-category tile-loading-animation"></div>
  <div class="tile-wide ld-module fg-white">
      <div class="tile-content tile-loading-animation slide-up">
          <div class="tile-label">
              <div class="tile-name tile-loading-animation"></div>
          </div>
      </div>
  </div>
</div>`
  $("#reactTiles").append(`<div class="tilesCat skeleton-loading">${categorySection}${categorySection}</div>`)
}

function addLandingPageSkeleton() {
  let route = getInitialRoute();
  if (route === "apps")
    addAppsPageSkeleton()
  else
    $("body").append(imageLoader);
}

function getInitialRoute(){
  let path = location.pathname || authState.state || "";
  let appName =  path.split("/apps")[1]||path.split("/docs")[1];
  if(_.isEmpty(appName)&& !isAnonymousRoute()){
    if(authState && authState.state && authState.state.includes("/apps/"))
      return "view";
    return "apps";
  }
  return "view";
}
function isPublicApps(){
  return  location.pathname.indexOf("/docs")!=-1;
}